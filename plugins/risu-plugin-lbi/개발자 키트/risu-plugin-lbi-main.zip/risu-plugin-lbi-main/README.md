# risu-plugin-lbi
Large Beautiful Integrator for RisuAI
