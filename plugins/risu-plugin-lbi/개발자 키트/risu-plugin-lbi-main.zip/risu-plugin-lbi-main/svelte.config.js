import { vitePreprocess } from "@sveltejs/vite-plugin-svelte";

export default {
  compilerOptions: {
    css: "injected",
  },
  preprocess: vitePreprocess(),
  vitePlugin: {
    emitCss: false,
  },
};
