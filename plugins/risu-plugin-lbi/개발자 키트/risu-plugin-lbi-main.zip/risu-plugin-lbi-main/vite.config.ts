import { defineConfig } from "vite";
import tailwindcss from "@tailwindcss/vite";
import { svelte } from "@sveltejs/vite-plugin-svelte";
import cssInjectedByJs from "vite-plugin-css-injected-by-js";
import license from "rollup-plugin-license";

// https://vite.dev/config/
export default defineConfig(({ command }) => {
  return {
    build: {
      lib: {
        entry: "src/main.ts",
        fileName: "plugin",
        formats: ["es"],
      },
      minify: false,
      sourcemap: false,
      target: ["safari15", "chrome100", "firefox100", "edge100"],
    },
    plugins: [
      tailwindcss(),
      svelte(),
      cssInjectedByJs({
        injectionCodeFormat: "esm",
        topExecutionPriority: false,
      }),
      license({
        banner: {
          commentStyle: "regular",
          content: `
  <%= pkg.name %>
  @license GPL-3.0 <https://opensource.org/license/gpl-3-0>
  @copyright Wg7VmsZ6xE <%= moment().format('YYYY') %>
  @dependencies:<% _.forEach(dependencies, function (dependency) { %>
  <%= dependency.name %>:<%= dependency.version %> -- <%= dependency.license %><% }) %>`,
        },
      }),
    ],
    resolve: {
      alias: [
        {
          find: "$assets",
          replacement: "/src/assets",
        },
        {
          find: "$lib",
          replacement: "/src/lib",
        },
        {
          find: "$risu",
          replacement: "/src/risu",
        },
        {
          find: "$ts",
          replacement: "/src/ts",
        },
        {
          find: /app.css$/,
          replacement: command === "build" ? "app.css" : "app.dev.css",
        },
      ],
    },
  };
});
