<script lang="ts">
  import { testModalOpen } from "$ts/stores.svelte";
  import * as Sidebar from "$lib/components/ui/sidebar/index.js";
  import AppSidebar from "$lib/components/app-sidebar.svelte";
  import { Button } from "$lib/components/ui/button/index.js";
  import { PanelLeftIcon, SunIcon, MoonIcon, XIcon } from "@lucide/svelte";
  import { Separator } from "$lib/components/ui/separator/index.js";
  import ChatSettings from "$lib/components/chat-settings.svelte";
  import MemorySettings from "$lib/components/memory-settings.svelte";
  import TranslationSettings from "$lib/components/translation-settings.svelte";
  import OtherSettings from "$lib/components/other-settings.svelte";
  import CacheTool from "$lib/components/cache-tool.svelte";
  import GithubTool from "$lib/components/github-tool.svelte";

  let isDarkMode = $state(false);
  let currentPage = $state("chat");

  $testModalOpen = true;

  $effect(() => {
    console.log("currentPage changed:", currentPage);
  });
</script>

{#if $testModalOpen}
  <!-- Modal Backdrop -->
  <div class="tw:fixed tw:inset-0 tw:z-50">
    <!-- Modal Wrapper -->
    <div class="tw:w-full tw:h-full tw:flex tw:justify-center tw:items-center">
      <!-- Modal Window -->
      <div
        class="tw:w-full tw:md:w-7xl tw:h-full tw:md:h-[98dvh] tw:md:rounded-xl tw:md:overflow-hidden tw:md:border tw:md:shadow-2xl
        tw:bg-background tw:text-foreground tw:border-border-all tw:outline-ring/50-all"
        class:dark={isDarkMode}
        role="dialog"
        tabindex="0"
        onkeydown={(e) => {
          if (e.key === "Escape") {
            $testModalOpen = false;
          }
        }}
      >
        <Sidebar.Provider class="tw:h-full">
          <AppSidebar bind:currentPage />

          <!-- Main Content -->
          <div class="tw:flex-1 tw:flex tw:flex-col">
            <!-- Header -->
            <header
              class="tw:h-12 tw:px-2 tw:flex tw:justify-between tw:items-center tw:border-b"
            >
              <div class="tw:h-full tw:flex tw:items-center tw:gap-1">
                <!-- Sidebar Button -->
                <Sidebar.Trigger class="tw:size-9">
                  <PanelLeftIcon class="tw:size-5" />
                </Sidebar.Trigger>

                <Separator orientation="vertical" class="tw:mx-1" />

                <!-- Theme Button -->
                <Button
                  variant="ghost"
                  size="icon"
                  onclick={() => (isDarkMode = !isDarkMode)}
                >
                  <SunIcon
                    class="tw:size-5 tw:rotate-0 tw:scale-0 tw:dark:rotate-90 tw:dark:scale-100 tw:transition-all"
                  />
                  <MoonIcon
                    class="tw:absolute tw:size-5 tw:rotate-0 tw:scale-100 tw:dark:rotate-90 tw:dark:scale-0 tw:transition-all"
                  />
                  <span class="tw:sr-only">Toggle theme</span>
                </Button>
              </div>

              <div class="tw:h-full tw:flex tw:items-center tw:gap-1">
                <Separator orientation="vertical" class="tw:mx-1" />

                <!-- Close Button -->
                <Button
                  variant="ghost"
                  size="icon"
                  onclick={() => ($testModalOpen = !$testModalOpen)}
                >
                  <XIcon class="tw:size-5" />
                </Button>
              </div>
            </header>

            <div class="tw:px-4">
              {#if currentPage === "chat"}
                <ChatSettings />
              {:else if currentPage === "memory"}
                <MemorySettings />
              {:else if currentPage === "translation"}
                <TranslationSettings />
              {:else if currentPage === "other"}
                <OtherSettings />
              {:else if currentPage === "cache"}
                <CacheTool />
              {:else if currentPage === "github"}
                <GithubTool />
              {/if}
            </div>
          </div>
        </Sidebar.Provider>
      </div>
    </div>
  </div>
{/if}

<style>
  .tw\:border-border-all,
  .tw\:border-border-all :global(*) {
    border-color: var(--border);
  }

  .tw\:outline-ring\/50-all,
  .tw\:outline-ring\/50-all :global(*) {
    outline-color: var(--ring);
  }

  @supports (color: color-mix(in lab, red, red)) {
    .tw\:outline-ring\/50-all,
    .tw\:outline-ring\/50-all :global(*) {
      outline-color: color-mix(in oklab, var(--ring) 50%, transparent);
    }
  }
</style>
