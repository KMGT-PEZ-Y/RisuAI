import type { LLMDefinition } from "$ts/types";
import { LLM_PROVIDER, LLM_TOKENIZER, LLM_FLAG } from "$ts/types";

export const LLM_DEFINITIONS: LLMDefinition[] = [
  // Google AI

  // Free models
  {
    uniqueId: "gemini-2.0-flash-exp",
    id: "gemini-2.0-flash-exp",
    name: "Gemini 2.0 Flash Exp",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.isFreeModel,
      LLM_FLAG.hasGroundingSearch,
    ],
  },
  {
    uniqueId: "gemini-2.5-pro-exp-03-25",
    id: "gemini-2.5-pro-exp-03-25",
    name: "Gemini 2.5 Pro Exp (03/25)",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isThinkingModel,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.isFreeModel,
      LLM_FLAG.hasGroundingSearch,
    ],
  },

  // Non-free models
  {
    uniqueId: "gemini-1.5-flash-002",
    id: "gemini-1.5-flash-002",
    name: "Gemini 1.5 Flash 002",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [],
  },
  {
    uniqueId: "gemini-1.5-pro-002",
    id: "gemini-1.5-pro-002",
    name: "Gemini 1.5 Pro 002",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [],
  },
  {
    uniqueId: "gemini-2.0-flash-lite-001",
    id: "gemini-2.0-flash-lite-001",
    name: "Gemini 2.0 Flash Lite 001",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [],
  },
  {
    uniqueId: "gemini-2.0-flash-001",
    id: "gemini-2.0-flash-001",
    name: "Gemini 2.0 Flash 001",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [LLM_FLAG.hasGroundingSearch],
  },
  {
    uniqueId: "gemini-2.5-pro-preview-03-25",
    id: "gemini-2.5-pro-preview-03-25",
    name: "Gemini 2.5 Pro Preview (03/25)",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isThinkingModel,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
  },
  {
    uniqueId: "gemini-2.5-flash-preview-04-17",
    id: "gemini-2.5-flash-preview-04-17",
    name: "Gemini 2.5 Flash Preview (04/17)",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.hasThinkingTokens,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
  },
  {
    uniqueId: "gemini-2.5-pro-preview-05-06",
    id: "gemini-2.5-pro-preview-05-06",
    name: "Gemini 2.5 Pro Preview (05/06)",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isThinkingModel,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
  },
  {
    uniqueId: "gemini-2.5-flash-preview-05-20",
    id: "gemini-2.5-flash-preview-05-20",
    name: "Gemini 2.5 Flash Preview (05/20)",
    provider: LLM_PROVIDER.GOOGLEAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.hasThinkingTokens,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
  },

  // Vertex AI

  // Free models
  {
    uniqueId: "vertex-gemini-2.0-flash-exp",
    id: "gemini-2.0-flash-exp",
    name: "Gemini 2.0 Flash Exp",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.isFreeModel,
      LLM_FLAG.hasGroundingSearch,
    ],
    locations: ["us-central1"],
  },
  {
    uniqueId: "vertex-gemini-2.5-pro-exp-03-25",
    id: "gemini-2.5-pro-exp-03-25",
    name: "Gemini 2.5 Pro Exp (03/25)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isThinkingModel,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.isFreeModel,
      LLM_FLAG.hasGroundingSearch,
    ],
    locations: ["global"],
  },

  // Non-free models
  {
    uniqueId: "vertex-gemini-1.5-flash-002",
    id: "gemini-1.5-flash-002",
    name: "Gemini 1.5 Flash 002",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [],
    locations: ["us-west1"],
  },
  {
    uniqueId: "vertex-gemini-1.5-pro-002",
    id: "gemini-1.5-pro-002",
    name: "Gemini 1.5 Pro 002",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [],
    locations: ["us-west1"],
  },
  {
    uniqueId: "vertex-gemini-2.0-flash-lite-001",
    id: "gemini-2.0-flash-lite-001",
    name: "Gemini 2.0 Flash Lite 001",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [],
    locations: ["us-west1"],
  },
  {
    uniqueId: "vertex-gemini-2.0-flash-001",
    id: "gemini-2.0-flash-001",
    name: "Gemini 2.0 Flash 001",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [LLM_FLAG.hasGroundingSearch],
    locations: ["us-west1"],
  },
  {
    uniqueId: "vertex-gemini-2.5-pro-preview-03-25",
    id: "gemini-2.5-pro-preview-03-25",
    name: "Gemini 2.5 Pro Preview (03/25)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isThinkingModel,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
    locations: ["us-central1"],
  },
  {
    uniqueId: "vertex-gemini-2.5-flash-preview-04-17",
    id: "gemini-2.5-flash-preview-04-17",
    name: "Gemini 2.5 Flash Preview (04/17)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.hasThinkingTokens,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
    locations: ["us-central1"],
  },
  {
    uniqueId: "vertex-gemini-2.5-pro-preview-05-06",
    id: "gemini-2.5-pro-preview-05-06",
    name: "Gemini 2.5 Pro Preview (05/06)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.isThinkingModel,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
    locations: ["us-central1"],
  },
  {
    uniqueId: "vertex-gemini-2.5-flash-preview-05-20",
    id: "gemini-2.5-flash-preview-05-20",
    name: "Gemini 2.5 Flash Preview (05/20)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.GEMMA,
    flags: [
      LLM_FLAG.hasThinkingTokens,
      LLM_FLAG.isExperimentalModel,
      LLM_FLAG.hasGroundingSearch,
    ],
    locations: ["us-central1"],
  },

  {
    uniqueId: "claude-3-5-haiku@20241022",
    id: "claude-3-5-haiku@20241022",
    name: "Vertex Claude 3.5 Haiku (2024/10/22)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
    locations: ["us-east5", "europe-west1", "asia-southeast1"],
  },
  {
    uniqueId: "claude-3-5-sonnet@20240620",
    id: "claude-3-5-sonnet@20240620",
    name: "Claude 3.5 Sonnet (2024/06/20)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
    locations: ["us-east5", "europe-west1", "asia-southeast1"],
  },
  {
    uniqueId: "claude-3-5-sonnet-v2@20241022",
    id: "claude-3-5-sonnet-v2@20241022",
    name: "Claude 3.5 Sonnet (2024/10/22)",
    provider: LLM_PROVIDER.VERTEXAI,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
    locations: ["us-east5", "europe-west1", "asia-southeast1"],
  },

  // Anthropic
  {
    uniqueId: "claude-3-haiku-20240307",
    id: "claude-3-haiku-20240307",
    name: "Claude 3 Haiku (2024/03/07)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "claude-3-sonnet-20240229",
    id: "claude-3-sonnet-20240229",
    name: "Claude 3 Sonnet (2024/02/29)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "claude-3-opus-20240229",
    id: "claude-3-opus-20240229",
    name: "Claude 3 Opus (2024/02/29)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "claude-3-5-haiku-20241022",
    id: "claude-3-5-haiku-20241022",
    name: "Claude 3.5 Haiku (2024/10/22)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "claude-3-5-sonnet-20240620",
    id: "claude-3-5-sonnet-20240620",
    name: "Claude 3.5 Sonnet (2024/06/20)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "claude-3-5-sonnet-20241022",
    id: "claude-3-5-sonnet-20241022",
    name: "Claude 3.5 Sonnet (2024/10/22)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "claude-3-7-sonnet-20250219",
    id: "claude-3-7-sonnet-20250219",
    name: "Claude 3.7 Sonnet (2025/02/19)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [LLM_FLAG.hasThinkingTokens],
  },
  {
    uniqueId: "claude-sonnet-4-20250514",
    id: "claude-sonnet-4-20250514",
    name: "Claude 4 Sonnet (2025/05/14)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [LLM_FLAG.hasThinkingTokens],
  },
  {
    uniqueId: "claude-opus-4-20250514",
    id: "claude-opus-4-20250514",
    name: "Claude 4 Opus (2025/05/14)",
    provider: LLM_PROVIDER.ANTHROPIC,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [LLM_FLAG.hasThinkingTokens],
  },

  // Deepseek
  {
    uniqueId: "deepseek-chat",
    id: "deepseek-chat",
    name: "Deepseek Chat",
    provider: LLM_PROVIDER.DEEPSEEK,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [],
  },
  {
    uniqueId: "deepseek-reasoner",
    id: "deepseek-reasoner",
    name: "Deepseek Reasoner",
    provider: LLM_PROVIDER.DEEPSEEK,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [],
  },

  // OpenAI
  {
    uniqueId: "gpt-4o-mini-2024-07-18",
    id: "gpt-4o-mini-2024-07-18",
    name: "GPT-4o Mini (2024/07/18)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasFullSystemPrompt],
  },
  {
    uniqueId: "gpt-4o-2024-05-13",
    id: "gpt-4o-2024-05-13",
    name: "GPT-4o (2024/05/13)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasFullSystemPrompt],
  },
  {
    uniqueId: "gpt-4o-2024-08-06",
    id: "gpt-4o-2024-08-06",
    name: "GPT-4o (2024/08/06)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasFullSystemPrompt],
  },
  {
    uniqueId: "gpt-4o-2024-11-20",
    id: "gpt-4o-2024-11-20",
    name: "GPT-4o (2024/11/20)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasFullSystemPrompt],
  },
  {
    uniqueId: "gpt-4.1-mini-2025-04-14",
    id: "gpt-4.1-mini-2025-04-14",
    name: "GPT-4.1 mini (2025/04/14)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasFullSystemPrompt],
  },
  {
    uniqueId: "gpt-4.1-2025-04-14",
    id: "gpt-4.1-2025-04-14",
    name: "GPT-4.1 (2025/04/14)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasFullSystemPrompt],
  },
  {
    uniqueId: "chatgpt-4o-latest",
    id: "chatgpt-4o-latest",
    name: "ChatGPT-4o (Latest)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasFullSystemPrompt],
  },
  {
    uniqueId: "o1-mini-2024-09-12",
    id: "o1-mini-2024-09-12",
    name: "o1-mini (2024/09/12)",
    provider: LLM_PROVIDER.OPENAI,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [LLM_FLAG.hasMaxCompletionTokens],
  },

  // AWS models
  {
    uniqueId: "anthropic.claude-3-5-haiku-20241022-v1:0",
    id: "anthropic.claude-3-5-haiku-20241022-v1:0",
    name: "Claude 3.5 Haiku (2024/10/22)",
    provider: LLM_PROVIDER.AWS,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "anthropic.claude-3-5-sonnet-20240620-v1:0",
    id: "anthropic.claude-3-5-sonnet-20240620-v1:0",
    name: "Claude 3.5 Sonnet (2024/06/20)",
    provider: LLM_PROVIDER.AWS,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "anthropic.claude-3-5-sonnet-20241022-v2:0",
    id: "anthropic.claude-3-5-sonnet-20241022-v2:0",
    name: "Claude 3.5 Sonnet (2024/10/22)",
    provider: LLM_PROVIDER.AWS,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [],
  },
  {
    uniqueId: "anthropic.claude-3-7-sonnet-20250219-v1:0",
    id: "anthropic.claude-3-7-sonnet-20250219-v1:0",
    name: "Claude 3.7 Sonnet (2025/02/19)",
    provider: LLM_PROVIDER.AWS,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [LLM_FLAG.hasThinkingTokens],
  },
  {
    uniqueId: "anthropic.claude-sonnet-4-20250514-v1:0",
    id: "anthropic.claude-sonnet-4-20250514-v1:0",
    name: "Claude 4 Sonnet (2025/05/14)",
    provider: LLM_PROVIDER.AWS,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [LLM_FLAG.hasThinkingTokens],
  },
  {
    uniqueId: "anthropic.claude-opus-4-20250514-v1:0",
    id: "anthropic.claude-opus-4-20250514-v1:0",
    name: "Claude 4 Opus (2025/05/14)",
    provider: LLM_PROVIDER.AWS,
    tokenizer: LLM_TOKENIZER.CLAUDE,
    flags: [LLM_FLAG.hasThinkingTokens],
  },

  // OpenAICompatible
  {
    uniqueId: "custom",
    id: "custom",
    name: "Custom",
    provider: LLM_PROVIDER.OPENAICOMPATIBLE,
    tokenizer: LLM_TOKENIZER.O200K_BASE,
    flags: [],
  },
] as const;

export function getLLMDefinition(uniqueId: string): LLMDefinition | null {
  const def = LLM_DEFINITIONS.find((e) => e.uniqueId === uniqueId);

  return def ? structuredClone(def) : null;
}

export function groupLLMDefinitionByProvider(): Record<
  string,
  LLMDefinition[]
> {
  return structuredClone(LLM_DEFINITIONS).reduce((acc, def) => {
    const provider = def.provider;

    if (!acc[provider]) {
      acc[provider] = [];
    }

    acc[provider].push(def);
    return acc;
  }, {} as Record<string, LLMDefinition[]>);
}
