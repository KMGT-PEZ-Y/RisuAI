export const PLUGIN_SETTING_TYPE = {
  BOOLEAN: "boolean",
  INTEGER: "integer",
  FLOAT: "float",
  STRING: "string",
} as const;

export type PluginSettingType =
  (typeof PLUGIN_SETTING_TYPE)[keyof typeof PLUGIN_SETTING_TYPE];

export interface PluginSettingOptions {
  default?: boolean | number | string;
  min?: number;
  max?: number;
  candidates?: string[];
  allowNonCandidate?: boolean;
  placeholder?: string;
  useEditor?: boolean;
}

export interface PluginSettingDefinitions {
  [key: string]: {
    category: string[];
    displayName: string;
    type: PluginSettingType;
    options?: PluginSettingOptions;
  };
}

export const PLUGIN_SETTING_DEFINITIONS_BASE: PluginSettingDefinitions = {
  // 공통 설정
  common_googleAIProvider_apiKey: {
    category: ["공통 설정", "구글 스튜디오"],
    displayName: "API 키 (키 회전 지원)",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { placeholder: "KEY1 KEY2 KEY3...", useEditor: true },
  },
  common_fallbackToVertexGemini: {
    category: ["공통 설정", "구글 스튜디오"],
    displayName: "버텍스 제미니로 폴백",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_vertexAIProvider_projectId: {
    category: ["공통 설정", "버텍스"],
    displayName: "프로젝트 ID",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_vertexAIProvider_privateKey: {
    category: ["공통 설정", "버텍스"],
    displayName: "프라이빗 키",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_vertexAIProvider_clientEmail: {
    category: ["공통 설정", "버텍스"],
    displayName: "클라이언트 이메일",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_vertexAIProvider_credentials: {
    category: ["공통 설정", "버텍스"],
    displayName: "JSON 키 파일 (키 회전 지원)",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: {
      placeholder:
        '{ "type": "service_account", ... }, { "type": "service_account", ... }, ...',
      useEditor: true,
    },
  },
  common_anthropicProvider_apiKey: {
    category: ["공통 설정", "엔트로픽"],
    displayName: "API 키",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  chat_claude_useStreaming: {
    category: ["공통 설정", "엔트로픽"],
    displayName: "스트리밍 사용",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_deepseekProvider_apiKey: {
    category: ["공통 설정", "딥식"],
    displayName: "API 키",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_deepseekProvider_customUrl: {
    category: ["공통 설정", "딥식"],
    displayName: "커스텀 URL (프록시용)",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: {
      candidates: [
        "",
        "https://openrouter.ai/api/v1/chat/completions",
        "https://api.fireworks.ai/inference/v1/chat/completions",
        "https://api.together.xyz/v1/chat/completions",
        "https://api.hyperbolic.xyz/v1/chat/completions",
        "https://api.kluster.ai/v1/chat/completions",
        "https://api.featherless.ai/v1/chat/completions",
        "https://chatapi.akash.network/api/v1/chat/completions",
        "https://api.minimaxi.chat/v1/text/chatcompletion_v2",
      ],
      allowNonCandidate: true,
    },
  },
  common_openaiProvider_apiKey: {
    category: ["공통 설정", "오픈AI"],
    displayName: "API 키",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_awsProvider_accessKey: {
    category: ["공통 설정", "AWS"],
    displayName: "액세스 키",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_awsProvider_secretAccessKey: {
    category: ["공통 설정", "AWS"],
    displayName: "비밀 액세스 키",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_awsProvider_region: {
    category: ["공통 설정", "AWS"],
    displayName: "지역",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_openaiCompatibleProvider_url: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "URL",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_openaiCompatibleProvider_apiKey: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "키/패스워드",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_openaiCompatibleProvider_model: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "모델명",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  common_openaiCompatibleProvider_tokenizer: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "토크나이저 (새로고침 필요)",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { candidates: [] },
  },
  common_openaiCompatibleProvider_useStreaming: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "스트리밍 사용",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_openaiCompatibleProvider_hasFirstSystemPrompt: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "hasFirstSystemPrompt",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_openaiCompatibleProvider_requiresAlternateRole: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "requiresAlternateRole",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_openaiCompatibleProvider_mustStartWithUserInput: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "mustStartWithUserInput",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_openaiCompatibleProvider_useMaxOutputTokensInstead: {
    category: ["공통 설정", "커스텀 (OpenAI 호환)"],
    displayName: "max_output_tokens 사용",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_previewPrompt: {
    category: ["공통 설정"],
    displayName: "프롬프트 미리보기",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_useEditorForInputBox: {
    category: ["공통 설정"],
    displayName: "입력 시 편집기 사용",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_gemini_blockPaidModel: {
    category: ["공통 설정", "제미니 설정"],
    displayName: "유료 모델 차단",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  common_gemini_showThoughts: {
    category: ["공통 설정", "제미니 설정"],
    displayName: "자체 추론 표시",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },

  // 채팅 설정
  chat_claude_caching: {
    category: ["채팅 설정", "클로드 설정"],
    displayName: "캐싱 사용",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_claude_cachingBreakpoints: {
    category: ["채팅 설정", "클로드 설정"],
    displayName: "캐싱 브레이크 포인트",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { placeholder: "u[-1] u[-2] u[-3] u[-4]" },
  },
  chat_claude_cachingMaxExtension: {
    category: ["채팅 설정", "클로드 설정"],
    displayName: "캐싱 최대 연장 횟수 (끄기: 0)",
    type: PLUGIN_SETTING_TYPE.INTEGER,
    options: { placeholder: "3" },
  },
  chat_claude_useExperimentalCachingExtension: {
    category: ["채팅 설정", "클로드 설정"],
    displayName: "캐싱 연장 시 입력 토큰 절약",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_claude_useSilentCachingExtension: {
    category: ["채팅 설정", "클로드 설정"],
    displayName: "조용한 캐싱 연장 사용",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_gemini_preserveSystem: {
    category: ["채팅 설정", "제미니 설정"],
    displayName: "시스템 프롬프트 보존",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_gemini_removeForeignLanguage: {
    category: ["채팅 설정", "제미니 설정"],
    displayName: "외국어 제거 시도 (한챗용)",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_gemini_separateCot: {
    category: ["채팅 설정", "제미니 설정"],
    displayName: "생각의 사슬 분리 시도 (추론모델용)",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_gemini_useGroundingSearch: {
    category: ["채팅 설정", "제미니 설정"],
    displayName: "그라운딩 검색 사용",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_gemini_showThoughtsToken: {
    category: ["채팅 설정", "제미니 설정"],
    displayName: "생각 토큰 알림",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_gemini_usePlainFetch: {
    category: ["채팅 설정", "제미니 설정"],
    displayName: "직접 요청 보내기",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_removeStartANewChat: {
    category: ["채팅 설정"],
    displayName: "[Start a new chat] 제거",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  chat_autoClickTranslateButton: {
    category: ["채팅 설정"],
    displayName: "캐릭터 메시지 자동 번역 (Ctrl+Alt+Shfit+T)",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },

  // 채팅 샘플링 설정
  chat_sampling_temperature: {
    category: ["채팅 설정", "샘플링 설정"],
    displayName: "온도",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  chat_sampling_topP: {
    category: ["채팅 설정", "샘플링 설정"],
    displayName: "Top P",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  chat_sampling_topK: {
    category: ["채팅 설정", "샘플링 설정"],
    displayName: "Top K",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  chat_sampling_frequencyPenalty: {
    category: ["채팅 설정", "샘플링 설정"],
    displayName: "빈도 패널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  chat_sampling_presencePenalty: {
    category: ["채팅 설정", "샘플링 설정"],
    displayName: "프리센스 패널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  chat_sampling_thinkingTokens: {
    category: ["채팅 설정", "샘플링 설정"],
    displayName: "생각 토큰",
    type: PLUGIN_SETTING_TYPE.INTEGER,
    options: { min: 0 },
  },
  chat_sampling_stopSequences: {
    category: ["채팅 설정", "샘플링 설정"],
    displayName: "정지 시퀀스",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { placeholder: "Enter 키로 구분", useEditor: true },
  },

  // 감정/하이파 설정
  hypa_model: {
    category: ["감정/하이파 설정"],
    displayName: "모델",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { candidates: [] },
  },
  hypa_prefill: {
    category: ["감정/하이파 설정"],
    displayName: "프리필 (ChatML 프롬이 아닌 경우)",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  hypa_usePlainFetch: {
    category: ["감정/하이파 설정"],
    displayName: "직접 요청 보내기",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },

  // 감정/하이파 샘플링 설정
  hypa_sampling_maxTokens: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "최대 응답 크기",
    type: PLUGIN_SETTING_TYPE.INTEGER,
    options: { min: 1 },
  },
  hypa_sampling_temperature: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "온도",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  hypa_sampling_topP: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "Top P",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  hypa_sampling_topK: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "Top K",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  hypa_sampling_frequencyPenalty: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "빈도 패널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  hypa_sampling_presencePenalty: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "프리센스 패널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  hypa_sampling_thinkingTokens: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "생각 토큰",
    type: PLUGIN_SETTING_TYPE.INTEGER,
    options: { min: 0 },
  },
  hypa_sampling_stopSequences: {
    category: ["감정/하이파 설정", "샘플링 설정"],
    displayName: "정지 시퀀스",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { placeholder: "Enter 키로 구분", useEditor: true },
  },

  // 번역 설정
  translation_model: {
    category: ["번역 설정"],
    displayName: "모델",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { candidates: [] },
  },
  translation_prefill: {
    category: ["번역 설정"],
    displayName: "프리필 (ChatML 프롬이 아닌 경우)",
    type: PLUGIN_SETTING_TYPE.STRING,
  },
  translation_showOriginal: {
    category: ["번역 설정"],
    displayName: "원문 번역문 병행 표시 (JSON 번역 필요)",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  translation_removeThoughts: {
    category: ["번역 설정"],
    displayName: "생각의 사슬 제거하고 번역",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  translation_saveToTranslatorNote: {
    category: ["번역 설정"],
    displayName: "번역가의 노트에 저장",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
  translation_usePlainFetch: {
    category: ["번역 설정"],
    displayName: "직접 요청 보내기",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },

  // 번역 샘플링 설정
  translation_sampling_temperature: {
    category: ["번역 설정", "샘플링 설정"],
    displayName: "온도",
    type: PLUGIN_SETTING_TYPE.FLOAT,
    options: { placeholder: "0" },
  },
  translation_sampling_topP: {
    category: ["번역 설정", "샘플링 설정"],
    displayName: "Top P",
    type: PLUGIN_SETTING_TYPE.FLOAT,
    options: { placeholder: "0.9" },
  },
  translation_sampling_topK: {
    category: ["번역 설정", "샘플링 설정"],
    displayName: "Top K",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  translation_sampling_frequencyPenalty: {
    category: ["번역 설정", "샘플링 설정"],
    displayName: "빈도 페널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
    options: { placeholder: "0" },
  },
  translation_sampling_presencePenalty: {
    category: ["번역 설정", "샘플링 설정"],
    displayName: "프리센스 패널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
    options: { placeholder: "0" },
  },
  translation_sampling_thinkingTokens: {
    category: ["번역 설정", "샘플링 설정"],
    displayName: "생각 토큰",
    type: PLUGIN_SETTING_TYPE.INTEGER,
    options: { min: 0 },
  },
  translation_sampling_stopSequences: {
    category: ["번역 설정", "샘플링 설정"],
    displayName: "정지 시퀀스",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { placeholder: "Enter 키로 구분", useEditor: true },
  },

  // 기타 설정
  other_model: {
    category: ["루아/트리거 설정"],
    displayName: "모델",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { candidates: [] },
  },
  other_usePlainFetch: {
    category: ["루아/트리거 설정"],
    displayName: "직접 요청 보내기",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },

  // 기타 샘플링 설정
  other_sampling_maxTokens: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "최대 응답 크기",
    type: PLUGIN_SETTING_TYPE.INTEGER,
    options: { min: 1 },
  },
  other_sampling_temperature: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "온도",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  other_sampling_topP: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "Top P",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  other_sampling_topK: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "Top K",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  other_sampling_frequencyPenalty: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "빈도 패널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  other_sampling_presencePenalty: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "프리센스 패널티",
    type: PLUGIN_SETTING_TYPE.FLOAT,
  },
  other_sampling_thinkingTokens: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "생각 토큰",
    type: PLUGIN_SETTING_TYPE.INTEGER,
    options: { min: 0 },
  },
  other_sampling_stopSequences: {
    category: ["루아/트리거 설정", "샘플링 설정"],
    displayName: "정지 시퀀스",
    type: PLUGIN_SETTING_TYPE.STRING,
    options: { placeholder: "Enter 키로 구분", useEditor: true },
  },

  // 도구 설정
  tools_githubCopilotToken: {
    category: ["도구"],
    displayName: "GitHub Copilot 토큰",
    type: PLUGIN_SETTING_TYPE.STRING,
  },

  // 호환성 설정
  compatibility_doNotSetTokenizer: {
    category: ["호환성"],
    displayName: "토크나이저 설정 안 함 (새로고침 필요)",
    type: PLUGIN_SETTING_TYPE.BOOLEAN,
  },
} as const;
