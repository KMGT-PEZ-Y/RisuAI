import { writable } from "svelte/store";

export const DBState = $state({
  db: {},
});

export const testModalOpen = writable(false);
