import { PLUGIN_NAME, getChatSettings } from "$ts/pluginSetting";
import { Utils } from "$ts/utils";

export class PluginTextEditorUI {
  public static showModal(
    title: string,
    content: string,
    wordWrap: boolean = true
  ): Promise<{ confirmed: boolean; value?: string }> {
    return new Promise((resolve) => {
      const modal = document.createElement("div");
      modal.className = "fixed inset-0 z-50 p-1 sm:p-2 bg-black/50";
      modal.tabIndex = -1;
      modal.innerHTML = `
        <div class="flex justify-center w-full h-full">
          <div class="flex flex-col p-3 sm:p-6 rounded-lg bg-zinc-900 w-full max-w-3xl h-full">
            <!-- Header -->
            <div class="flex justify-between items-center w-full mb-4">
              <h2 class="text-zinc-100 text-2xl font-semibold">${Utils.escapeHTML(
                title
              )}</h2>
            </div>

            <!-- Text Area -->
            <div class="flex-1 overflow-hidden min-h-0 mb-4">
              <textarea class="w-full h-full resize-none overflow-auto px-3 py-2 rounded border border-zinc-700 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-zinc-800 text-zinc-200" wrap="${
                wordWrap ? "soft" : "off"
              }">${Utils.escapeHTML(content)}</textarea>
            </div>

            <!-- Buttons -->
            <div class="flex justify-end mt-4 pt-2 gap-2 border-t border-zinc-700">
              <button class="px-4 py-2 rounded bg-zinc-800 hover:bg-red-500 text-zinc-200 transition-colors">취소</button>
              <button class="px-4 py-2 rounded bg-zinc-800 hover:bg-blue-500 text-zinc-200 transition-colors">저장</button>
            </div>
          </div>
        </div>
      `;

      this.bindEvents(modal, resolve);
      document.body.appendChild(modal);

      const textarea = modal.querySelector("textarea") as HTMLTextAreaElement;
      textarea.focus();
    });
  }

  private static bindEvents(
    modal: HTMLElement,
    resolve: (value: { confirmed: boolean; value?: string }) => void
  ): void {
    const textarea = modal.querySelector("textarea") as HTMLTextAreaElement;
    const cancelButton = modal.querySelectorAll("button")[0];
    const saveButton = modal.querySelectorAll("button")[1];

    modal.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        resolve({ confirmed: false });
        modal.remove();
      }
    });

    cancelButton?.addEventListener("click", () => {
      resolve({ confirmed: false });
      modal.remove();
    });

    saveButton?.addEventListener("click", () => {
      resolve({ confirmed: true, value: textarea.value });
      modal.remove();
    });
  }
}

export class PluginToastUI {
  private static toastEl: HTMLElement | null;
  private static timeout: number;

  public static show(message: string, ttl: number): void {
    PluginToastUI.hide();

    const toastEl = document.createElement("div");
    toastEl.style.zIndex = "10000";
    toastEl.style.position = "fixed";
    toastEl.style.bottom = "16px";
    toastEl.style.right = "16px";
    toastEl.style.padding = "12px";
    toastEl.style.borderRadius = "4px";
    toastEl.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
    toastEl.style.color = "rgb(255, 255, 255)";
    toastEl.style.fontWeight = "bold";
    toastEl.textContent = message;

    document.body.appendChild(toastEl);

    PluginToastUI.toastEl = toastEl;

    PluginToastUI.timeout = window.setTimeout(() => {
      PluginToastUI.hide();
    }, ttl);
  }

  public static hide(): void {
    if (!PluginToastUI.toastEl) return;

    window.clearTimeout(PluginToastUI.timeout);

    PluginToastUI.toastEl.remove();
    PluginToastUI.toastEl = null;
  }
}

export class PluginTimerUI {
  private static readonly ID: string = `${PLUGIN_NAME}-pluginTimerUI`;

  private static timeout: number;
  private static startTime: number;

  public static start(onTimeout: () => Promise<void>, duration: number): void {
    // Clear the state
    PluginTimerUI.stop();
    PluginTimerUI.startTime = Date.now();

    const checkAndRun = async () => {
      const element = PluginTimerUI.createGetElement();
      const currentTime = Date.now();
      const elapsedSeconds = Math.floor(
        (currentTime - PluginTimerUI.startTime) / 1000
      );
      const remainingSeconds = Math.max(0, duration - elapsedSeconds);

      // Update display
      if (element) {
        element.textContent = PluginTimerUI.formatTime(remainingSeconds);
      }

      // When time runs out, remove the timer and raise timeout event
      if (remainingSeconds === 0) {
        element?.remove();
        await onTimeout();

        return;
      }

      PluginTimerUI.timeout = window.setTimeout(checkAndRun, 1000);
    };

    PluginTimerUI.timeout = window.setTimeout(checkAndRun, 0);
  }

  public static stop(): void {
    window.clearTimeout(PluginTimerUI.timeout);

    const element = document.getElementById(PluginTimerUI.ID);

    if (element) {
      element.remove();
    }
  }

  private static createGetElement(): HTMLElement | null {
    const chatSettings = getChatSettings();
    const opactiy = chatSettings.claude_useSilentCachingExtension ? "0" : "0.1";
    let element = document.getElementById(PluginTimerUI.ID);

    if (!element) {
      // Find menu button with three lines
      const menuButton = document.querySelector(
        "button.peer-focus\\:border-textcolor.mr-2"
      );

      if (!menuButton || !menuButton.parentElement) {
        return null;
      }

      // Create a timer element if it doesn't exist
      element = document.createElement("div");
      element.id = PluginTimerUI.ID;
      element.style.width = "64px";
      element.style.height = "64px";
      element.style.backgroundColor = "rgb(30, 30, 30)";
      element.style.color = "rgb(200, 200, 200)";
      element.style.borderRadius = "8px";
      element.style.display = "flex";
      element.style.alignItems = "center";
      element.style.justifyContent = "center";
      element.style.fontFamily = "monospace";
      element.style.fontSize = "14px";
      element.style.zIndex = "10000";
      element.style.position = "absolute"; // Set absolute position
      element.style.bottom = "100%"; // Position right above the button
      element.style.right = "10px"; // Align to the right
      element.style.marginBottom = "10px"; // Add some spacing
      element.style.opacity = opactiy; // Set default opacity

      // Add mouse hover events
      element.addEventListener("mouseenter", () => {
        if (element) {
          element.style.opacity = "1"; // Make fully visible on hover
        }
      });

      element.addEventListener("mouseleave", () => {
        if (element) {
          element!.style.opacity = opactiy; // Return to original opacity when mouse leaves
        }
      });

      // Add double click event listener
      element.addEventListener("dblclick", () => {
        PluginTimerUI.stop();
      });

      // Set parent container to relative positioning and append timer
      menuButton.parentElement.style.position = "relative";
      menuButton.parentElement.appendChild(element);
    }

    return element;
  }

  private static formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    return `${String(minutes).padStart(2, "0")}:${String(
      remainingSeconds
    ).padStart(2, "0")}`;
  }
}
