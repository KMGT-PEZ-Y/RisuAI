import type { PluginV2ProviderArgument } from "$risu/plugins/plugins";
import { risuAPI } from "$risu/plugins/plugins";
import type {
  GlobalFetchArgs,
  GlobalFetchResult,
} from "$risu/globalApi.svelte";
import { BaseProvider } from "$ts/providers/baseProvider";
import { Logger } from "$ts/logger";
import {
  risuFetchEx,
  getCommonSettings,
  getChatSettings,
} from "$ts/pluginSetting";
import type { LLMRole, LLMNonSystemRole, LLMDefinition } from "$ts/types";
import { LLM_ROLE, LLM_FLAG, REQUEST_TYPE } from "$ts/types";
import { PluginTextEditorUI, PluginToastUI, PluginTimerUI } from "$ts/ui";
import { Utils } from "$ts/utils";

export interface ClaudeBody {
  model?: string;
  anthropic_version?: string;
  messages: ClaudeBodyMessage[];
  system?: ClaudeBodyContent[];
  max_tokens: number;
  temperature?: number;
  top_p?: number;
  top_k?: number;
  thinking?: {
    type: "enabled";
    budget_tokens: number;
  };
  stream?: boolean;
}

export interface ClaudeBodyMessage {
  role: LLMNonSystemRole;
  content: ClaudeBodyContent[];
}

export interface ClaudeBodyContent {
  type: "text" | "thinking" | "redacted_thinking";
  text: string;
  cache_control?: { type: "ephemeral" };
  thinking?: string;
  signature?: string;
  data?: string;
}

export class AnthropicProvider extends BaseProvider {
  private readonly apiKey: string;

  public constructor(apiKey: string) {
    super();
    this.apiKey = apiKey;
  }

  public static validateApiParameters(body: ClaudeBody): void {
    if (body.thinking) {
      // Remove sampling parameters
      delete body.temperature;
      delete body.top_p;
      delete body.top_k;

      // Remove prefills
      while (
        body.messages.length > 0 &&
        body.messages.at(-1)?.role === LLM_ROLE.ASSISTANT
      ) {
        body.messages.pop();
      }

      return;
    }

    if (body.max_tokens > 8192) {
      body.max_tokens = 8192;
    }

    if (
      body.temperature != null &&
      (body.temperature < 0 || body.temperature > 1)
    ) {
      body.temperature = 1;
    }

    if (body.top_p != null && (body.top_p < 0 || body.top_p > 1)) {
      delete body.top_p;
    }

    if (
      body.top_k != null &&
      (!Number.isInteger(body.top_k) || body.top_k < 1)
    ) {
      delete body.top_k;
    }
  }

  public static parseContent(
    pluginRequest: PluginV2ProviderArgument,
    response: GlobalFetchResult
  ): string {
    const contents: ClaudeBodyContent[] = response?.data?.content;

    if (!contents) {
      Logger.warn("No content field in response");
      throw new Error(JSON.stringify(response.data));
    }

    const reasoningParts = contents.filter(
      (content) =>
        content.type === "thinking" || content.type === "redacted_thinking"
    );
    const contentParts = contents.filter((content) => content.type === "text");
    let parsed = "";

    if (contentParts.length === 0) {
      Logger.error("No text field in response");
      throw new Error(JSON.stringify(response.data));
    }

    switch (Utils.getRequestType(pluginRequest)) {
      case REQUEST_TYPE.CHAT: {
        if (reasoningParts.length > 0) {
          parsed += `<Thoughts>\n\n${reasoningParts
            .map((content) => {
              if (content.type === "thinking") {
                return content.thinking;
              } else {
                return "[REDACTED]";
              }
            })
            .join("\n\n")}\n</Thoughts>\n\n`;
        }

        parsed += contentParts.map((content) => content.text).join("\n\n");
        break;
      }

      case REQUEST_TYPE.TRANSLATION: {
        if (reasoningParts.length > 0) {
          // Translation should return <details> tag instead of <Thoughts> tag,
          // and a line break (\n\n) should follow the </summary> tag
          // to ensure proper markdown formatting
          parsed += `<details><summary>생각의 사슬</summary>\n\n${reasoningParts
            .map((content) => {
              if (content.type === "thinking") {
                return content.thinking;
              } else {
                return "[REDACTED]";
              }
            })
            .join("\n\n")}</details>\n\n`;
        }

        parsed += contentParts.map((content) => content.text).join("\n\n");
        break;
      }

      default: {
        parsed += contentParts.map((content) => content.text).join("\n\n");
        break;
      }
    }

    return parsed;
  }

  public static getCachingDuration(requestTime: number): number {
    return Math.floor(280 - (Date.now() - requestTime) / 1000);
  }

  public static async onCachingTimeout(
    extendFunc: () => Promise<number>,
    currentExtension: number
  ): Promise<void> {
    const chatSettings = getChatSettings();
    const maxRetry = 2;
    let currentRetry = 0;
    let requestTime = -1;

    while (true) {
      if (!chatSettings.claude_useSilentCachingExtension) {
        PluginToastUI.show(`캐싱 연장하는 중`, 3000);
      }

      requestTime = Date.now();

      const cacheRead = await extendFunc();

      if (cacheRead > 0) {
        break;
      } else if (cacheRead === 0) {
        if (!chatSettings.claude_useSilentCachingExtension) {
          window.alert(
            "읽은 캐시가 없습니다. 탭을 비활성화하면 캐시가 만료될 수 있습니다."
          );
        }

        return;
      } else if (cacheRead === -1) {
        if (currentRetry >= maxRetry) {
          // The maximum number of retries has been reached
          if (!chatSettings.claude_useSilentCachingExtension) {
            PluginToastUI.show(`캐싱 연장 실패함`, 3000);
          }

          return;
        }

        if (!chatSettings.claude_useSilentCachingExtension) {
          PluginToastUI.show(
            `3초 후 캐싱 연장 재시도 (${currentRetry + 1})`,
            3000
          );
        }

        // Sleep 3 seconds
        await Utils.sleep(3000);

        currentRetry += 1;
      }
    }

    currentExtension++;

    // Restart timer
    if (currentExtension < chatSettings.claude_cachingMaxExtension) {
      const duration = AnthropicProvider.getCachingDuration(requestTime);

      if (duration > 30) {
        const onTimeout = async () =>
          await AnthropicProvider.onCachingTimeout(
            extendFunc,
            currentExtension
          );

        PluginTimerUI.start(onTimeout, duration);
      } else {
        if (!chatSettings.claude_useSilentCachingExtension) {
          PluginToastUI.show(
            `남은 캐싱 유효 기간이 ${duration}초에 불과함`,
            3000
          );
        }
      }
    }
  }

  public static isExtendedThinking(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): boolean {
    return (
      modelDef.flags.includes(LLM_FLAG.hasThinkingTokens) &&
      Number.isInteger(pluginRequest.thinking_tokens) &&
      pluginRequest.thinking_tokens >= 1024
    );
  }

  private static buildClaudeBody(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): ClaudeBody {
    const commonSettings = getCommonSettings();
    const chatSettings = getChatSettings();
    const requestType = Utils.getRequestType(pluginRequest);
    const isCachePointAvailable = AnthropicProvider.isCachePointAvailable(
      pluginRequest,
      modelDef
    );
    const openAIChats = structuredClone(pluginRequest.prompt_chat);

    // Find the index where the first 'user' or 'assistant' role appears
    let splitIndex = openAIChats.findIndex(
      (message) =>
        message.role === LLM_ROLE.USER || message.role === LLM_ROLE.ASSISTANT
    );

    // If no 'user' or 'assistant' role is found, set splitIndex to the length of the array
    if (splitIndex === -1) {
      splitIndex = openAIChats.length;
    }

    // Extract the beginning consecutive system messages and join content of the system messages using '\n\n'
    const system: ClaudeBodyContent = {
      type: "text",
      text: "",
    };

    for (let i = 0; i < splitIndex; i++) {
      const message = openAIChats[i];
      const trimmedContent = message.content.trim();

      if (system.text) {
        system.text += "\n\n";
      }

      system.text += trimmedContent;

      if (isCachePointAvailable && message.cachePoint) {
        system.cache_control = { type: "ephemeral" };
      }
    }

    // Remove the system messages from the original array
    openAIChats.splice(0, splitIndex);

    // Ensure the first message is the user message
    if (openAIChats.length === 0 || openAIChats[0].role !== LLM_ROLE.USER) {
      openAIChats.unshift({ role: LLM_ROLE.USER, content: "Start" });
    }

    // Build messages
    const messages: ClaudeBodyMessage[] = [];

    for (let i = 0; i < openAIChats.length; i++) {
      const message = openAIChats[i];
      const trimedContent = message.content.trim();
      const lastMessage =
        messages.length > 0 ? messages[messages.length - 1] : null;

      if (message.role === LLM_ROLE.SYSTEM) {
        if (lastMessage?.role === LLM_ROLE.USER) {
          messages[messages.length - 1].content[0].text +=
            "\n\nsystem: " + trimedContent;

          if (isCachePointAvailable && message.cachePoint) {
            messages[messages.length - 1].content[0].cache_control = {
              type: "ephemeral",
            };
          }
        } else {
          const newMessage: ClaudeBodyMessage = {
            role: LLM_ROLE.USER,
            content: [
              {
                type: "text",
                text: "system: " + trimedContent,
              },
            ],
          };

          if (isCachePointAvailable && message.cachePoint) {
            newMessage.content[0].cache_control = {
              type: "ephemeral",
            };
          }

          messages.push(newMessage);
        }
      } else if (
        message.role === LLM_ROLE.USER ||
        message.role === LLM_ROLE.ASSISTANT
      ) {
        if (lastMessage?.role === message.role) {
          messages[messages.length - 1].content[0].text +=
            "\n\n" + trimedContent;

          if (isCachePointAvailable && message.cachePoint) {
            messages[messages.length - 1].content[0].cache_control = {
              type: "ephemeral",
            };
          }
        } else {
          const newMessage: ClaudeBodyMessage = {
            role: message.role,
            content: [
              {
                type: "text",
                text: trimedContent,
              },
            ],
          };

          if (isCachePointAvailable && message.cachePoint) {
            newMessage.content[0].cache_control = {
              type: "ephemeral",
            };
          }

          messages.push(newMessage);
        }
      }
    }

    // Build body
    const body: ClaudeBody = {
      model: modelDef.id,
      ...(system.text !== "" && {
        system: [system],
      }),
      messages: messages,
      max_tokens: pluginRequest.max_tokens,
      ...(pluginRequest.temperature != null && {
        temperature: pluginRequest.temperature,
      }),
      ...(pluginRequest.top_p != null && { top_p: pluginRequest.top_p }),
      ...(pluginRequest.top_k != null && { top_k: pluginRequest.top_k }),
    };

    // Extended thinking
    if (AnthropicProvider.isExtendedThinking(pluginRequest, modelDef)) {
      body.thinking = {
        type: "enabled",
        budget_tokens: pluginRequest.thinking_tokens,
      };
    }

    // Prompt caching
    if (
      chatSettings.claude_caching &&
      requestType === REQUEST_TYPE.CHAT &&
      !isCachePointAvailable
    ) {
      if (
        AnthropicProvider.isExtendedThinking(pluginRequest, modelDef) &&
        chatSettings.claude_cachingMaxExtension > 0 &&
        chatSettings.claude_cachingBreakpoints !== "s"
      ) {
        // Changes to the thinking budget invalidate cached prompt prefixes that include messages.
        // However, cached system prompts and tool definitions will continue to work when thinking parameters change.
        AnthropicProvider.applyClaudeCaching("s", body);

        PluginToastUI.show("커스텀 브레이크 포인트가 s로 수정됨", 2000);
      } else {
        AnthropicProvider.applyClaudeCaching(
          chatSettings.claude_cachingBreakpoints,
          body
        );
      }
    }

    // Validate api parameters
    AnthropicProvider.validateApiParameters(body);

    // Preview prompt
    if (
      commonSettings.previewPrompt &&
      (requestType === REQUEST_TYPE.CHAT ||
        requestType === REQUEST_TYPE.TRANSLATION)
    ) {
      const bodyCloned = structuredClone(body);

      for (let i = 0; i < bodyCloned.messages.length; i++) {
        const message = bodyCloned.messages[i];
        const sameRoleMessages = bodyCloned.messages.filter(
          (v) => v.role === message.role
        );
        const reverseIndex = -(
          sameRoleMessages.length - sameRoleMessages.indexOf(message)
        );

        message.role = `${message.role}[${reverseIndex}]` as LLMNonSystemRole;
      }

      PluginTextEditorUI.showModal(
        "프롬프트 미리보기",
        JSON.stringify(bodyCloned, null, 2)
      );

      throw new Error(
        "Sending chat is interrupted because 'preview prompt' option is turned on."
      );
    }

    return body;
  }

  private static isCachePointAvailable(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): boolean {
    const chatSettings = getChatSettings();
    const requestType = Utils.getRequestType(pluginRequest);

    if (!chatSettings.claude_caching || requestType !== REQUEST_TYPE.CHAT) {
      return false;
    }

    if (
      AnthropicProvider.isExtendedThinking(pluginRequest, modelDef) &&
      chatSettings.claude_cachingMaxExtension > 0
    ) {
      return false;
    }

    return pluginRequest.prompt_chat.some((message) => message.cachePoint);
  }

  private static applyClaudeCaching(str: string, body: ClaudeBody): void {
    function findMessageIndex(
      messages: ClaudeBodyMessage[],
      role: LLMRole,
      count: number
    ): number {
      let roleCount = 0;

      for (let i = 0; i < messages.length; i++) {
        if (messages[i].role === role) {
          roleCount++;

          if (roleCount === count) {
            return i;
          }
        }
      }

      return -1;
    }

    function findLastMessageIndex(
      messages: ClaudeBodyMessage[],
      role: LLMRole,
      count: number
    ): number {
      let roleCount = 0;

      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].role === role) {
          roleCount++;

          if (roleCount === count) {
            return i;
          }
        }
      }

      return -1;
    }

    const breakpoints = str.split(/\s+/);

    if (breakpoints.length > 4) {
      throw new Error(
        `Maximum number of breakpoints is 4: ${breakpoints.length}`
      );
    }

    const codeRoleMap = {
      s: LLM_ROLE.SYSTEM,
      u: LLM_ROLE.USER,
      a: LLM_ROLE.ASSISTANT,
    } as const;

    type Code = keyof typeof codeRoleMap;

    breakpoints.forEach((breakpoint) => {
      const match = breakpoint.match(/^([sua]+)(?:\[(\-?\d+)\])?$/);

      if (!match) {
        throw new Error("Invalid breakpoint format");
      }

      const code = match[1] as Code;
      const role = codeRoleMap[code];

      if (!role) {
        throw new Error(`Unknown role: ${code}`);
      }

      const indexStr = match[2];
      const index = parseInt(indexStr, 10);

      if (role !== LLM_ROLE.SYSTEM && Number.isNaN(index)) {
        throw new Error(`Missing index for role: ${role}`);
      }

      if (role === LLM_ROLE.SYSTEM && body.system && body.system.length > 0) {
        body.system[0].cache_control = { type: "ephemeral" };
      } else if (body.messages) {
        const targetIndex =
          index < 0
            ? findLastMessageIndex(body.messages, role, Math.abs(index))
            : findMessageIndex(body.messages, role, index + 1);

        if (targetIndex !== -1) {
          body.messages[targetIndex].content[0].cache_control = {
            type: "ephemeral",
          };
        }
      }
    });
  }

  public async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    const chatSettings = getChatSettings();

    const url = `https://api.anthropic.com/v1/messages`;

    const jsonBody = AnthropicProvider.buildClaudeBody(pluginRequest, modelDef);

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
        "anthropic-dangerous-direct-browser-access": "true",
        "anthropic-beta": "prompt-caching-2024-07-31",
      },
      body: jsonBody,
      rawResponse: false,
    };

    Logger.info("Calling Anthropic with model:", modelDef.id);
    const requestTime = Date.now();
    const response = await risuFetchEx(pluginRequest, url, fetchArgs);

    if (!response.ok) {
      throw new Error(JSON.stringify(response.data));
    }

    const modelContent = AnthropicProvider.parseContent(
      pluginRequest,
      response
    );

    const usage = response?.data?.usage;
    const cacheWrite = usage?.cache_creation_input_tokens;
    const cacheRead = usage?.cache_read_input_tokens;
    const outputTokens = usage?.output_tokens;

    if (Number.isInteger(cacheWrite)) {
      Logger.info(
        `cacheWrite: ${cacheWrite}, cacheRead: ${cacheRead}, outputTokens: ${outputTokens}`
      );
    }

    // Extend caching when cache read/write
    if (
      chatSettings.claude_cachingMaxExtension > 0 &&
      (cacheWrite !== 0 || cacheRead !== 0)
    ) {
      const duration = AnthropicProvider.getCachingDuration(requestTime);

      if (duration > 30) {
        const onTimeout = async () =>
          await AnthropicProvider.onCachingTimeout(
            async () => await this.extendCaching(pluginRequest, modelDef),
            0
          );

        PluginTimerUI.start(onTimeout, duration);
      } else {
        if (!chatSettings.claude_useSilentCachingExtension) {
          PluginToastUI.show(
            `남은 캐싱 유효 기간이 ${duration}초에 불과함`,
            3000
          );
        }
      }
    }

    return modelContent;
  }

  public async getStreamedResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<ReadableStream<string>> {
    const chatSettings = getChatSettings();

    const url = `https://api.anthropic.com/v1/messages`;

    const jsonBody = AnthropicProvider.buildClaudeBody(pluginRequest, modelDef);

    jsonBody.stream = true;

    const fetchArgs = {
      headers: {
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
        "anthropic-dangerous-direct-browser-access": "true",
        "anthropic-beta": "prompt-caching-2024-07-31",
      },
      body: JSON.stringify(jsonBody),
    };

    Logger.info("Calling Anthropic with model:", modelDef.id);
    const requestTime = Date.now();
    const response = await risuAPI.nativeFetch(url, fetchArgs);

    if (response.status !== 200) {
      throw new Error(await new Response(response.body).text());
    }

    const provider = this;
    let thinking = false;
    let usage: any = null;

    const stream = new ReadableStream<string>({
      async start(controller) {
        const reader = response.body!.getReader();
        const decoder = new TextDecoder();
        const prefix = "data: ";
        const parseLine = async (line: string) => {
          try {
            const parsed = JSON.parse(line);
            let deltaText = "";

            switch (parsed?.type) {
              case "message_start": {
                usage = parsed.message?.usage;

                break;
              }

              case "content_block_delta": {
                if (
                  parsed.delta?.type === "thinking" ||
                  parsed.delta?.type === "thinking_delta"
                ) {
                  if (!parsed.delta.thinking) {
                    break;
                  }

                  if (!thinking) {
                    thinking = true;
                    deltaText += "<Thoughts>\n\n";
                  }

                  deltaText += parsed.delta.thinking;
                }

                if (parsed.delta?.type === "redacted_thinking") {
                  if (!thinking) {
                    thinking = true;
                    deltaText += "<Thoughts>\n";
                  }

                  deltaText += "\n[REDACTED]\n";
                }

                if (
                  parsed.delta?.type === "text" ||
                  parsed.delta?.type === "text_delta"
                ) {
                  if (!parsed.delta.text) {
                    break;
                  }

                  if (thinking) {
                    thinking = false;
                    deltaText += "\n</Thoughts>\n\n";
                  }

                  deltaText += parsed.delta?.text;
                }

                break;
              }

              case "error": {
                deltaText += "\nError: " + parsed.error?.message;
                +"\n";

                break;
              }
            }

            return deltaText;
          } catch (error) {}
        };
        let buffer = "";
        let i = 0;

        while (true) {
          try {
            const { value, done } = await reader.read();

            if (done) {
              break;
            }

            buffer += decoder.decode(value);

            const lines = buffer.split("\n");

            for (; i < lines.length - 1; i++) {
              const line = lines[i];

              if (line.startsWith(prefix)) {
                const deltaText = await parseLine(line.slice(prefix.length));

                if (deltaText) {
                  controller.enqueue(deltaText);
                }
              }
            }
          } catch (error) {
            throw error;
          }
        }

        controller.close();

        const cacheWrite = usage?.cache_creation_input_tokens;
        const cacheRead = usage?.cache_read_input_tokens;
        const outputTokens = usage?.output_tokens;

        if (Number.isInteger(cacheWrite)) {
          Logger.info(
            `cacheWrite: ${cacheWrite}, cacheRead: ${cacheRead}, outputTokens: ${outputTokens}`
          );
        }

        // Extend caching when cache read/write
        if (
          chatSettings.claude_cachingMaxExtension > 0 &&
          (cacheWrite !== 0 || cacheRead !== 0)
        ) {
          const duration = AnthropicProvider.getCachingDuration(requestTime);

          if (duration > 30) {
            const onTimeout = async () =>
              await AnthropicProvider.onCachingTimeout(
                async () =>
                  await provider.extendCaching(pluginRequest, modelDef),
                0
              );

            PluginTimerUI.start(onTimeout, duration);
          } else {
            if (!chatSettings.claude_useSilentCachingExtension) {
              PluginToastUI.show(
                `남은 캐싱 유효 기간이 ${duration}초에 불과함`,
                3000
              );
            }
          }
        }
      },
      cancel() {},
    });

    return stream;
  }

  private async extendCaching(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<number> {
    const chatSettings = getChatSettings();

    const url = `https://api.anthropic.com/v1/messages`;

    const jsonBody = AnthropicProvider.buildClaudeBody(pluginRequest, modelDef);

    jsonBody.max_tokens = 1;

    if (jsonBody.thinking) {
      delete jsonBody.thinking;
    }

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
        "anthropic-dangerous-direct-browser-access": "true",
        "anthropic-beta": "prompt-caching-2024-07-31",
      },
      body: jsonBody,
      rawResponse: false,
    };

    if (chatSettings.claude_useExperimentalCachingExtension) {
      // Remove messages after the last breakpoint
      while (
        jsonBody.messages.length > 0 &&
        !jsonBody.messages.at(-1)?.content[0].cache_control
      ) {
        jsonBody.messages.pop();
      }

      // When only the system message is a breakpoint
      if (jsonBody.messages.length === 0) {
        jsonBody.messages.push({
          role: LLM_ROLE.USER,
          content: [
            {
              type: "text",
              text: "Start",
            },
          ],
        });
      }
    }

    Logger.info("Calling Anthropic with model:", modelDef.id);
    const response = await risuFetchEx(pluginRequest, url, fetchArgs);

    if (!response.ok) {
      return -1;
    }

    const usage = response?.data?.usage;
    const cacheWrite = usage?.cache_creation_input_tokens;
    const cacheRead = usage?.cache_read_input_tokens;
    const outputTokens = usage?.output_tokens;

    if (Number.isInteger(cacheWrite)) {
      Logger.info(
        `cacheWrite: ${cacheWrite}, cacheRead: ${cacheRead}, outputTokens: ${outputTokens}`
      );

      if (!chatSettings.claude_useSilentCachingExtension) {
        PluginToastUI.show(`캐시 읽음: ${cacheRead}`, 3000);
      }

      if (cacheRead > 0) {
        return cacheRead;
      }
    }

    return 0;
  }
}
