import type { PluginV2ProviderArgument } from "$risu/plugins/plugins";
import type { LLMDefinition } from "$ts/types";

export abstract class BaseProvider {
  public supportsStreaming(): boolean {
    return typeof this.getStreamedResponse === "function";
  }

  public abstract getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string>;

  public getStreamedResponse?(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<ReadableStream<string>>;
}
