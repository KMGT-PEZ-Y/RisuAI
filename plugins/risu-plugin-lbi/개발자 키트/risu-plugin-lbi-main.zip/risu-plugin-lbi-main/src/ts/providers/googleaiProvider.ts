import type { PluginV2ProviderArgument } from "$risu/plugins/plugins";
import type { OpenAIChat } from "$risu/process/index.svelte";
import type {
  GlobalFetchArgs,
  GlobalFetchResult,
} from "$risu/globalApi.svelte";
import { BaseProvider } from "$ts/providers/baseProvider";
import { Logger } from "$ts/logger";
import {
  risuFetchEx,
  getCommonSettings,
  getChatSettings,
} from "$ts/pluginSetting";
import type { LLMDefinition } from "$ts/types";
import { LLM_ROLE, LLM_FLAG, REQUEST_TYPE } from "$ts/types";
import { PluginTextEditorUI, PluginToastUI } from "$ts/ui";
import { Utils } from "$ts/utils";

export interface GeminiBody {
  contents: GeminiMessage[];
  systemInstruction?: {
    parts: GeminiPart[];
  };
  safetySettings: {
    category:
      | "HARM_CATEGORY_HATE_SPEECH"
      | "HARM_CATEGORY_DANGEROUS_CONTENT"
      | "HARM_CATEGORY_HARASSMENT"
      | "HARM_CATEGORY_SEXUALLY_EXPLICIT";
    threshold: GeminiSafetyThreshold;
  }[];
  generationConfig: {
    maxOutputTokens: number;
    temperature?: number;
    topP?: number;
    topK?: number;
    frequencyPenalty?: number;
    presencePenalty?: number;
    stopSequences?: string[];
    thinkingConfig?: {
      includeThoughts?: boolean;
      thinkingBudget?: number;
    };
  };
  tools?: Record<string, any>[];
}

export interface GeminiMessage {
  role: GeminiNonSystemRole;
  parts: GeminiPart[];
}

export const GEMINI_ROLE = {
  SYSTEM: "system",
  USER: "user",
  MODEL: "model",
} as const;

export type GeminiRole = (typeof GEMINI_ROLE)[keyof typeof GEMINI_ROLE];

export type GeminiNonSystemRole =
  | typeof GEMINI_ROLE.USER
  | typeof GEMINI_ROLE.MODEL;

export interface GeminiPart {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
  };
  thought?: boolean;
}

export const GEMINI_SAFETY_THRESHOLD = {
  OFF: "OFF",
  BLOCK_NONE: "BLOCK_NONE",
} as const;

export type GeminiSafetyThreshold =
  (typeof GEMINI_SAFETY_THRESHOLD)[keyof typeof GEMINI_SAFETY_THRESHOLD];

export class GoogleAIProvider extends BaseProvider {
  private static readonly modelSafetyThresholdsMap: {
    readonly [key: string]: GeminiSafetyThreshold;
  } = {
    default: GEMINI_SAFETY_THRESHOLD.OFF,
    "gemini-2.0-flash-thinking-exp-01-21": GEMINI_SAFETY_THRESHOLD.BLOCK_NONE,
  };

  public readonly apiKey: string;

  public constructor(apiKey: string) {
    super();
    this.apiKey = apiKey;
  }

  public static buildGeminiBody(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): GeminiBody {
    const commonSettings = getCommonSettings();
    const chatSettings = getChatSettings();
    const requestType = Utils.getRequestType(pluginRequest);
    const openAIChats = structuredClone(pluginRequest.prompt_chat);

    // Find the index where the first 'user' or 'assistant' role appears
    let splitIndex = openAIChats.findIndex(
      (message) =>
        message.role === LLM_ROLE.USER || message.role === LLM_ROLE.ASSISTANT
    );

    // If no 'user' or 'assistant' role is found, set splitIndex to the length of the array
    if (splitIndex === -1) {
      splitIndex = openAIChats.length;
    }

    // Extract the beginning consecutive system messages and join content of the system messages using '\n\n'
    const system: GeminiPart = {
      text: openAIChats
        .slice(0, splitIndex)
        .map((message) => message.content.trim())
        .join("\n\n"),
    };

    // Remove the system messages from the original array
    openAIChats.splice(0, splitIndex);

    // Ensure the first message is the user message
    if (openAIChats.length === 0 || openAIChats[0].role !== LLM_ROLE.USER) {
      openAIChats.unshift({ role: LLM_ROLE.USER, content: "Start" });
    }

    // Build messages
    const messages: GeminiMessage[] = [];

    for (let i = 0; i < openAIChats.length; i++) {
      const message = openAIChats[i];
      const geminiRole = GoogleAIProvider.toGeminiRole(message.role);
      const trimedContent = message.content?.trim() || "";
      const lastMessage =
        messages.length > 0 ? messages[messages.length - 1] : null;
      const prefix = "";

      if (message.multimodals && message.multimodals.length > 0) {
        const newParts: GeminiPart[] = [];

        newParts.push({
          text: trimedContent,
        });

        for (const modal of message.multimodals) {
          if (
            modal.type === "image" ||
            modal.type === "audio" ||
            modal.type === "video"
          ) {
            const base64 = modal.base64;
            const mimeType = base64.split(";")[0].split(":")[1];
            const data = base64.split(",")[1];

            newParts.push({
              inlineData: {
                mimeType: mimeType,
                data: data,
              },
            });
          }
        }

        messages.push({
          role:
            geminiRole === GEMINI_ROLE.SYSTEM ? GEMINI_ROLE.USER : geminiRole,
          parts: newParts,
        });
      } else if (
        geminiRole === GEMINI_ROLE.MODEL &&
        GoogleAIProvider.isGeminiThinkingModel(modelDef) &&
        message.thoughts &&
        message.thoughts.length > 0
      ) {
        if (trimedContent === "") {
          // Thought prefill
          messages.push({
            role: geminiRole,
            parts: [
              {
                text: message.thoughts.join("\n\n"),
                thought: true,
              },
            ],
          });
        } else {
          messages.push({
            role: geminiRole,
            parts: [
              {
                text: trimedContent,
              },
            ],
          });
        }
      } else if (lastMessage?.role === geminiRole) {
        if (trimedContent === "") {
          continue;
        }

        if (lastMessage.parts[lastMessage.parts.length - 1].inlineData) {
          lastMessage.parts.push({
            text: trimedContent,
          });
        } else {
          lastMessage.parts[lastMessage.parts.length - 1].text +=
            "\n\n" + trimedContent;
        }
      } else if (geminiRole === GEMINI_ROLE.SYSTEM) {
        if (trimedContent === "") {
          continue;
        }

        // Any all other system messages will be converted to user messages with prefix
        if (lastMessage?.role === GEMINI_ROLE.USER) {
          if (lastMessage.parts[lastMessage.parts.length - 1].inlineData) {
            lastMessage.parts.push({
              text: prefix + trimedContent,
            });
          } else {
            lastMessage.parts[lastMessage.parts.length - 1].text +=
              "\n\n" + prefix + trimedContent;
          }
        } else {
          messages.push({
            role: GEMINI_ROLE.USER,
            parts: [
              {
                text: prefix + trimedContent,
              },
            ],
          });
        }
      } else if (
        geminiRole === GEMINI_ROLE.USER ||
        geminiRole === GEMINI_ROLE.MODEL
      ) {
        if (trimedContent === "") {
          continue;
        }

        messages.push({
          role: geminiRole,
          parts: [
            {
              text: trimedContent,
            },
          ],
        });
      }
    }

    // Build body
    const body: GeminiBody = {
      contents: messages,
      ...(system.text !== "" && {
        systemInstruction: {
          parts: [system],
        },
      }),
      safetySettings: [
        {
          category: "HARM_CATEGORY_HATE_SPEECH",
          threshold: GEMINI_SAFETY_THRESHOLD.OFF,
        },
        {
          category: "HARM_CATEGORY_DANGEROUS_CONTENT",
          threshold: GEMINI_SAFETY_THRESHOLD.OFF,
        },
        {
          category: "HARM_CATEGORY_HARASSMENT",
          threshold: GEMINI_SAFETY_THRESHOLD.OFF,
        },
        {
          category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
          threshold: GEMINI_SAFETY_THRESHOLD.OFF,
        },
      ],
      generationConfig: {
        maxOutputTokens: pluginRequest.max_tokens,
        ...(pluginRequest.temperature != null && {
          temperature: pluginRequest.temperature,
        }),
        ...(pluginRequest.top_p != null && { topP: pluginRequest.top_p }),
        ...(pluginRequest.top_k != null && { topK: pluginRequest.top_k }),
        ...(pluginRequest.frequency_penalty != null && {
          frequencyPenalty: pluginRequest.frequency_penalty,
        }),
        ...(pluginRequest.presence_penalty != null && {
          presencePenalty: pluginRequest.presence_penalty,
        }),
      },
    };

    // Stop sequences
    if (pluginRequest.stop_sequences?.length > 0) {
      body.generationConfig.stopSequences = pluginRequest.stop_sequences;
    }

    // Thinking model
    if (GoogleAIProvider.isGeminiThinkingModel(modelDef)) {
      body.generationConfig.thinkingConfig = {
        includeThoughts: true,
      };
    }

    const thinkingMode = GoogleAIProvider.getGeminiThinkingMode(
      pluginRequest,
      modelDef
    );

    Logger.debug("Thinking mode:", thinkingMode);

    switch (thinkingMode) {
      case "off": {
        // Non-thinking mode
        body.generationConfig.thinkingConfig = {
          thinkingBudget: 0,
        };
        break;
      }
      case "auto": {
        // Auto thinking tokens - No parameters needed
        body.generationConfig.thinkingConfig = {
          includeThoughts: true,
        };
        break;
      }
      case "manual": {
        // Manual thinking tokens
        body.generationConfig.thinkingConfig = {
          includeThoughts: true,
          thinkingBudget: pluginRequest.thinking_tokens,
        };
        break;
      }
    }

    // Grounding with google search
    if (
      chatSettings.gemini_useGroundingSearch &&
      modelDef.flags.includes(LLM_FLAG.hasGroundingSearch) &&
      requestType === REQUEST_TYPE.CHAT
    ) {
      body.tools = [
        {
          google_search: {},
        },
      ];
    }

    // Validate api parameters
    GoogleAIProvider.validateApiParameters(body, modelDef);

    // Determine the safety threshold
    const safetyThreshold: GeminiSafetyThreshold =
      GoogleAIProvider.modelSafetyThresholdsMap[modelDef.id] ||
      GoogleAIProvider.modelSafetyThresholdsMap.default;

    body.safetySettings.forEach((setting) => {
      setting.threshold = safetyThreshold;
    });

    // Remove unsupported paramters
    if (
      modelDef.id.includes("exp") ||
      modelDef.flags.includes(LLM_FLAG.isExperimentalModel)
    ) {
      delete body.generationConfig.frequencyPenalty;
      delete body.generationConfig.presencePenalty;
    }

    // Set JSON Schema
    /*
     if (pluginRequest.json_schema != null) {
      body.generationConfig.response_mime_type = "application/json";
      body.generationConfig.response_schema = pluginRequest.json_schema;
    }
    */

    // Preview prompt
    if (
      commonSettings.previewPrompt &&
      (requestType === REQUEST_TYPE.CHAT ||
        requestType === REQUEST_TYPE.TRANSLATION)
    ) {
      const bodyCloned = structuredClone(body);

      for (let i = 0; i < bodyCloned.contents.length; i++) {
        const message = bodyCloned.contents[i];
        const sameRoleMessages = bodyCloned.contents.filter(
          (v) => v.role === message.role
        );
        const reverseIndex = -(
          sameRoleMessages.length - sameRoleMessages.indexOf(message)
        );

        message.role =
          `${message.role}[${reverseIndex}]` as GeminiNonSystemRole;
      }

      PluginTextEditorUI.showModal(
        "프롬프트 미리보기",
        JSON.stringify(bodyCloned, null, 2)
      );

      throw new Error(
        "Sending chat is interrupted because 'preview prompt' option is turned on."
      );
    }

    return body;
  }

  public static isGeminiThinkingModel(modelDef: LLMDefinition): boolean {
    return (
      modelDef.id.includes("gemini") &&
      modelDef.flags.includes(LLM_FLAG.isThinkingModel)
    );
  }

  public static getGeminiThinkingMode(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): "off" | "auto" | "manual" | "unknown" {
    if (
      !modelDef.id.includes("gemini") ||
      !modelDef.flags.includes(LLM_FLAG.hasThinkingTokens)
    ) {
      return "unknown";
    }

    if (pluginRequest.thinking_tokens == null) {
      return "auto";
    }

    if (
      Number.isInteger(pluginRequest.thinking_tokens) &&
      pluginRequest.thinking_tokens > 0
    ) {
      return "manual";
    }

    return "off";
  }

  public static parseContent(
    pluginRequest: PluginV2ProviderArgument,
    response: GlobalFetchResult
  ): string {
    const commonSettings = getCommonSettings();
    const chatSettings = getChatSettings();

    const blockReason =
      response?.data?.promptFeedback?.blockReason ??
      response?.data?.candidates?.[0]?.finishReason;

    if (
      blockReason === "SAFETY" ||
      blockReason === "RECITATION" ||
      blockReason === "OTHER" ||
      blockReason === "BLOCKLIST" ||
      blockReason === "PROHIBITED_CONTENT" ||
      blockReason === "SPII"
    ) {
      throw new Error(`검열됨: ${JSON.stringify(response.data)}`);
    }

    const parts: GeminiPart[] = response?.data?.candidates?.[0]?.content?.parts;

    if (!parts) {
      Logger.warn("No parts field in response");
      throw new Error(JSON.stringify(response.data));
    }

    const reasoningParts = parts.filter((part) => part.thought);
    const contentParts = parts.filter((part) => !part.thought);
    let parsed = "";

    if (contentParts.length === 0) {
      Logger.warn("No part field in response");
      throw new Error(JSON.stringify(response.data));
    }

    switch (Utils.getRequestType(pluginRequest)) {
      case REQUEST_TYPE.CHAT: {
        // Process grounding search result
        const groundingMetadata = response.data.candidates[0].groundingMetadata;

        if (
          groundingMetadata &&
          groundingMetadata.groundingChunks &&
          groundingMetadata.groundingChunks.length > 0
        ) {
          const groundingHtml =
            GoogleAIProvider.generateGroundingSearchHtml(groundingMetadata);

          parsed += `<Thoughts>\n${groundingHtml.trim()}\n</Thoughts>\n\n`;
        }

        if (commonSettings.gemini_showThoughts && reasoningParts.length > 0) {
          parsed += `<Thoughts>\n\n${reasoningParts
            .map((part) => part.text)
            .join("\n\n")}\n</Thoughts>\n\n`;
        }

        parsed += contentParts.map((part) => part.text).join("\n\n") || "";

        // Show thoughts token count
        if (chatSettings.gemini_showThoughtsToken) {
          const thoughtsTokenCount =
            response.data.usageMetadata?.thoughtsTokenCount || 0;

          PluginToastUI.show(`thoughtsTokenCount: ${thoughtsTokenCount}`, 3000);
        }

        break;
      }

      case REQUEST_TYPE.TRANSLATION: {
        if (commonSettings.gemini_showThoughts && reasoningParts.length > 0) {
          // Translation should return <details> tag instead of <Thoughts> tag,
          // and a line break (\n\n) should follow the </summary> tag
          // to ensure proper markdown formatting
          parsed += `<details><summary>생각의 사슬</summary>\n\n${reasoningParts
            .map((part) => part.text)
            .join("\n\n")}</details>\n\n`;
        }

        parsed += contentParts.map((part) => part.text).join("\n\n") || "";
        break;
      }

      default: {
        parsed += contentParts.map((part) => part.text).join("\n\n") || "";
        break;
      }
    }

    return parsed;
  }

  private static generateGroundingSearchHtml(
    groundingMetadata: Record<string, any>
  ): string {
    // Serach queries HTML
    const webSearchQueries: string[] = groundingMetadata.webSearchQueries || [];
    let queriesHtml = "";

    if (webSearchQueries.length > 0) {
      const queries = webSearchQueries
        .map(
          (query) =>
            `<span style="display:inline-block;border-radius:16px;padding:4px 12px;background-color:#2d3748;color:#e2e8f0;font-size:12px;border:1px solid #4a5568;">${query}</span>`
        )
        .join("");

      queriesHtml =
        `<div style="margin-bottom:10px;">` +
        `<div style="font-weight:500;margin-bottom:4px;color:#a0aec0;font-size:13px;">검색 쿼리</div>` +
        `<div style="display:flex;flex-wrap:wrap;gap:6px;">${queries}</div>` +
        `</div>`;
    }

    // Sources HTML
    const chunks: Record<string, any>[] = groundingMetadata.groundingChunks;
    const sourcesHtml = chunks
      .map((chunk: Record<string, any>) => {
        if (!chunk.web) return "";

        const web: Record<string, string> = chunk.web;
        const title = web.title;
        const uri = web.uri;

        return (
          `<div style="background-color:#2d3748;border:1px solid #4a5568;border-radius:8px;padding:8px;display:flex;align-items:center;min-width:120px;max-width:200px;height:40px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);">` +
          `<a href="${uri}" target="_blank" style="font-weight:600;color:#90cdf4;font-size:13px;text-decoration:none;display:flex;align-items:center;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:100%;">` +
          `${title}` +
          `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left:4px;min-width:12px;"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>` +
          `</a>` +
          `</div>`
        );
      })
      .join("");

    // Entire HTML
    return (
      `<div style="font-family:system-ui,-apple-system,sans-serif;margin:8px 0;padding:12px;border-radius:12px;background-color:#1a202c;color:#e2e8f0;box-shadow:0 4px 6px rgba(0,0,0,0.1);border:1px solid #2d3748;">` +
      `<div style="display:flex;align-items:center;margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid #4a5568;">` +
      `<svg width="16" height="16" viewBox="0 0 24 24" style="margin-right:8px;"><path fill="#63b3ed" d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>` +
      `<span style="font-weight:600;color:#e2e8f0;font-size:14px;">그라운딩 검색</span>` +
      `</div>` +
      queriesHtml +
      `<div>` +
      `<div style="font-weight:500;margin-bottom:4px;color:#a0aec0;font-size:13px;">소스</div>` +
      `<div style="display:flex;flex-wrap:wrap;gap:8px;font-size:13px;color:#e2e8f0;">` +
      sourcesHtml +
      `</div>` +
      `</div>` +
      `<div style="font-size:11px;color:#a0aec0;margin-top:8px;text-align:right;padding-top:8px;border-top:1px solid #4a5568;">이 응답은 웹 검색을 기반으로 생성되었습니다</div>` +
      `</div>`
    );
  }

  private static toGeminiRole = (role: OpenAIChat["role"]): GeminiRole => {
    switch (role) {
      case LLM_ROLE.SYSTEM: {
        return GEMINI_ROLE.SYSTEM;
      }

      case LLM_ROLE.USER: {
        return GEMINI_ROLE.USER;
      }

      case LLM_ROLE.ASSISTANT: {
        return GEMINI_ROLE.MODEL;
      }

      default:
        return GEMINI_ROLE.SYSTEM;
    }
  };

  private static validateApiParameters(
    body: GeminiBody,
    modelDef: LLMDefinition
  ): void {
    if (
      body.generationConfig.temperature != null &&
      (body.generationConfig.temperature < 0 ||
        body.generationConfig.temperature > 2)
    ) {
      body.generationConfig.temperature = 1;
    }

    if (
      body.generationConfig.topP != null &&
      (body.generationConfig.topP < 0 || body.generationConfig.topP > 1)
    ) {
      delete body.generationConfig.topP;
    }

    if (
      body.generationConfig.topK != null &&
      (!Number.isInteger(body.generationConfig.topK) ||
        body.generationConfig.topK < 1 ||
        body.generationConfig.topK > 40)
    ) {
      delete body.generationConfig.topK;
    }

    if (
      body.generationConfig.frequencyPenalty != null &&
      (body.generationConfig.frequencyPenalty < -2 ||
        body.generationConfig.frequencyPenalty >= 2)
    ) {
      delete body.generationConfig.frequencyPenalty;
    }

    if (
      body.generationConfig.presencePenalty != null &&
      (body.generationConfig.presencePenalty < -2 ||
        body.generationConfig.presencePenalty >= 2)
    ) {
      delete body.generationConfig.presencePenalty;
    }
  }

  public async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    const chatSettings = getChatSettings();

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelDef.id}:generateContent?key=${this.apiKey}`;

    const jsonBody = GoogleAIProvider.buildGeminiBody(pluginRequest, modelDef);

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        "Content-Type": "application/json",
      },
      body: jsonBody,
      rawResponse: false,
      ...(chatSettings.gemini_usePlainFetch ? { plainFetchForce: true } : {}),
    };

    Logger.info("Calling Google AI with model:", modelDef.id);
    const response = await risuFetchEx(pluginRequest, url, fetchArgs);

    if (!response.ok) {
      // 429: Quota exceeded
      if (response.data.error?.code === 429) {
        Logger.warn("Google Studio quota exceeded:", response.data);
        throw response.data;
      }

      // Other error
      throw new Error(JSON.stringify(response.data));
    }

    return GoogleAIProvider.parseContent(pluginRequest, response);
  }
}
