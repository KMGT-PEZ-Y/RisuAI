import type { PluginV2ProviderArgument } from "$risu/plugins/plugins";
import { risuAPI } from "$risu/plugins/plugins";
import type { GlobalFetchArgs } from "$risu/globalApi.svelte";
import type {
  ClaudeBody,
  ClaudeBodyMessage,
  ClaudeBodyContent,
} from "$ts/providers/anthropicProvider";
import { AnthropicProvider } from "$ts/providers/anthropicProvider";
import { BaseProvider } from "$ts/providers/baseProvider";
import { Logger } from "$ts/logger";
import { getCommonSettings, getChatSettings } from "$ts/pluginSetting";
import type { LLMNonSystemRole, LLMDefinition } from "$ts/types";
import { LLM_ROLE, REQUEST_TYPE } from "$ts/types";
import { PluginTextEditorUI, PluginToastUI } from "$ts/ui";
import { Utils } from "$ts/utils";

import { AwsV4Signer } from "aws4fetch";

export class AWSProvider extends BaseProvider {
  private readonly accessKey: string;
  private readonly secretAccessKey: string;
  private readonly region: string;

  public constructor(
    accessKey: string,
    secretAccessKey: string,
    region: string
  ) {
    super();
    this.accessKey = accessKey;
    this.secretAccessKey = secretAccessKey;
    this.region = region;
  }

  private static buildClaudeBody(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): ClaudeBody {
    const commonSettings = getCommonSettings();
    const requestType = Utils.getRequestType(pluginRequest);
    const openAIChats = structuredClone(pluginRequest.prompt_chat);

    // Find the index where the first 'user' or 'assistant' role appears
    let splitIndex = openAIChats.findIndex(
      (message) =>
        message.role === LLM_ROLE.USER || message.role === LLM_ROLE.ASSISTANT
    );

    // If no 'user' or 'assistant' role is found, set splitIndex to the length of the array
    if (splitIndex === -1) {
      splitIndex = openAIChats.length;
    }

    // Extract the beginning consecutive system messages and join content of the system messages using '\n\n'
    const system: ClaudeBodyContent = {
      type: "text",
      text: openAIChats
        .slice(0, splitIndex)
        .map((message) => message.content.trim())
        .join("\n\n"),
    };

    // Remove the system messages from the original array
    openAIChats.splice(0, splitIndex);

    // Ensure the first message is the user message
    if (openAIChats.length === 0 || openAIChats[0].role !== LLM_ROLE.USER) {
      openAIChats.unshift({ role: LLM_ROLE.USER, content: "Start" });
    }

    // Build messages
    const messages: ClaudeBodyMessage[] = [];

    for (let i = 0; i < openAIChats.length; i++) {
      const message = openAIChats[i];
      const trimedContent = message.content.trim();
      const lastMessage =
        messages.length > 0 ? messages[messages.length - 1] : null;

      if (message.role === LLM_ROLE.SYSTEM) {
        if (lastMessage?.role === LLM_ROLE.USER) {
          messages[messages.length - 1].content[0].text +=
            "\n\nsystem: " + trimedContent;
        } else {
          messages.push({
            role: LLM_ROLE.USER,
            content: [
              {
                type: "text",
                text: "system: " + trimedContent,
              },
            ],
          });
        }
      } else if (
        message.role === LLM_ROLE.USER ||
        message.role === LLM_ROLE.ASSISTANT
      ) {
        if (lastMessage?.role === message.role) {
          messages[messages.length - 1].content[0].text +=
            "\n\n" + trimedContent;
        } else {
          messages.push({
            role: message.role,
            content: [
              {
                type: "text",
                text: trimedContent,
              },
            ],
          });
        }
      }
    }

    // Build body
    const body: ClaudeBody = {
      anthropic_version: "bedrock-2023-05-31",
      ...(system.text !== "" && {
        system: [system],
      }),
      messages: messages,
      max_tokens: pluginRequest.max_tokens,
      ...(pluginRequest.temperature != null && {
        temperature: pluginRequest.temperature,
      }),
      ...(pluginRequest.top_p != null && { top_p: pluginRequest.top_p }),
      ...(pluginRequest.top_k != null && { top_k: pluginRequest.top_k }),
    };

    // Extended thinking
    if (AnthropicProvider.isExtendedThinking(pluginRequest, modelDef)) {
      body.thinking = {
        type: "enabled",
        budget_tokens: pluginRequest.thinking_tokens,
      };
    }

    // Validate api parameters
    AnthropicProvider.validateApiParameters(body);

    // Preview prompt
    if (
      commonSettings.previewPrompt &&
      (requestType === REQUEST_TYPE.CHAT ||
        requestType === REQUEST_TYPE.TRANSLATION)
    ) {
      const bodyCloned = structuredClone(body);

      for (let i = 0; i < bodyCloned.messages.length; i++) {
        const message = bodyCloned.messages[i];
        const sameRoleMessages = bodyCloned.messages.filter(
          (v) => v.role === message.role
        );
        const reverseIndex = -(
          sameRoleMessages.length - sameRoleMessages.indexOf(message)
        );

        message.role = `${message.role}[${reverseIndex}]` as LLMNonSystemRole;
      }

      PluginTextEditorUI.showModal(
        "프롬프트 미리보기",
        JSON.stringify(bodyCloned, null, 2)
      );

      throw new Error(
        "Sending chat is interrupted because 'preview prompt' option is turned on."
      );
    }

    return body;
  }

  public async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    const jsonBody = AWSProvider.buildClaudeBody(pluginRequest, modelDef);

    const signer = new AwsV4Signer({
      method: "POST",
      url: `https://bedrock-runtime.${this.region}.amazonaws.com/model/${
        this.region.split("-")[0]
      }.${modelDef.id}/invoke`,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(jsonBody),
      accessKeyId: this.accessKey,
      secretAccessKey: this.secretAccessKey,
      service: "bedrock",
      region: this.region,
    });

    const { method, url, headers, body } = await signer.sign();
    const headersObj = Object.fromEntries(headers.entries());

    // Chrome browser is case-sensitive for header names.
    if (headersObj["content-type"]) {
      headersObj["Content-Type"] = headersObj["content-type"];
      delete headersObj["content-type"];
    }

    const fetchArgs: GlobalFetchArgs = {
      method: "POST",
      headers: headersObj,
      body: jsonBody,
      rawResponse: false,
      plainFetchForce: true,
    };

    Logger.info("Calling AWS with model:", modelDef.id);
    const response = await risuAPI.risuFetch(url.href, fetchArgs);

    if (!response.ok) {
      throw new Error(JSON.stringify(response.data));
    }

    return AnthropicProvider.parseContent(pluginRequest, response);
  }

  private async extendCaching(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<number> {
    const chatSettings = getChatSettings();

    const jsonBody = AWSProvider.buildClaudeBody(pluginRequest, modelDef);

    jsonBody.max_tokens = 1;

    if (jsonBody.thinking) {
      delete jsonBody.thinking;
    }

    const signer = new AwsV4Signer({
      method: "POST",
      url: `https://bedrock-runtime.${this.region}.amazonaws.com/model/${
        this.region.split("-")[0]
      }.${modelDef.id}/invoke`,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(jsonBody),
      accessKeyId: this.accessKey,
      secretAccessKey: this.secretAccessKey,
      service: "bedrock",
      region: this.region,
    });

    const { method, url, headers, body } = await signer.sign();
    const headersObj = Object.fromEntries(headers.entries());

    // Chrome browser is case-sensitive for header names.
    if (headersObj["content-type"]) {
      headersObj["Content-Type"] = headersObj["content-type"];
      delete headersObj["content-type"];
    }

    const fetchArgs: GlobalFetchArgs = {
      method: "POST",
      headers: headersObj,
      body: jsonBody,
      rawResponse: false,
      plainFetchForce: true,
    };

    if (chatSettings.claude_useExperimentalCachingExtension) {
      // Remove messages after the last breakpoint
      while (
        jsonBody.messages.length > 0 &&
        !jsonBody.messages.at(-1)?.content[0].cache_control
      ) {
        jsonBody.messages.pop();
      }

      // When only the system message is a breakpoint
      if (jsonBody.messages.length === 0) {
        jsonBody.messages.push({
          role: LLM_ROLE.USER,
          content: [
            {
              type: "text",
              text: "Start",
            },
          ],
        });
      }
    }

    Logger.info("Calling AWS with model:", modelDef.id);
    const response = await risuAPI.risuFetch(url.href, fetchArgs);

    if (!response.ok) {
      return -1;
    }

    const usage = response?.data?.usage;
    const cacheWrite = usage?.cache_creation_input_tokens;
    const cacheRead = usage?.cache_read_input_tokens;
    const outputTokens = usage?.output_tokens;

    if (Number.isInteger(cacheWrite)) {
      Logger.info(
        `cacheWrite: ${cacheWrite}, cacheRead: ${cacheRead}, outputTokens: ${outputTokens}`
      );

      if (!chatSettings.claude_useSilentCachingExtension) {
        PluginToastUI.show(`캐시 읽음: ${cacheRead}`, 3000);
      }

      if (cacheRead > 0) {
        return cacheRead;
      }
    }

    return 0;
  }
}
