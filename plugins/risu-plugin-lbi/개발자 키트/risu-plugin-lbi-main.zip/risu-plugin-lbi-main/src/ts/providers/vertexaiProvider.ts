import type { PluginV2ProviderArgument } from "$risu/plugins/plugins";
import type {
  GlobalFetchArgs,
  GlobalFetchResult,
} from "$risu/globalApi.svelte";
import type {
  ClaudeBody,
  ClaudeBodyMessage,
  ClaudeBodyContent,
} from "$ts/providers/anthropicProvider";
import { AnthropicProvider } from "$ts/providers/anthropicProvider";
import { BaseProvider } from "$ts/providers/baseProvider";
import { GoogleAIProvider } from "$ts/providers/googleaiProvider";
import * as PluginDB from "$ts/storage/pluginDB";
import { Logger } from "$ts/logger";
import {
  risuFetchEx,
  getCommonSettings,
  getChatSettings,
} from "$ts/pluginSetting";
import type { LLMNonSystemRole, LLMDefinition } from "$ts/types";
import { LLM_ROLE, REQUEST_TYPE } from "$ts/types";
import { PluginTextEditorUI } from "$ts/ui";
import { Utils } from "$ts/utils";

export interface VertexAICredential {
  type: string;
  project_id: string;
  private_key_id: string;
  private_key: string;
  client_email: string;
  client_id: string;
  auth_uri: string;
  token_uri: string;
  auth_provider_x509_cert_url: string;
  client_x509_cert_url: string;
  universe_domain: string;
}

const MODEL_FAMILIES = {
  CLAUDE: "claude",
  GEMINI: "gemini",
  UNKNOWN: "unknown",

  identify: (model: string): string => {
    if (model.includes(MODEL_FAMILIES.CLAUDE)) return MODEL_FAMILIES.CLAUDE;
    if (model.includes(MODEL_FAMILIES.GEMINI)) return MODEL_FAMILIES.GEMINI;

    return MODEL_FAMILIES.UNKNOWN;
  },
} as const;

export class VertexAIProvider extends BaseProvider {
  private static readonly projectIdTokenMapKey: string =
    "vertexAIProjectIdTokenMap";

  public credential: VertexAICredential;

  public constructor(credentials: VertexAICredential) {
    super();
    this.credential = credentials;
  }

  private static buildClaudeBody(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): ClaudeBody {
    const commonSettings = getCommonSettings();
    const requestType = Utils.getRequestType(pluginRequest);
    const openAIChats = structuredClone(pluginRequest.prompt_chat);

    // Find the index where the first 'user' or 'assistant' role appears
    let splitIndex = openAIChats.findIndex(
      (message) =>
        message.role === LLM_ROLE.USER || message.role === LLM_ROLE.ASSISTANT
    );

    // If no 'user' or 'assistant' role is found, set splitIndex to the length of the array
    if (splitIndex === -1) {
      splitIndex = openAIChats.length;
    }

    // Extract the beginning consecutive system messages and join content of the system messages using '\n\n'
    const system: ClaudeBodyContent = {
      type: "text",
      text: openAIChats
        .slice(0, splitIndex)
        .map((message) => message.content.trim())
        .join("\n\n"),
    };

    // Remove the system messages from the original array
    openAIChats.splice(0, splitIndex);

    // Ensure the first message is the user message
    if (openAIChats.length === 0 || openAIChats[0].role !== LLM_ROLE.USER) {
      openAIChats.unshift({ role: LLM_ROLE.USER, content: "Start" });
    }

    // Build messages
    const messages: ClaudeBodyMessage[] = [];

    for (let i = 0; i < openAIChats.length; i++) {
      const message = openAIChats[i];
      const trimedContent = message.content.trim();
      const lastMessage =
        messages.length > 0 ? messages[messages.length - 1] : null;

      if (message.role === LLM_ROLE.SYSTEM) {
        if (lastMessage?.role === LLM_ROLE.USER) {
          messages[messages.length - 1].content[0].text +=
            "\n\nsystem: " + trimedContent;
        } else {
          messages.push({
            role: LLM_ROLE.USER,
            content: [
              {
                type: "text",
                text: "system: " + trimedContent,
              },
            ],
          });
        }
      } else if (
        message.role === LLM_ROLE.USER ||
        message.role === LLM_ROLE.ASSISTANT
      ) {
        if (lastMessage?.role === message.role) {
          messages[messages.length - 1].content[0].text +=
            "\n\n" + trimedContent;
        } else {
          messages.push({
            role: message.role,
            content: [
              {
                type: "text",
                text: trimedContent,
              },
            ],
          });
        }
      }
    }

    // Build body
    const body: ClaudeBody = {
      anthropic_version: "vertex-2023-10-16",
      ...(system.text !== "" && {
        system: [system],
      }),
      messages: messages,
      max_tokens: pluginRequest.max_tokens,
      ...(pluginRequest.temperature != null && {
        temperature: pluginRequest.temperature,
      }),
      ...(pluginRequest.top_p != null && { top_p: pluginRequest.top_p }),
      ...(pluginRequest.top_k != null && { top_k: pluginRequest.top_k }),
    };

    // Validate api parameters
    AnthropicProvider.validateApiParameters(body);

    // Preview prompt
    if (
      commonSettings.previewPrompt &&
      (requestType === REQUEST_TYPE.CHAT ||
        requestType === REQUEST_TYPE.TRANSLATION)
    ) {
      const bodyCloned = structuredClone(body);

      for (let i = 0; i < bodyCloned.messages.length; i++) {
        const message = bodyCloned.messages[i];
        const sameRoleMessages = bodyCloned.messages.filter(
          (v) => v.role === message.role
        );
        const reverseIndex = -(
          sameRoleMessages.length - sameRoleMessages.indexOf(message)
        );

        message.role = `${message.role}[${reverseIndex}]` as LLMNonSystemRole;
      }

      PluginTextEditorUI.showModal(
        "프롬프트 미리보기",
        JSON.stringify(bodyCloned, null, 2)
      );

      throw new Error(
        "Sending chat is interrupted because 'preview prompt' option is turned on."
      );
    }

    return body;
  }

  private static async getAccessTokenForProject(
    credential: VertexAICredential,
    forceUpdate: boolean = false
  ): Promise<string> {
    const projectIdTokenMap =
      (await PluginDB.get<Record<string, string>>(
        VertexAIProvider.projectIdTokenMapKey
      )) || {};

    if (!forceUpdate && projectIdTokenMap[credential.project_id]) {
      return projectIdTokenMap[credential.project_id];
    }

    const newToken = await this.getAccessToken(
      credential.client_email,
      credential.private_key
    );

    projectIdTokenMap[credential.project_id] = newToken;
    await PluginDB.put<Record<string, string>>(
      VertexAIProvider.projectIdTokenMapKey,
      projectIdTokenMap
    );

    return newToken;
  }

  private static async getAccessToken(
    clientEmail: string,
    privateKey: string
  ): Promise<string> {
    const jwt = await this.generateJWT(clientEmail, privateKey);

    const response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`,
    });

    if (!response.ok) {
      let errorText;

      try {
        errorText = JSON.stringify(await response.json());
      } catch {
        errorText = response.status;
      }

      throw new Error(`Failed to refresh google access token: ${errorText}`);
    }

    const data = await response.json();
    const accessToken = data.access_token;

    if (!accessToken) {
      throw new Error("No google access token in the response");
    }

    return accessToken;
  }

  private static async generateJWT(
    clientEmail: string,
    privateKey: string
  ): Promise<string> {
    if (!clientEmail.includes("gserviceaccount.com")) {
      throw new Error(
        "Invalid Vertex project id. Must include gserviceaccount.com"
      );
    }

    if (
      !privateKey.includes("-----BEGIN PRIVATE KEY-----") ||
      !privateKey.includes("-----END PRIVATE KEY-----")
    ) {
      throw new Error(
        "Invalid Vertex private key. Must include proper key markers."
      );
    }

    const header = {
      alg: "RS256",
      typ: "JWT",
    };

    const now = Math.floor(Date.now() / 1000);
    const claimSet = {
      iss: clientEmail,
      scope: "https://www.googleapis.com/auth/cloud-platform",
      aud: "https://oauth2.googleapis.com/token",
      exp: now + 3600,
      iat: now,
    };

    const encodedHeader = this.base64url(
      new TextEncoder().encode(JSON.stringify(header))
    );
    const encodedClaimSet = this.base64url(
      new TextEncoder().encode(JSON.stringify(claimSet))
    );

    const key = await crypto.subtle.importKey(
      "pkcs8",
      this.str2ab(privateKey),
      {
        name: "RSASSA-PKCS1-v1_5",
        hash: { name: "SHA-256" },
      },
      false,
      ["sign"]
    );

    const signature = await crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      key,
      new TextEncoder().encode(`${encodedHeader}.${encodedClaimSet}`)
    );

    return `${encodedHeader}.${encodedClaimSet}.${this.base64url(
      new Uint8Array(signature)
    )}`;
  }

  private static str2ab(privateKey: string): ArrayBuffer {
    const binaryString = atob(
      privateKey.replace(
        /-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\\n/g,
        ""
      )
    );
    const bytes = new Uint8Array(binaryString.length);

    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    return bytes.buffer;
  }

  private static base64url(source: Uint8Array): string {
    let encodedSource = btoa(String.fromCharCode.apply(null, [...source]))
      .replace(/=+$/, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_");
    return encodedSource;
  }

  private static getEndpointUrl(
    modelDef: LLMDefinition,
    location: string,
    projectId: string
  ): string {
    const baseUrl =
      location === "global"
        ? `https://aiplatform.googleapis.com/v1/projects/${projectId}/locations/global`
        : `https://${location}-aiplatform.googleapis.com/v1/projects/${projectId}/locations/${location}`;

    switch (MODEL_FAMILIES.identify(modelDef.id)) {
      case MODEL_FAMILIES.CLAUDE:
        return `${baseUrl}/publishers/anthropic/models/${modelDef.id}:rawPredict`;
      case MODEL_FAMILIES.GEMINI:
        return `${baseUrl}/publishers/google/models/${modelDef.id}:generateContent`;
      default:
        throw new Error(
          `Unsupported model family while getting endpoint url: ${modelDef.id}`
        );
    }
  }

  private static parseContent(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition,
    response: GlobalFetchResult
  ): string {
    switch (MODEL_FAMILIES.identify(modelDef.id)) {
      case MODEL_FAMILIES.CLAUDE: {
        return AnthropicProvider.parseContent(pluginRequest, response);
      }

      case MODEL_FAMILIES.GEMINI: {
        return GoogleAIProvider.parseContent(pluginRequest, response);
      }

      default: {
        throw new Error(
          `Unsupported model family while parsing response: ${modelDef.id}`
        );
      }
    }
  }

  public async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    const chatSettings = getChatSettings();

    let jsonBody;

    switch (MODEL_FAMILIES.identify(modelDef.id)) {
      case MODEL_FAMILIES.CLAUDE: {
        jsonBody = VertexAIProvider.buildClaudeBody(pluginRequest, modelDef);
        break;
      }

      case MODEL_FAMILIES.GEMINI: {
        jsonBody = GoogleAIProvider.buildGeminiBody(pluginRequest, modelDef);

        // Temporary fix for thinking model
        if (GoogleAIProvider.isGeminiThinkingModel(modelDef)) {
          // Remove thought property
          jsonBody.contents = jsonBody.contents.map((content) => ({
            ...content,
            parts: content.parts.map((part) => {
              const { thought, ...rest } = part;
              return rest;
            }),
          }));
        }

        break;
      }

      default: {
        throw new Error(
          `Unsupported model family while building request body: ${modelDef.id}`
        );
      }
    }

    Logger.info("Using Vertex AI project id:", this.credential.project_id);

    // Get access token
    const accessToken = await VertexAIProvider.getAccessTokenForProject(
      this.credential
    );

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: jsonBody,
      rawResponse: false,
      ...(chatSettings.gemini_usePlainFetch ? { plainFetchForce: true } : {}),
    };

    const availableLocations = modelDef?.locations || [];

    for (let i = 0; i < availableLocations.length; i++) {
      const location = availableLocations[i];
      Logger.info("Using Vertex AI location:", location);

      const url = VertexAIProvider.getEndpointUrl(
        modelDef,
        location,
        this.credential.project_id
      );

      Logger.info("Calling Vertex AI with model:", modelDef.id);
      let response = await risuFetchEx(pluginRequest, url, fetchArgs);

      // Handle token expiration
      if (!response?.ok && response.data.error?.code === 401) {
        Logger.info("Token expired. Refreshing token.");

        const newAccessToken = await VertexAIProvider.getAccessTokenForProject(
          this.credential,
          true
        );

        fetchArgs.headers = {
          ...fetchArgs.headers,
          Authorization: `Bearer ${newAccessToken}`,
        };

        Logger.info("Retrying Vertex AI with new token.");
        response = await risuFetchEx(pluginRequest, url, fetchArgs);
      }

      // Success
      if (response?.ok) {
        return VertexAIProvider.parseContent(pluginRequest, modelDef, response);
      }

      // 400: Invalid resource field value in the request (will fail in next location)
      if (
        response.data.error?.code === 400 &&
        response.data.error?.status === "INVALID_ARGUMENT"
      ) {
        throw new Error(
          `No vertex project id?: ${JSON.stringify(response.data)}`
        );
      }

      // 400: Project is not allowed to use Publisher Model (will fail in next location)
      if (
        response.data.error?.code === 400 &&
        response.data.error?.status === "FAILED_PRECONDITION"
      ) {
        throw new Error(
          `Model is not enabled?: ${JSON.stringify(response.data)}`
        );
      }

      // 403: Permission denied on resource project (will fail in next location)
      if (
        response.data.error?.code === 403 &&
        response.data.error?.status === "PERMISSION_DENIED"
      ) {
        throw new Error(
          `No permission to use the model?: ${JSON.stringify(response.data)}`
        );
      }

      // The current location is unstable, but the next location may return a successful response.
      // Ignore the error for now.
      if (i < availableLocations.length - 1) {
        continue;
      }

      // 429: Quota exceeded
      if (response.data.error?.code === 429) {
        Logger.warn("Vertex AI quota exceeded:", response.data);
        throw response.data;
      }

      // Other error
      throw new Error(JSON.stringify(response.data));
    }

    throw new Error("Unexpected error");
  }
}
