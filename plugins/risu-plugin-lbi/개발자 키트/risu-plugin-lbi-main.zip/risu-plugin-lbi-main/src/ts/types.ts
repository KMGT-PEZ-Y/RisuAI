export const LLM_ROLE = {
  SYSTEM: "system",
  USER: "user",
  ASSISTANT: "assistant",
} as const;

export type LLMRole = (typeof LLM_ROLE)[keyof typeof LLM_ROLE];

export type LLMNonSystemRole = typeof LLM_ROLE.USER | typeof LLM_ROLE.ASSISTANT;

export const LLM_PROVIDER = {
  GOOGLEAI: "GoogleAI",
  VERTEXAI: "VertexAI",
  ANTHROPIC: "Anthropic",
  DEEPSEEK: "Deepseek",
  OPENAI: "OpenAI",
  AWS: "AWS",
  OPENAICOMPATIBLE: "OpenAICompatible",
} as const;

export type LLMProvider = (typeof LLM_PROVIDER)[keyof typeof LLM_PROVIDER];

export const LLM_TOKENIZER = {
  O200K_BASE: "o200k_base",
  CL100K_BASE: "cl100k_base",
  MISTRAL: "mistral",
  LLAMA: "llama",
  NOVELAI: "novelai",
  CLAUDE: "claude",
  NOVELLIST: "novellist",
  LLAMA3: "llama",
  GEMMA: "gemma",
  COHERE: "cohere",
} as const;

export type LLMTokenizer = (typeof LLM_TOKENIZER)[keyof typeof LLM_TOKENIZER];

export const LLM_FLAG = {
  hasFullSystemPrompt: "hasFullSystemPrompt",
  hasFirstSystemPrompt: "hasFirstSystemPrompt",
  requiresAlternateRole: "requiresAlternateRole",
  mustStartWithUserInput: "mustStartWithUserInput",
  isThinkingModel: "isThinkingModel",
  isExperimentalModel: "isExperimentalModel",
  isFreeModel: "isFreeModel",
  hasStreaming: "hasStreaming",
  hasDeveloperRole: "hasDeveloperRole",
  hasGroundingSearch: "hasGroundingSearch",
  hasThinkingTokens: "hasThinkingTokens",
  hasMaxCompletionTokens: "hasMaxCompletionTokens",
  hasReasoningEffort: "hasReasoningEffort",
} as const;

export type LLMFlag = (typeof LLM_FLAG)[keyof typeof LLM_FLAG];

export interface LLMDefinition {
  uniqueId: string;
  id: string;
  name: string;
  provider: LLMProvider;
  tokenizer: LLMTokenizer;
  flags: LLMFlag[];
  locations?: string[];
}

export interface CommonSettings {
  googleAIProvider_apiKey: string;
  fallbackToVertexGemini: boolean;
  vertexAIProvider_projectId: string;
  vertexAIProvider_privateKey: string;
  vertexAIProvider_clientEmail: string;
  vertexAIProvider_credentials: string;
  anthropicProvider_apiKey: string;
  deepseekProvider_apiKey: string;
  deepseekProvider_customUrl: string;
  openaiProvider_apiKey: string;
  awsProvider_accessKey: string;
  awsProvider_secretAccessKey: string;
  awsProvider_region: string;
  openaiCompatibleProvider_url: string;
  openaiCompatibleProvider_apiKey: string;
  openaiCompatibleProvider_model: string;
  openaiCompatibleProvider_tokenizer: string;
  openaiCompatibleProvider_useStreaming: string;
  openaiCompatibleProvider_hasFirstSystemPrompt: string;
  openaiCompatibleProvider_mustStartWithUserInput: string;
  openaiCompatibleProvider_requiresAlternateRole: string;
  openaiCompatibleProvider_useMaxOutputTokensInstead: string;
  previewPrompt: boolean;
  useEditorForInputBox: boolean;
  gemini_blockPaidModel: boolean;
  gemini_showThoughts: boolean;
}

export interface ChatSettings {
  claude_caching: boolean;
  claude_cachingBreakpoints: string;
  claude_cachingMaxExtension: number;
  claude_useExperimentalCachingExtension: boolean;
  claude_useSilentCachingExtension: boolean;
  claude_useStreaming: boolean;
  gemini_preserveSystem: boolean;
  gemini_removeForeignLanguage: boolean;
  gemini_separateCot: boolean;
  gemini_useGroundingSearch: boolean;
  gemini_showThoughtsToken: boolean;
  gemini_usePlainFetch: boolean;
  removeStartANewChat: boolean;
  autoClickTranslateButton: boolean;
  sampling_temperature: number;
  sampling_topP: number;
  sampling_topK: number;
  sampling_frequencyPenalty: number;
  sampling_presencePenalty: number;
  sampling_thinkingTokens: number;
  sampling_stopSequences: string;
}

export interface MemorySettings {
  model: string;
  prefill: string;
  usePlainFetch: boolean;
  sampling_maxTokens: number;
  sampling_temperature: number;
  sampling_topP: number;
  sampling_topK: number;
  sampling_frequencyPenalty: number;
  sampling_presencePenalty: number;
  sampling_thinkingTokens: number;
  sampling_stopSequences: string;
}

export interface TranslationSettings {
  model: string;
  prefill: string;
  showOriginal: boolean;
  removeThoughts: boolean;
  saveToTranslatorNote: boolean;
  usePlainFetch: boolean;
  sampling_temperature: number;
  sampling_topP: number;
  sampling_topK: number;
  sampling_frequencyPenalty: number;
  sampling_presencePenalty: number;
  sampling_thinkingTokens: number;
  sampling_stopSequences: string;
}

export interface OtherSettings {
  model: string;
  usePlainFetch: boolean;
  sampling_maxTokens: number;
  sampling_temperature: number;
  sampling_topP: number;
  sampling_topK: number;
  sampling_frequencyPenalty: number;
  sampling_presencePenalty: number;
  sampling_thinkingTokens: number;
  sampling_stopSequences: string;
}

export const REQUEST_TYPE = {
  CHAT: "chat",
  EMOTION: "emotion",
  MEMORY: "memory",
  TRANSLATION: "translation",
  OTHER: "other",
  UNKNOWN: "unknown",
} as const;

export type RequestType = (typeof REQUEST_TYPE)[keyof typeof REQUEST_TYPE];
