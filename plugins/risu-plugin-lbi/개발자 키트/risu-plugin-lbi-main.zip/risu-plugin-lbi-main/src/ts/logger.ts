import { Utils } from "$ts/utils";

export const LOGLEVEL = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3,
} as const;

export type LogLevel = (typeof LOGLEVEL)[keyof typeof LOGLEVEL];

export class Logger {
  public static defaultMinLevel: LogLevel = LOGLEVEL.DEBUG;

  public static debug(...params: any[]): void {
    this.log(LOGLEVEL.DEBUG, ...params);
  }

  public static info(...params: any[]): void {
    this.log(LOGLEVEL.INFO, ...params);
  }

  public static warn(...params: any[]): void {
    this.log(LOGLEVEL.WARN, ...params);
  }

  public static error(...params: any[]): void {
    this.log(LOGLEVEL.ERROR, ...params);
  }

  private static log(level: LogLevel, ...params: any[]): void {
    if (this.shouldLog(level)) {
      const caller = Logger.getCallerName();
      const timestamp = Utils.getTimestamp();
      const levelString = Logger.levelToString[level];

      console.log(`[${timestamp}][${levelString}][${caller}]`, ...params);
    }
  }

  private static shouldLog(level: LogLevel): boolean {
    return level >= Logger.defaultMinLevel;
  }

  private static getCallerName(): string {
    try {
      const stack = new Error().stack as string;
      const lines = stack.split("\n");

      for (let i = 3; i < lines.length; i++) {
        const line = lines[i]?.trim();

        if (!line) continue;

        // Extract function name before @ symbol or blob URL
        const match =
          line.match(/^([^@]+)@/) || line.match(/at\s+([^@\s]+)[@\s]/);
        if (match?.[1]) {
          const name = match[1]
            .replace(/[\/<>]+/g, "") // Remove special characters
            .split(".")
            .pop(); // Get last part after dot

          if (name && name !== "unknown") {
            return name;
          }
        }
      }
    } catch (error) {
      console.log("Error getting caller name:", error);
    }

    return "unknown";
  }

  private static levelToString: Record<LogLevel, string> = {
    [LOGLEVEL.DEBUG]: "DEBUG",
    [LOGLEVEL.INFO]: "INFO",
    [LOGLEVEL.WARN]: "WARN",
    [LOGLEVEL.ERROR]: "ERROR",
  };
}
