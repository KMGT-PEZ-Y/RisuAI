import { IndexedDB } from "$ts/storage/indexedDB";

const DB_NAME: string = "LLMTranslateCache";
const STORE_NAME = "keyvaluepairs";

const db = new IndexedDB(DB_NAME, STORE_NAME);

export async function getAll(): Promise<Record<string, string>> {
  return await db.getAll<string>();
}

export async function putAll(
  keyValuePairs: Record<string, string>
): Promise<void> {
  await db.putAll<string>(keyValuePairs);
}

export async function clear(): Promise<void> {
  await db.clear();
}

export async function count(): Promise<number> {
  return await db.count();
}
