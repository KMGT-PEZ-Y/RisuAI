import { IndexedDB } from "$ts/storage/indexedDB";
import { PLUGIN_TITLE } from "$ts/pluginSetting";

const DB_NAME: string = PLUGIN_TITLE;
const STORE_NAME = PLUGIN_TITLE;
const DB_VERSION: number = 2;

const db = new IndexedDB(DB_NAME, STORE_NAME, DB_VERSION);

export async function get<T>(key: string): Promise<T | null> {
  return db.get<T>(key);
}

export async function put<T>(key: string, value: T): Promise<void> {
  return db.put<T>(key, value);
}
