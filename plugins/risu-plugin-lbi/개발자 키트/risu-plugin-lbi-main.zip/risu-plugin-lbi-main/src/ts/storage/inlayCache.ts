import { v4 } from "uuid";
import { IndexedDB } from "$ts/storage/indexedDB";

interface Inlay {
  name: string;
  data: string;
  ext: string;
  height: number;
  width: number;
  type: "image" | "video" | "audio";
}

const DB_NAME: string = "inlay";
const STORE_NAME = "inlay";

const db = new IndexedDB(DB_NAME, STORE_NAME);

export async function create(dataURL: string): Promise<string> {
  const base64Pattern = /^data:image\/([a-z]+);base64,(.+)$/i;
  const match = dataURL.match(base64Pattern);

  if (!match) throw new Error("Invalid data URL.");

  const [, dataExt] = match;
  const inlayId = v4();
  const extension = dataExt || "png";
  const fileName = `${inlayId}.${extension}`;

  const imageEl = new Image();
  imageEl.src = dataURL;

  const { width, height } = await getImageDimensions(imageEl);

  await put(inlayId, {
    name: fileName,
    data: dataURL,
    ext: extension,
    height: height,
    width: width,
    type: "image",
  });

  return inlayId;
}

export async function get(key: string): Promise<Inlay | null> {
  return await db.get<Inlay>(key);
}

export async function getRange(
  offset: number,
  limit: number
): Promise<Record<string, Inlay>> {
  return await db.getRange<Inlay>(offset, limit);
}

export async function getAll(): Promise<Record<string, Inlay>> {
  return await db.getAll<Inlay>();
}

export async function put(key: string, value: Inlay): Promise<void> {
  await db.put<Inlay>(key, value);
}

export async function putAll(
  keyValuePairs: Record<string, Inlay>
): Promise<void> {
  await db.putAll<Inlay>(keyValuePairs);
}

export async function clear(): Promise<void> {
  await db.clear();
}

export async function count(): Promise<number> {
  return await db.count();
}

function getImageDimensions(
  imageEl: HTMLImageElement
): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    imageEl.onerror = () => {
      reject(new Error("Failed to load image."));
    };

    const checkDimensions = () => {
      const width = imageEl.naturalWidth;
      const height = imageEl.naturalHeight;

      if (width <= 0 || height <= 0) {
        reject(new Error("Invalid image dimensions: width or height is zero."));
      } else {
        resolve({ width, height });
      }
    };

    imageEl.onload = checkDimensions;

    if (imageEl.complete) {
      checkDimensions();
    }
  });
}
