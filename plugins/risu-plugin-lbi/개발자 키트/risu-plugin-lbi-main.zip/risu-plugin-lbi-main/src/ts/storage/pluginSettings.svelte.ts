import { LLM_TOKENIZER, type LLMTokenizer } from "$ts/types";

export interface LegacyPluginSettings {
  common_googleAIProvider_apiKey: string;
  common_fallbackToVertexGemini: string;
  common_vertexAIProvider_projectId: string;
  common_vertexAIProvider_privateKey: string;
  common_vertexAIProvider_clientEmail: string;
  common_vertexAIProvider_credentials: string;
  common_anthropicProvider_apiKey: string;
  chat_claude_useStreaming: string;
  common_deepseekProvider_apiKey: string;
  common_deepseekProvider_customUrl: string;
  common_openaiProvider_apiKey: string;
  common_awsProvider_accessKey: string;
  common_awsProvider_secretAccessKey: string;
  common_awsProvider_region: string;
  common_openaiCompatibleProvider_url: string;
  common_openaiCompatibleProvider_apiKey: string;
  common_openaiCompatibleProvider_model: string;
  common_openaiCompatibleProvider_tokenizer: string;
  common_openaiCompatibleProvider_useStreaming: string;
  common_openaiCompatibleProvider_hasFirstSystemPrompt: string;
  common_openaiCompatibleProvider_requiresAlternateRole: string;
  common_openaiCompatibleProvider_mustStartWithUserInput: string;
  common_openaiCompatibleProvider_useMaxOutputTokensInstead: string;
  common_previewPrompt: string;
  common_useEditorForInputBox: string;
  common_gemini_blockPaidModel: string;
  common_gemini_showThoughts: string;
  chat_claude_caching: string;
  chat_claude_cachingBreakpoints: string;
  chat_claude_cachingMaxExtension: string;
  chat_claude_useExperimentalCachingExtension: string;
  chat_claude_useSilentCachingExtension: string;
  chat_gemini_preserveSystem: string;
  chat_gemini_removeForeignLanguage: string;
  chat_gemini_separateCot: string;
  chat_gemini_useGroundingSearch: string;
  chat_gemini_showThoughtsToken: string;
  chat_gemini_usePlainFetch: string;
  chat_removeStartANewChat: string;
  chat_autoClickTranslateButton: string;
  chat_sampling_temperature: string;
  chat_sampling_topP: string;
  chat_sampling_topK: string;
  chat_sampling_frequencyPenalty: string;
  chat_sampling_presencePenalty: string;
  chat_sampling_thinkingTokens: string;
  chat_sampling_stopSequences: string;
  hypa_model: string;
  hypa_prefill: string;
  hypa_usePlainFetch: string;
  hypa_sampling_maxTokens: string;
  hypa_sampling_temperature: string;
  hypa_sampling_topP: string;
  hypa_sampling_topK: string;
  hypa_sampling_frequencyPenalty: string;
  hypa_sampling_presencePenalty: string;
  hypa_sampling_thinkingTokens: string;
  hypa_sampling_stopSequences: string;
  translation_model: string;
  translation_prefill: string;
  translation_showOriginal: string;
  translation_removeThoughts: string;
  translation_saveToTranslatorNote: string;
  translation_usePlainFetch: string;
  translation_sampling_temperature: string;
  translation_sampling_topP: string;
  translation_sampling_topK: string;
  translation_sampling_frequencyPenalty: string;
  translation_sampling_presencePenalty: string;
  translation_sampling_thinkingTokens: string;
  translation_sampling_stopSequences: string;
  other_model: string;
  other_usePlainFetch: string;
  other_sampling_maxTokens: string;
  other_sampling_temperature: string;
  other_sampling_topP: string;
  other_sampling_topK: string;
  other_sampling_frequencyPenalty: string;
  other_sampling_presencePenalty: string;
  other_sampling_thinkingTokens: string;
  other_sampling_stopSequences: string;
  tools_githubCopilotToken: string;
  compatibility_doNotSetTokenizer: string;
}

export interface PluginSettings {
  common_googleAIProvider_apiKey: string[];
  common_fallbackToVertexGemini: boolean;
  common_vertexAIProvider_credentials: string[];
  common_anthropicProvider_apiKey: string;
  chat_claude_useStreaming: boolean;
  common_deepseekProvider_apiKey: string;
  common_deepseekProvider_customUrl: string;
  common_openaiProvider_apiKey: string;
  common_awsProvider_accessKey: string;
  common_awsProvider_secretAccessKey: string;
  common_awsProvider_region: string;
  common_openaiCompatibleProvider_url: string;
  common_openaiCompatibleProvider_apiKey: string;
  common_openaiCompatibleProvider_model: string;
  common_openaiCompatibleProvider_tokenizer: LLMTokenizer;
  common_openaiCompatibleProvider_useStreaming: boolean;
  common_openaiCompatibleProvider_hasFirstSystemPrompt: boolean;
  common_openaiCompatibleProvider_requiresAlternateRole: boolean;
  common_openaiCompatibleProvider_mustStartWithUserInput: boolean;
  common_openaiCompatibleProvider_useMaxOutputTokensInstead: boolean;
  common_previewPrompt: boolean;
  common_useEditorForInputBox: boolean;
  common_gemini_blockPaidModel: boolean;
  common_gemini_showThoughts: boolean;
  chat_claude_caching: boolean;
  chat_claude_cachingBreakpoints: string | null;
  chat_claude_cachingMaxExtension: number;
  chat_claude_useExperimentalCachingExtension: boolean;
  chat_claude_useSilentCachingExtension: boolean;
  chat_gemini_preserveSystem: boolean;
  chat_gemini_removeForeignLanguage: boolean;
  chat_gemini_separateCot: boolean;
  chat_gemini_useGroundingSearch: boolean;
  chat_gemini_showThoughtsToken: boolean;
  chat_gemini_usePlainFetch: boolean;
  chat_removeStartANewChat: boolean;
  chat_autoClickTranslateButton: boolean;
  chat_sampling_temperature: number | null;
  chat_sampling_topP: number | null;
  chat_sampling_topK: number | null;
  chat_sampling_frequencyPenalty: number | null;
  chat_sampling_presencePenalty: number | null;
  chat_sampling_thinkingTokens: number | null;
  chat_sampling_stopSequences: string[];
  hypa_model: string | null;
  hypa_prefill: string;
  hypa_usePlainFetch: boolean;
  hypa_sampling_maxTokens: number | null;
  hypa_sampling_temperature: number | null;
  hypa_sampling_topP: number | null;
  hypa_sampling_topK: number | null;
  hypa_sampling_frequencyPenalty: number | null;
  hypa_sampling_presencePenalty: number | null;
  hypa_sampling_thinkingTokens: number | null;
  hypa_sampling_stopSequences: string[];
  translation_model: string | null;
  translation_prefill: string;
  translation_showOriginal: boolean;
  translation_removeThoughts: boolean;
  translation_saveToTranslatorNote: boolean;
  translation_usePlainFetch: boolean;
  translation_sampling_temperature: number | null;
  translation_sampling_topP: number | null;
  translation_sampling_topK: number | null;
  translation_sampling_frequencyPenalty: number | null;
  translation_sampling_presencePenalty: number | null;
  translation_sampling_thinkingTokens: number | null;
  translation_sampling_stopSequences: string[];
  other_model: string | null;
  other_usePlainFetch: boolean;
  other_sampling_maxTokens: number | null;
  other_sampling_temperature: number | null;
  other_sampling_topP: number | null;
  other_sampling_topK: number | null;
  other_sampling_frequencyPenalty: number | null;
  other_sampling_presencePenalty: number | null;
  other_sampling_thinkingTokens: number | null;
  other_sampling_stopSequences: string[];
  tools_githubCopilotToken: string;
  compatibility_doNotSetTokenizer: boolean;
}

export async function loadPluginSettings(): Promise<PluginSettings> {
  // indexed db 에서 가져오기
  // legacyPluginSettings 타입이면 migratePluginSettings
  // 아니면 그대로 반환
  return createPluginSettings();
}

export function migratePluginSettings(): PluginSettings {
  return {} as PluginSettings;
}

export function createPluginSettings(): PluginSettings {
  const settings: PluginSettings = {
    common_googleAIProvider_apiKey: [],
    common_fallbackToVertexGemini: false,
    common_vertexAIProvider_credentials: [],
    common_anthropicProvider_apiKey: "",
    chat_claude_useStreaming: false,
    common_deepseekProvider_apiKey: "",
    common_deepseekProvider_customUrl: "",
    common_openaiProvider_apiKey: "",
    common_awsProvider_accessKey: "",
    common_awsProvider_secretAccessKey: "",
    common_awsProvider_region: "",
    common_openaiCompatibleProvider_url: "",
    common_openaiCompatibleProvider_apiKey: "",
    common_openaiCompatibleProvider_model: "",
    common_openaiCompatibleProvider_tokenizer: LLM_TOKENIZER.O200K_BASE,
    common_openaiCompatibleProvider_useStreaming: false,
    common_openaiCompatibleProvider_hasFirstSystemPrompt: false,
    common_openaiCompatibleProvider_requiresAlternateRole: false,
    common_openaiCompatibleProvider_mustStartWithUserInput: false,
    common_openaiCompatibleProvider_useMaxOutputTokensInstead: false,
    common_previewPrompt: false,
    common_useEditorForInputBox: false,
    common_gemini_blockPaidModel: false,
    common_gemini_showThoughts: false,
    chat_claude_caching: false,
    chat_claude_cachingBreakpoints: null,
    chat_claude_cachingMaxExtension: 0,
    chat_claude_useExperimentalCachingExtension: false,
    chat_claude_useSilentCachingExtension: false,
    chat_gemini_preserveSystem: false,
    chat_gemini_removeForeignLanguage: false,
    chat_gemini_separateCot: false,
    chat_gemini_useGroundingSearch: false,
    chat_gemini_showThoughtsToken: false,
    chat_gemini_usePlainFetch: false,
    chat_removeStartANewChat: false,
    chat_autoClickTranslateButton: false,
    chat_sampling_temperature: null,
    chat_sampling_topP: null,
    chat_sampling_topK: null,
    chat_sampling_frequencyPenalty: null,
    chat_sampling_presencePenalty: null,
    chat_sampling_thinkingTokens: null,
    chat_sampling_stopSequences: [],
    hypa_model: null,
    hypa_prefill: "",
    hypa_usePlainFetch: false,
    hypa_sampling_maxTokens: null,
    hypa_sampling_temperature: null,
    hypa_sampling_topP: null,
    hypa_sampling_topK: null,
    hypa_sampling_frequencyPenalty: null,
    hypa_sampling_presencePenalty: null,
    hypa_sampling_thinkingTokens: null,
    hypa_sampling_stopSequences: [],
    translation_model: null,
    translation_prefill: "",
    translation_showOriginal: false,
    translation_removeThoughts: false,
    translation_saveToTranslatorNote: false,
    translation_usePlainFetch: false,
    translation_sampling_temperature: null,
    translation_sampling_topP: null,
    translation_sampling_topK: null,
    translation_sampling_frequencyPenalty: null,
    translation_sampling_presencePenalty: null,
    translation_sampling_thinkingTokens: null,
    translation_sampling_stopSequences: [],
    other_model: null,
    other_usePlainFetch: false,
    other_sampling_maxTokens: null,
    other_sampling_temperature: null,
    other_sampling_topP: null,
    other_sampling_topK: null,
    other_sampling_frequencyPenalty: null,
    other_sampling_presencePenalty: null,
    other_sampling_thinkingTokens: null,
    other_sampling_stopSequences: [],
    tools_githubCopilotToken: "",
    compatibility_doNotSetTokenizer: false,
  };

  return settings;
}

export async function savePluginSettings(
  settings: PluginSettings
): Promise<void> {}
