export class IndexedDB {
  private readonly dbName: string;
  private readonly storeName: string;
  private readonly dbVersion?: number;

  public constructor(dbName: string, storeName: string, dbVersion?: number) {
    this.dbName = dbName;
    this.storeName = storeName;
    this.dbVersion = dbVersion;
  }

  public async get<T>(key: string): Promise<T | null> {
    const store = await this.getStore("readonly");

    return new Promise((resolve, reject) => {
      const request = store.get(key);

      request.onerror = () =>
        reject(
          new Error(
            `Error getting record in ${this.storeName}: ${request.error}`
          )
        );
      request.onsuccess = () => resolve(request.result ?? null);
    });
  }

  public async put<T>(key: string, value: T): Promise<void> {
    await this.putAll<T>({ [key]: value });
  }

  public async getRange<T>(
    offset: number,
    limit: number
  ): Promise<Record<string, T>> {
    const store = await this.getStore("readonly");

    return new Promise((resolve, reject) => {
      const request = store.openCursor();
      const keyValuePairs: Record<string, T> = {};
      let advanced = offset === 0;
      let count = 0;

      request.onerror = () =>
        reject(
          new Error(
            `Error getting record in ${this.storeName}: ${request.error}`
          )
        );
      request.onsuccess = () => {
        const cursor = request.result;

        if (!cursor) {
          resolve(keyValuePairs);
          return;
        }

        if (!advanced) {
          cursor.advance(offset);
          advanced = true;
          return;
        }

        if (count < limit) {
          keyValuePairs[String(cursor.key)] = cursor.value;
          count++;
          cursor.continue();
        } else {
          resolve(keyValuePairs);
        }
      };
    });
  }

  public async getAll<T>(): Promise<Record<string, T>> {
    const store = await this.getStore("readonly");

    return new Promise((resolve, reject) => {
      const request = store.openCursor();
      const keyValuePairs: Record<string, T> = {};

      request.onerror = () =>
        reject(
          new Error(
            `Error getting record in ${this.storeName}: ${request.error}`
          )
        );
      request.onsuccess = () => {
        const cursor = request.result;

        if (cursor) {
          keyValuePairs[String(cursor.key)] = cursor.value;
          cursor.continue();
        } else {
          resolve(keyValuePairs);
        }
      };
    });
  }

  public async putAll<T>(keyValuePairs: Record<string, T>): Promise<void> {
    const store = await this.getStore("readwrite");

    const requests = Object.entries(keyValuePairs).map(([key, value]) => {
      return new Promise<void>((resolve, reject) => {
        const request = store.put(value, key);

        request.onerror = () =>
          reject(
            new Error(
              `Error putting record in ${this.storeName}: ${request.error}`
            )
          );
        request.onsuccess = () => resolve();
      });
    });

    await Promise.all(requests);
  }

  public async delete(key: string): Promise<void> {
    const store = await this.getStore("readwrite");

    return new Promise((resolve, reject) => {
      const request = store.delete(key);

      request.onerror = () =>
        reject(
          new Error(
            `Error deleting key ${key} from ${this.storeName}: ${request.error}`
          )
        );
      request.onsuccess = () => resolve();
    });
  }

  public async clear(): Promise<void> {
    const store = await this.getStore("readwrite");

    return new Promise((resolve, reject) => {
      const request = store.clear();

      request.onerror = () =>
        reject(
          new Error(
            `Error clearing records in ${this.storeName}: ${request.error}`
          )
        );
      request.onsuccess = () => resolve();
    });
  }

  public async count(): Promise<number> {
    const store = await this.getStore("readonly");

    return new Promise((resolve, reject) => {
      const request = store.count();

      request.onerror = () =>
        reject(
          new Error(
            `Error counting records in ${this.storeName}: ${request.error}`
          )
        );
      request.onsuccess = () => resolve(request.result);
    });
  }

  private async getStore(mode: IDBTransactionMode): Promise<IDBObjectStore> {
    try {
      const db = await this.openDB();
      const tx = db.transaction(this.storeName, mode);

      return tx.objectStore(this.storeName);
    } catch (error) {
      throw new Error(`Error getting store ${this.dbName}: ${error}`);
    }
  }

  private openDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = this.dbVersion
        ? indexedDB.open(this.dbName, this.dbVersion)
        : indexedDB.open(this.dbName);

      request.onblocked = () =>
        reject(new Error("Database upgrade blocked by another open tab."));
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      request.onupgradeneeded = () => {
        const db = request.result;

        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName);
        }
      };
    });
  }
}
