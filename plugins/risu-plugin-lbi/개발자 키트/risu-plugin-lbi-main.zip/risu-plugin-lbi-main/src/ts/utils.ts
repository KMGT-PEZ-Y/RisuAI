import type { PluginV2ProviderArgument } from "$risu/plugins/plugins";
import type { OpenAIChat } from "$risu/process/index.svelte";
import type {
  LLMRole,
  ChatSettings,
  MemorySettings,
  TranslationSettings,
  OtherSettings,
  RequestType,
} from "$ts/types";
import { LLM_ROLE, REQUEST_TYPE } from "$ts/types";

export class Utils {
  public static confirmEx(message: string): Promise<boolean> {
    return new Promise((resolve) => {
      // Use setTimeout to defer the execution of confirm to the next tick of the event loop
      window.setTimeout(() => {
        const confirmed = window.confirm(message);
        resolve(confirmed);
      }, 0);
    });
  }

  public static sleep(ms: number): Promise<void> {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  public static isTrueString(str: unknown): boolean {
    if (typeof str !== "string") {
      return false;
    }

    const trimmedValue = str.trim().toLowerCase();
    return trimmedValue === "1" || trimmedValue === "true";
  }

  public static isGuid(str: unknown): boolean {
    if (typeof str !== "string") {
      return false;
    }

    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
      str
    );
  }

  public static pickElement<T>(arr: T[]): T {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  public static removeElement<T>(arr: T[], element: T): boolean {
    const index = arr.indexOf(element);

    if (index > -1) {
      arr.splice(index, 1);

      return true;
    }

    return false;
  }

  public static getTimestamp(): string {
    return new Date().toLocaleString("sv-SE").replace(/:/g, "");
  }

  public static escapeHTML(str: string): string {
    return str
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  public static getRequestType(
    pluginRequest: PluginV2ProviderArgument
  ): RequestType {
    switch (pluginRequest.mode) {
      case "model": {
        return REQUEST_TYPE.CHAT;
      }
      case "emotion": {
        return REQUEST_TYPE.EMOTION;
      }
      case "memory": {
        return REQUEST_TYPE.MEMORY;
      }
      case "translate": {
        return REQUEST_TYPE.TRANSLATION;
      }
      case "submodel": {
        // NAI image generation
        // Trigger effect
        return REQUEST_TYPE.OTHER;
      }
      case "otherAx": {
        return REQUEST_TYPE.OTHER;
      }
      default: {
        return REQUEST_TYPE.UNKNOWN;
      }
    }
  }

  public static applySamplingParameters(
    pluginRequest: PluginV2ProviderArgument,
    settings:
      | ChatSettings
      | MemorySettings
      | TranslationSettings
      | OtherSettings
  ): void {
    pluginRequest.top_p =
      pluginRequest.top_p != null
        ? Math.round(pluginRequest.top_p * 100) / 100
        : pluginRequest.top_p;

    pluginRequest.temperature =
      settings.sampling_temperature ?? pluginRequest.temperature;
    pluginRequest.top_p = settings.sampling_topP ?? pluginRequest.top_p;
    pluginRequest.top_k = settings.sampling_topK ?? pluginRequest.top_k;
    pluginRequest.frequency_penalty =
      settings.sampling_frequencyPenalty ?? pluginRequest.frequency_penalty;
    pluginRequest.presence_penalty =
      settings.sampling_presencePenalty ?? pluginRequest.presence_penalty;
    pluginRequest.thinking_tokens =
      settings.sampling_thinkingTokens ?? pluginRequest.thinking_tokens;
    pluginRequest.stop_sequences = settings.sampling_stopSequences
      .split(/\n+/)
      .filter((item) => item.trim().length > 0);
  }

  public static getKoreanPercentage(str: unknown): number {
    if (typeof str !== "string") {
      return 0;
    }

    // Remove all special characters, spaces, and numbers
    const cleanedText = str.replace(/[^\p{L}]/gu, "");

    if (cleanedText.length === 0) return 0;

    const koreanPattern = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
    const koreanCount = [...cleanedText].filter((char) =>
      koreanPattern.test(char)
    ).length;

    return Math.round((koreanCount / cleanedText.length) * 1000) / 10;
  }

  public static parseChatML(str: string): OpenAIChat[] | null {
    const starter = "<|im_start|>";
    const seperator = "<|im_sep|>";
    const ender = "<|im_end|>";
    const trimedData = str.trim();

    if (!trimedData.startsWith(starter)) {
      return null;
    }

    return trimedData
      .split(starter)
      .filter((f) => f !== "")
      .map((v) => {
        let role: LLMRole = LLM_ROLE.USER;

        // Default separators
        if (v.startsWith(LLM_ROLE.USER + seperator)) {
          role = LLM_ROLE.USER;
          v = v.substring(role.length + seperator.length);
        } else if (v.startsWith(LLM_ROLE.SYSTEM + seperator)) {
          role = LLM_ROLE.SYSTEM;
          v = v.substring(role.length + seperator.length);
        } else if (v.startsWith(LLM_ROLE.ASSISTANT + seperator)) {
          role = LLM_ROLE.ASSISTANT;
          v = v.substring(role.length + seperator.length);
        }

        // Space/Newline separators
        else if (v.startsWith("user ") || v.startsWith("user\n")) {
          role = LLM_ROLE.USER;
          v = v.substring(role.length + 1);
        } else if (v.startsWith("system ") || v.startsWith("system\n")) {
          role = LLM_ROLE.SYSTEM;
          v = v.substring(role.length + 1);
        } else if (v.startsWith("assistant ") || v.startsWith("assistant\n")) {
          role = LLM_ROLE.ASSISTANT;
          v = v.substring(role.length + 1);
        }

        v = v.trim();

        if (v.endsWith(ender)) {
          v = v.substring(0, v.length - ender.length);
        }

        return {
          role: role,
          content: v,
        };
      });
  }

  public static base64ToUint8Array(base64: string): Uint8Array {
    const rawBytes = window.atob(base64);
    const bytes = new Uint8Array(rawBytes.length);

    for (let i = 0; i < rawBytes.length; i++) {
      bytes[i] = rawBytes.charCodeAt(i);
    }

    return bytes;
  }
}
