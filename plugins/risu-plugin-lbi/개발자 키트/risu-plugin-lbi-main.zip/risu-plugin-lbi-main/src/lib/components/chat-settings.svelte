<script lang="ts">
  import svelteLogo from "$assets/svelte.svg";
  import viteLogo from "$assets/vite.svg";
  import Counter from "$lib/components/counter.svelte";
</script>

<div class="tw:flex tw:gap-4 tw:items-center">
  <img
    class="tw:p-6 tw:h-24 tw:hover:drop-shadow-[0_0_2em_#646cffaa] tw:will-change-[filter] tw:transition-all tw:duration-300"
    src={viteLogo}
    alt="Vite Logo"
  />

  <img
    class="tw:p-6 tw:h-24 tw:hover:drop-shadow-[0_0_2em_#ff3e00aa] tw:will-change-[filter] tw:transition-all tw:duration-300"
    src={svelteLogo}
    alt="Svelte Logo"
  />
</div>

<div class="tw:flex tw:flex-col tw:gap-4 tw:items-start">
  <div class="tw:px-3 tw:py-1 tw:bg-zinc-400 tw:rounded-lg">
    <Counter />
  </div>

  <p>
    Check out
    <a
      class="tw:text-orange-500 tw:hover:text-orange-700 tw:underline"
      href="https://github.com/sveltejs/kit#readme"
      target="_blank"
      rel="noreferrer"
    >
      SvelteKit
    </a>
    , the official Svelte app framework powered by Vite!
  </p>
</div>
