<script lang="ts">
  import {
    Plug,
    Send,
    Brain,
    Languages,
    Braces,
    CircleGauge,
    Github,
  } from "@lucide/svelte";
  import * as Sidebar from "$lib/components/ui/sidebar/index.js";

  const requestItems = [
    {
      id: "chat",
      title: "채팅",
      icon: Send,
    },
    {
      id: "memory",
      title: "감정/하이파",
      icon: Brain,
    },
    {
      id: "translation",
      title: "번역",
      icon: Languages,
    },
    {
      id: "other",
      title: "루아/트리거",
      icon: Braces,
    },
  ];

  const toolItems = [
    {
      id: "cache",
      title: "캐시 관리",
      icon: CircleGauge,
    },
    {
      id: "github",
      title: "깃허브 토큰",
      icon: Github,
    },
  ];

  let { currentPage = $bindable() } = $props();
</script>

<Sidebar.Root
  class="tw:static tw:h-full"
  side="left"
  variant="sidebar"
  collapsible="icon"
>
  <Sidebar.Header>
    <Sidebar.Menu>
      <Sidebar.MenuItem>
        <Sidebar.MenuButton size="lg">
          {#snippet child({ props })}
            <div {...props}>
              <div
                class="tw:size-8 tw:aspect-square tw:flex tw:items-center tw:justify-center tw:rounded-lg tw:bg-sidebar-primary tw:text-sidebar-primary-foreground"
              >
                <Plug />
              </div>
              <div class="tw:flex tw:flex-col tw:gap-0.5 tw:leading-none">
                <span class="tw:font-semibold">Large Beautiful Integrator</span>
                <span>v0.35.0</span>
              </div>
            </div>
          {/snippet}
        </Sidebar.MenuButton>
      </Sidebar.MenuItem>
    </Sidebar.Menu>
  </Sidebar.Header>

  <Sidebar.Content>
    <Sidebar.Group>
      <Sidebar.GroupLabel>요청 설정</Sidebar.GroupLabel>
      <Sidebar.GroupContent>
        <Sidebar.Menu>
          {#each requestItems as item (item.title)}
            <Sidebar.MenuItem>
              <Sidebar.MenuButton onclick={() => (currentPage = item.id)}>
                {#snippet child({ props })}
                  <div
                    {...props}
                    class:tw:bg-sidebar-accent={currentPage === item.id}
                  >
                    <item.icon />
                    <span>{item.title}</span>
                  </div>
                {/snippet}
              </Sidebar.MenuButton>
            </Sidebar.MenuItem>
          {/each}
        </Sidebar.Menu>
      </Sidebar.GroupContent>
    </Sidebar.Group>

    <Sidebar.Group>
      <Sidebar.GroupLabel>도구</Sidebar.GroupLabel>
      <Sidebar.GroupContent>
        <Sidebar.Menu>
          {#each toolItems as item (item.title)}
            <Sidebar.MenuItem>
              <Sidebar.MenuButton onclick={() => (currentPage = item.id)}>
                {#snippet child({ props })}
                  <div
                    {...props}
                    class:tw:bg-sidebar-accent={currentPage === item.id}
                  >
                    <item.icon />
                    <span>{item.title}</span>
                  </div>
                {/snippet}
              </Sidebar.MenuButton>
            </Sidebar.MenuItem>
          {/each}
        </Sidebar.Menu>
      </Sidebar.GroupContent>
    </Sidebar.Group>
  </Sidebar.Content>
</Sidebar.Root>
