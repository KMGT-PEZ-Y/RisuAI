<script lang="ts">
  import { Separator as SeparatorPrimitive } from "bits-ui";
  import { cn } from "$lib/utils.js";

  let {
    ref = $bindable(null),
    class: className,
    orientation = "horizontal",
    decorative = true,
    ...restProps
  }: SeparatorPrimitive.RootProps = $props();
</script>

<SeparatorPrimitive.Root
  bind:ref
  data-slot="separator-root"
  {decorative}
  {orientation}
  class={cn(
    "tw:bg-border tw:shrink-0 tw:data-[orientation=horizontal]:h-px tw:data-[orientation=vertical]:h-full tw:data-[orientation=horizontal]:w-full tw:data-[orientation=vertical]:w-px",
    className
  )}
  {...restProps}
/>
