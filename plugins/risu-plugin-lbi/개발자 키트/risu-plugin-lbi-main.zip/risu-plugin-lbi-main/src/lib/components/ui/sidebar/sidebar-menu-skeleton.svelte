<script lang="ts">
  import { Skeleton } from "$lib/components/ui/skeleton/index.js";
  import { cn } from "$lib/utils.js";
  import type { WithElementRef } from "bits-ui";
  import type { HTMLAttributes } from "svelte/elements";

  let {
    ref = $bindable(null),
    class: className,
    showIcon = false,
    children,
    ...restProps
  }: WithElementRef<HTMLAttributes<HTMLElement>> & {
    showIcon?: boolean;
  } = $props();

  // Random width between 50% and 90%
  const width = `${Math.floor(Math.random() * 40) + 50}%`;
</script>

<div
  bind:this={ref}
  data-slot="sidebar-menu-skeleton"
  data-sidebar="menu-skeleton"
  class={cn(
    "tw:flex tw:h-8 tw:items-center tw:gap-2 tw:rounded-md tw:px-2",
    className
  )}
  {...restProps}
>
  {#if showIcon}
    <Skeleton
      class="tw:size-4 tw:rounded-md"
      data-sidebar="menu-skeleton-icon"
    />
  {/if}
  <Skeleton
    class="tw:max-w-(--skeleton-width) tw:h-4 tw:flex-1"
    data-sidebar="menu-skeleton-text"
    style="--skeleton-width: {width};"
  />
  {@render children?.()}
</div>
