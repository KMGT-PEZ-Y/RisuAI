<script lang="ts">
  import { cn } from "$lib/utils.js";
  import type { WithElementRef } from "bits-ui";
  import type { HTMLAttributes } from "svelte/elements";

  let {
    ref = $bindable(null),
    class: className,
    children,
    ...restProps
  }: WithElementRef<
    HTMLAttributes<HTMLUListElement>,
    HTMLUListElement
  > = $props();
</script>

<ul
  bind:this={ref}
  data-slot="sidebar-menu"
  data-sidebar="menu"
  class={cn("tw:flex tw:w-full tw:min-w-0 tw:flex-col tw:gap-1", className)}
  {...restProps}
>
  {@render children?.()}
</ul>
