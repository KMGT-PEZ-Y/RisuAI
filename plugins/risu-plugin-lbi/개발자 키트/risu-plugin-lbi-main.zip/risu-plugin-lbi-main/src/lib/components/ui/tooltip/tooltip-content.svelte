<script lang="ts">
  import { Tooltip as TooltipPrimitive } from "bits-ui";
  import { cn } from "$lib/utils.js";

  let {
    ref = $bindable(null),
    class: className,
    sideOffset = 0,
    children,
    ...restProps
  }: TooltipPrimitive.ContentProps = $props();
</script>

<TooltipPrimitive.Portal>
  <TooltipPrimitive.Content
    bind:ref
    data-slot="tooltip-content"
    {sideOffset}
    class={cn(
      "tw:bg-primary tw:text-primary-foreground tw:animate-in tw:fade-in-0 tw:zoom-in-95 tw:data-[state=closed]:animate-out tw:data-[state=closed]:fade-out-0 tw:data-[state=closed]:zoom-out-95 tw:data-[side=bottom]:slide-in-from-top-2 tw:data-[side=left]:slide-in-from-right-2 tw:data-[side=right]:slide-in-from-left-2 tw:data-[side=top]:slide-in-from-bottom-2 tw:origin-(--bits-tooltip-content-transform-origin) tw:z-50 tw:w-fit tw:text-balance tw:rounded-md tw:px-3 tw:py-1.5 tw:text-xs",
      className
    )}
    {...restProps}
  >
    {@render children?.()}
    <TooltipPrimitive.Arrow>
      {#snippet child({ props })}
        <div
          data-slot="tooltip-arrow"
          class={cn(
            "tw:bg-primary tw:z-50 tw:size-2.5 tw:translate-y-[calc(-50%_-_2px)] tw:rotate-45 tw:rounded-[2px]",
            "tw:data-[side=top]:translate-x-1/2 tw:data-[side=top]:translate-y-[calc(-50%_+_2px)]",
            "tw:data-[side=bottom]:-translate-x-1/2 tw:data-[side=bottom]:-translate-y-[calc(-50%_+_1px)]",
            "tw:data-[side=right]:translate-x-[calc(50%_+_2px)] tw:data-[side=right]:translate-y-1/2",
            "tw:data-[side=left]:-translate-y-[calc(50%_-_3px)]"
          )}
          {...props}
        ></div>
      {/snippet}
    </TooltipPrimitive.Arrow>
  </TooltipPrimitive.Content>
</TooltipPrimitive.Portal>
