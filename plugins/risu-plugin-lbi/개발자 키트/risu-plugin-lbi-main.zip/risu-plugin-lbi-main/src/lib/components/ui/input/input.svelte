<script lang="ts">
  import type {
    HTMLInputAttributes,
    HTMLInputTypeAttribute,
  } from "svelte/elements";
  import type { WithElementRef } from "bits-ui";
  import { cn } from "$lib/utils.js";

  type InputType = Exclude<HTMLInputTypeAttribute, "file">;

  type Props = WithElementRef<
    Omit<HTMLInputAttributes, "type"> &
      (
        | { type: "file"; files?: FileList }
        | { type?: InputType; files?: undefined }
      )
  >;

  let {
    ref = $bindable(null),
    value = $bindable(),
    type,
    files = $bindable(),
    class: className,
    ...restProps
  }: Props = $props();
</script>

{#if type === "file"}
  <input
    bind:this={ref}
    class={cn(
      "tw:selection:bg-primary tw:dark:bg-input/30 tw:selection:text-primary-foreground tw:border-input tw:ring-offset-background tw:placeholder:text-muted-foreground tw:shadow-xs tw:flex tw:h-9 tw:w-full tw:min-w-0 tw:rounded-md tw:border tw:bg-transparent tw:px-3 tw:py-2 tw:text-sm tw:font-medium tw:outline-none tw:transition-[color,box-shadow] tw:disabled:cursor-not-allowed tw:disabled:opacity-50 tw:md:text-sm",
      "tw:focus-visible:border-ring tw:focus-visible:ring-ring/50 tw:focus-visible:ring-[3px]",
      "tw:aria-invalid:ring-destructive/20 tw:dark:aria-invalid:ring-destructive/40 tw:aria-invalid:border-destructive",
      className
    )}
    type="file"
    bind:files
    bind:value
    {...restProps}
  />
{:else}
  <input
    bind:this={ref}
    class={cn(
      "tw:border-input tw:bg-background tw:selection:bg-primary tw:dark:bg-input/30 tw:selection:text-primary-foreground tw:ring-offset-background tw:placeholder:text-muted-foreground tw:shadow-xs tw:flex tw:h-9 tw:w-full tw:min-w-0 tw:rounded-md tw:border tw:px-3 tw:py-1 tw:text-base tw:outline-none tw:transition-[color,box-shadow] tw:disabled:cursor-not-allowed tw:disabled:opacity-50 tw:md:text-sm",
      "tw:focus-visible:border-ring tw:focus-visible:ring-ring/50 tw:focus-visible:ring-[3px]",
      "tw:aria-invalid:ring-destructive/20 tw:dark:aria-invalid:ring-destructive/40 tw:aria-invalid:border-destructive",
      className
    )}
    {type}
    bind:value
    {...restProps}
  />
{/if}
