import type {
  PluginV2ProviderArgument,
  PluginV2ProviderOptions,
} from "$risu/plugins/plugins";
import { risuAPI } from "$risu/plugins/plugins";
import type { OpenAIChat } from "$risu/process/index.svelte";
import type { Message } from "$risu/storage/database.svelte";
import type { GlobalFetchArgs } from "$risu/globalApi.svelte";

import { AnthropicProvider } from "$ts/providers/anthropicProvider";
import { AWSProvider } from "$ts/providers/awsProvider";
import { BaseProvider } from "$ts/providers/baseProvider";
import { GoogleAIProvider } from "$ts/providers/googleaiProvider";
import type { VertexAICredential } from "$ts/providers/vertexaiProvider";
import { VertexAIProvider } from "$ts/providers/vertexaiProvider";
import * as InlayCache from "$ts/storage/inlayCache";
import * as LLMTranslateCache from "$ts/storage/llmTranslateCache";
import * as PluginDB from "$ts/storage/pluginDB";
import { getLLMDefinition, groupLLMDefinitionByProvider } from "$ts/llm";
import { Logger } from "$ts/logger";
import {
  PluginSettingsManager,
  getArgEx,
  setArgEx,
  risuFetchEx,
  getCommonSettings,
  getChatSettings,
  getMemorySettings,
  getTranslationSettings,
  getOtherSettings,
  PLUGIN_TITLE,
  PLUGIN_NAME,
  DEFAULT,
  PLUGIN_SETTING_DEFINITIONS,
  PLUGIN_SETTINGS_MANAGER,
  getLLMTokenizer,
} from "$ts/pluginSetting";
import type {
  PluginSettingType,
  PluginSettingOptions,
  PluginSettingDefinitions,
} from "$ts/pluginSettingBase";
import { PLUGIN_SETTING_TYPE } from "$ts/pluginSettingBase";
import type {
  LLMRole,
  LLMDefinition,
  CommonSettings,
  ChatSettings,
  MemorySettings,
  TranslationSettings,
} from "$ts/types";
import { LLM_ROLE, LLM_PROVIDER, LLM_FLAG, REQUEST_TYPE } from "$ts/types";
import { PluginTextEditorUI, PluginToastUI, PluginTimerUI } from "$ts/ui";
import { Utils } from "$ts/utils";

import "./app.css";
import { mount, unmount } from "svelte";
import App from "./App.svelte";
import { testModalOpen } from "$ts/stores.svelte";

import streamSaver from "streamsaver";
import { Zip, ZipDeflate } from "fflate";

class PluginSettingsUI {
  private static readonly ROOT_ID = `${PLUGIN_NAME}-pluginSettingsUI`;
  private static readonly MODAL_ID = `${PluginSettingsUI.ROOT_ID}-settingsModal`;
  private static readonly TOOLS_BUTTON_ID = `${PluginSettingsUI.ROOT_ID}-toolsButton`;
  private static readonly OPEN_SETTINGS_BUTTON_ID = `${PluginSettingsUI.ROOT_ID}-openSettingsButton`;
  private static readonly EXPORT_SETTINGS_BUTTON_ID = `${PluginSettingsUI.ROOT_ID}-exportSettingsButton`;
  private static readonly IMPORT_SETTINGS_BUTTON_ID = `${PluginSettingsUI.ROOT_ID}-importSettingsButton`;
  private static readonly CATEGORY_TABS_ID = `${PluginSettingsUI.ROOT_ID}-categoryTabs`;
  private static readonly CANCEL_SETTINGS_BUTTON_ID = `${PluginSettingsUI.ROOT_ID}-cancelSettingsButton`;
  private static readonly SAVE_SETTINGS_BUTTON_ID = `${PluginSettingsUI.ROOT_ID}-saveSettingsButton`;

  private static timeout: number;

  private readonly definitions: PluginSettingDefinitions;
  private readonly manager: PluginSettingsManager;

  private touchCount = 0;
  private touchStartTime = 0;

  constructor(definitions: PluginSettingDefinitions) {
    this.definitions = definitions;
    this.manager = new PluginSettingsManager(definitions);
  }

  public initialize(): void {
    this.dispose();

    const checkAndAdd = () => {
      // Check if sidebar last button exists
      const lastButton = document.querySelector(
        "div.rs-setting-cont-3 > button:last-child"
      );

      if (!lastButton) {
        PluginSettingsUI.timeout = window.setTimeout(checkAndAdd, 1000);
        return;
      }

      // Check if open settings button already exists
      const openSettingsButton = document.getElementById(
        PluginSettingsUI.OPEN_SETTINGS_BUTTON_ID
      );

      // Add open settings button if not exists
      if (!openSettingsButton) {
        this.addOpenButton(lastButton);
      }

      // Continue checking after 1 second
      PluginSettingsUI.timeout = window.setTimeout(checkAndAdd, 1000);
    };

    // Add shortcut to show plugin settings
    document.addEventListener("keydown", this.onKeydown);
    document.addEventListener("touchstart", this.onTouchStart);
    document.addEventListener("touchend", this.onTouchEnd);

    // Start first check
    PluginSettingsUI.timeout = window.setTimeout(checkAndAdd, 1000);
    Logger.debug("PluginSettingsUI initialized");
  }

  public dispose(): void {
    window.clearTimeout(PluginSettingsUI.timeout);

    document.removeEventListener("keydown", this.onKeydown);
    document.removeEventListener("touchstart", this.onTouchStart);
    document.removeEventListener("touchend", this.onTouchEnd);

    Logger.debug("PluginSettingsUI disposed");
  }

  private onKeydown = (e: KeyboardEvent): void => {
    if (e.ctrlKey && e.altKey && e.shiftKey && e.key.toLowerCase() === "p") {
      e.preventDefault();

      if (!document.getElementById(PluginSettingsUI.MODAL_ID)) {
        this.showModal();
      }
    }
  };

  private onTouchStart = (e: TouchEvent): void => {
    this.touchCount++;

    if (this.touchCount === 4) {
      if (Date.now() - this.touchStartTime > 300) {
        return;
      }

      this.touchCount = 0;

      const escKeyEvent = new KeyboardEvent("keydown", {
        key: "Escape",
        code: "Escape",
        keyCode: 27,
        which: 27,
        bubbles: true,
        cancelable: true,
      });

      document.dispatchEvent(escKeyEvent);

      if (!document.getElementById(PluginSettingsUI.MODAL_ID)) {
        this.showModal();
      }
    }

    if (this.touchCount === 1) {
      this.touchStartTime = Date.now();
    }
  };

  private onTouchEnd = (e: TouchEvent): void => {
    this.touchCount = 0;
  };

  private addOpenButton(lastButton: Element): void {
    const button = document.createElement("button");
    button.id = PluginSettingsUI.OPEN_SETTINGS_BUTTON_ID;
    button.className =
      "flex gap-2 items-center hover:text-textcolor text-textcolor2";
    button.innerHTML = `
     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide-icon lucide lucide-plug">
       <path d="M12 22v-5"></path><path d="M9 7V2"></path><path d="M15 7V2"></path><path d="M6 13V8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2Z"></path><path d="M18 8v5"></path><path d="M6 8v5"></path>
     </svg>
     <span>${PLUGIN_NAME} 설정</span>
   `;
    button.onclick = () => this.showModal();

    lastButton.parentNode?.insertBefore(button, lastButton.nextSibling);
  }

  private showModal(): void {
    const modal = document.createElement("div");
    modal.id = PluginSettingsUI.MODAL_ID;
    modal.className = "fixed inset-0 z-50 p-1 sm:p-2 bg-black/50";
    modal.tabIndex = -1;
    modal.innerHTML = `
      <div class="flex justify-center w-full h-full">
        <div class="flex flex-col p-3 sm:p-6 rounded-lg bg-zinc-900 w-full max-w-3xl h-full">
          <!-- Header -->
          <div class="flex justify-between items-center w-full mb-4">
            <h2 class="text-lg sm:text-2xl font-semibold text-zinc-100">${PLUGIN_NAME} 설정</h2>
            <div class="flex items-center gap-2">
              <button id="${
                PluginSettingsUI.TOOLS_BUTTON_ID
              }" class="p-2 text-zinc-400 hover:text-zinc-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                </svg>
              </button>
              <button id="${
                PluginSettingsUI.EXPORT_SETTINGS_BUTTON_ID
              }" class="p-2 text-zinc-400 hover:text-zinc-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
                </svg>
              </button>
              <button id="${
                PluginSettingsUI.IMPORT_SETTINGS_BUTTON_ID
              }" class="p-2 text-zinc-400 hover:text-zinc-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
              </button>
            </div>
          </div>

          <!-- Category Tabs -->
          <div class="w-full mb-3 mt-2">
            <div class="relative">
              <div id="${
                PluginSettingsUI.CATEGORY_TABS_ID
              }" class="flex overflow-x-auto pb-2 no-scrollbar">
                ${this.generateCategoryTabs()}
              </div>
            </div>

            <div class="border-b border-zinc-700 mt-1 mb-3"></div>
          </div>

          <!-- Scrollable Container -->
          <div class="flex-1 overflow-y-auto min-h-0">
            ${this.generateSettingsContent()}
          </div>

          <!-- Buttons -->
          <div class="flex justify-end mt-4 pt-2 gap-2 border-t border-zinc-700">
            <button id="${
              PluginSettingsUI.CANCEL_SETTINGS_BUTTON_ID
            }" class="px-4 py-2 rounded bg-zinc-800 text-zinc-200 hover:bg-red-500 transition-colors">취소</button>
            <button id="${
              PluginSettingsUI.SAVE_SETTINGS_BUTTON_ID
            }" class="px-4 py-2 rounded bg-zinc-800 text-zinc-200 hover:bg-blue-500 transition-colors">저장</button>
          </div>
        </div>
      </div>
    `;

    this.bindEvents(modal);
    document.body.appendChild(modal);
  }

  private generateCategoryTabs(): string {
    const categories = [
      ...new Set(Object.values(this.definitions).map((def) => def.category[0])),
    ];

    return categories
      .map((category, index) => {
        const isActive = index === 0;

        return `
        <button class="px-3 py-2 mr-2 whitespace-nowrap rounded-full text-sm font-medium flex-shrink-0 transition-colors ${
          isActive
            ? "bg-blue-500 text-zinc-100"
            : "bg-zinc-800 hover:bg-zinc-700 text-zinc-100"
        }" data-category="${category}">
          ${category}
        </button>
      `;
      })
      .join("");
  }

  private generateSettingsContent(): string {
    const categories = this.groupSettingsByCategory();
    let content = "";

    for (const [category, settings] of Object.entries(categories)) {
      content += `
       <div class="mb-4">
         <h3 class="text-lg text-zinc-100 font-semibold mb-2">${category}</h3>
         ${settings
           .map(([key, setting]) => this.generateSettingField(key, setting))
           .join("")}
       </div>
     `;
    }

    return content;
  }

  private generateSettingField(
    key: string,
    setting: {
      type: PluginSettingType;
      displayName: string;
      options?: PluginSettingOptions;
    }
  ): string {
    const value = getArgEx(`${PLUGIN_NAME}::${key}`);

    // Handle boolean type - checkbox
    if (setting.type === PLUGIN_SETTING_TYPE.BOOLEAN) {
      const isChecked = Utils.isTrueString(value);

      return `
        <div class="mb-2">
          <label class="flex items-center gap-3 text-zinc-200 cursor-pointer">
            <input type="checkbox" class="w-4 h-4 rounded border-zinc-600 text-blue-500 focus:ring-blue-500 focus:ring-offset-zinc-900 bg-zinc-800" data-key="${key}" ${
        isChecked ? "checked" : ""
      }>
            <span>${setting.displayName}</span>
          </label>
        </div>
      `;
    }

    // Handle integer/float type with min/max constraints
    if (
      setting.type === PLUGIN_SETTING_TYPE.INTEGER ||
      setting.type === PLUGIN_SETTING_TYPE.FLOAT
    ) {
      const step = setting.type === PLUGIN_SETTING_TYPE.INTEGER ? 1 : 0.01;
      const minAttr =
        setting.options?.min !== undefined
          ? `min="${setting.options.min}"`
          : "";
      const maxAttr =
        setting.options?.max !== undefined
          ? `max="${setting.options.max}"`
          : "";

      return `
          <div class="mb-2">
            <label class="block">
              <span class="mb-1 block text-zinc-200">${
                setting.displayName
              }</span>
              <input type="number" class="w-full px-3 py-2 rounded bg-zinc-800 border border-zinc-700 text-zinc-200 focus:outline-none focus:ring-1 focus:ring-blue-500" placeholder="${Utils.escapeHTML(
                setting.options?.placeholder || ""
              )}" data-key="${key}" value="${value}" step="${step}" ${minAttr} ${maxAttr}>
            </label>
          </div>
        `;
    }

    // Handle string type with candidates - dropdown
    if (
      setting.type === PLUGIN_SETTING_TYPE.STRING &&
      setting.options?.candidates?.length
    ) {
      if (setting.options.allowNonCandidate) {
        return `
        <div class="mb-2">
          <label class="block">
            <span class="mb-1 block text-zinc-200">${setting.displayName}</span>
            <input class="w-full px-3 py-2 rounded bg-zinc-800 border border-zinc-700 text-zinc-200 focus:outline-none focus:ring-1 focus:ring-blue-500" data-key="${key}" value="${Utils.escapeHTML(
          value || ""
        )}" list="${key}-options">
            <datalist id="${key}-options">
            ${setting.options.candidates
              .map(
                (candidate) =>
                  `<option value="${Utils.escapeHTML(candidate)}"></option>`
              )
              .join("")}
            </datalist>
          </label>
        </div>
      `;
      }

      return `
        <div class="mb-2">
          <label class="block">
            <span class="mb-1 block text-zinc-200">${setting.displayName}</span>
            <select class="w-full px-3 py-2 rounded bg-zinc-800 border border-zinc-700 text-zinc-200 focus:outline-none focus:ring-1 focus:ring-blue-500" data-key="${key}">
              ${setting.options.candidates
                .map(
                  (candidate) => `
                  <option value="${Utils.escapeHTML(candidate)}" ${
                    value === candidate ? "selected" : ""
                  }>
                    ${Utils.escapeHTML(candidate)}
                  </option>
                `
                )
                .join("")}
            </select>
          </label>
        </div>
      `;
    }

    // Default text input for other cases
    if (setting.options?.useEditor) {
      return `
        <div class="mb-2">
          <label class="block">
            <span class="mb-1 block text-zinc-200">${setting.displayName}</span>
            <textarea class="w-full px-3 py-2 resize-none overflow-hidden rounded border border-zinc-700 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-zinc-800 text-zinc-200" rows="1" wrap="off" placeholder="${Utils.escapeHTML(
              setting.options?.placeholder || ""
            )}" data-useEditor="1" data-key="${key}">${Utils.escapeHTML(
        value
      )}</textarea>
          </label>
        </div>
      `;
    }

    return `
      <div class="mb-2">
        <label class="block">
          <span class="mb-1 block text-zinc-200">${setting.displayName}</span>
          <input type="text" class="w-full px-3 py-2 rounded bg-zinc-800 border border-zinc-700 text-zinc-200 focus:outline-none focus:ring-1 focus:ring-blue-500" placeholder="${Utils.escapeHTML(
            setting.options?.placeholder || ""
          )}" data-key="${key}" value="${Utils.escapeHTML(value)}">
        </label>
      </div>
    `;
  }

  private groupSettingsByCategory(): Record<string, [string, any][]> {
    const groups: Record<string, [string, any][]> = {};

    Object.entries(this.definitions).forEach(([key, definition]) => {
      const category = definition.category.join(" > ");
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push([key, definition]);
    });

    return groups;
  }

  private bindEvents(modal: HTMLElement): void {
    const toolsButton = modal.querySelector(
      "#" + CSS.escape(PluginSettingsUI.TOOLS_BUTTON_ID)
    );
    const exportButton = modal.querySelector(
      "#" + CSS.escape(PluginSettingsUI.EXPORT_SETTINGS_BUTTON_ID)
    );
    const importButton = modal.querySelector(
      "#" + CSS.escape(PluginSettingsUI.IMPORT_SETTINGS_BUTTON_ID)
    );
    const categoryTabs = modal.querySelector(
      "#" + CSS.escape(PluginSettingsUI.CATEGORY_TABS_ID)
    );
    const cancelButton = modal.querySelector(
      "#" + CSS.escape(PluginSettingsUI.CANCEL_SETTINGS_BUTTON_ID)
    );
    const saveButton = modal.querySelector(
      "#" + CSS.escape(PluginSettingsUI.SAVE_SETTINGS_BUTTON_ID)
    );

    modal.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        modal.remove();
      }
    });

    toolsButton?.addEventListener("click", () => {
      modal.remove();
      PluginToolsUI.showModal();
    });

    exportButton?.addEventListener("click", async () => {
      const confirmed = await Utils.confirmEx(
        "현재 설정을 브라우저 DB에 저장합니까?"
      );

      if (!confirmed) {
        return;
      }

      const json = this.manager.toJSON();

      await PluginDB.put<Record<string, string>>("settings", json);

      Logger.debug("Exported settings:", json);
      window.alert("현재 설정이 저장되었습니다.");
    });

    importButton?.addEventListener("click", async () => {
      const json = await PluginDB.get<Record<string, string>>("settings");

      if (!json) {
        Logger.debug("No settings found to import");
        window.alert("저장된 설정이 없습니다.");
        return;
      }

      const confirmed = await Utils.confirmEx(
        "저장된 설정을 불러옵니까? 현재 설정을 덮어쓰기 합니다."
      );

      if (!confirmed) {
        return;
      }

      this.manager.fromJSON(json);

      modal.remove();
      this.showModal();

      Logger.debug("Imported settings:", json);
      window.alert("설정을 불러왔습니다.");
    });

    categoryTabs
      ?.querySelectorAll("button[data-category]")
      .forEach((button) => {
        button.addEventListener("click", (e) => {
          const category = (e.currentTarget as HTMLElement).getAttribute(
            "data-category"
          );

          if (!category) return;

          categoryTabs
            .querySelectorAll("button[data-category]")
            .forEach((btn) => {
              btn.classList.remove("bg-blue-500", "text-zinc-100");
              btn.classList.add(
                "bg-zinc-800",
                "hover:bg-zinc-700",
                "text-zinc-100"
              );
            });

          (e.currentTarget as HTMLElement).classList.remove(
            "bg-zinc-800",
            "hover:bg-zinc-700",
            "text-zinc-100"
          );
          (e.currentTarget as HTMLElement).classList.add(
            "bg-blue-500",
            "text-zinc-100"
          );

          const headings = Array.from(modal.querySelectorAll("h3"));
          const partialMatch = headings.find((heading) =>
            heading.textContent?.startsWith(category)
          );

          if (partialMatch) {
            partialMatch.scrollIntoView({ behavior: "auto" });
          }
        });
      });

    modal
      .querySelectorAll('textarea[data-useEditor="1"]')
      .forEach((textarea) => {
        textarea.addEventListener("focus", async (e) => {
          const target = e.currentTarget as HTMLTextAreaElement;
          const key = target.dataset.key;

          if (!key) return;

          const definition = this.definitions[key];
          const result = await PluginTextEditorUI.showModal(
            definition.displayName,
            target.value,
            false
          );

          if (result.confirmed && result.value != null) {
            target.value = result.value;
          }

          target.blur();
          e.preventDefault();
        });
      });

    cancelButton?.addEventListener("click", () => {
      modal.remove();
    });

    saveButton?.addEventListener("click", () => {
      // Save all form values
      const inputs = modal.querySelectorAll<
        HTMLInputElement | HTMLSelectElement
      >("input[data-key], select[data-key], textarea[data-key]");

      inputs.forEach((input: HTMLInputElement | HTMLSelectElement) => {
        const key = input.dataset.key;

        if (!key) return;

        const value =
          input instanceof HTMLInputElement && input.type === "checkbox"
            ? String(Number(input.checked))
            : input.value;

        setArgEx(`${PLUGIN_NAME}::${key}`, value);
      });

      modal.remove();
    });
  }
}

class PluginToolsUI {
  private static readonly ROOT_ID = `${PLUGIN_NAME}-pluginToolsUI`;
  private static readonly MODAL_ID = `${PluginToolsUI.ROOT_ID}-modal`;
  private static readonly CLOSE_TOOLS_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-closeToolsButton`;
  private static readonly EXPORT_SETTINGS_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-exportSettingsButton`;
  private static readonly IMPORT_SETTINGS_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-importSettingsButton`;
  private static readonly EXPORT_TRANSLATION_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-exportTranslationButton`;
  private static readonly IMPORT_TRANSLATION_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-importTranslationButton`;
  private static readonly CLEAR_TRANSLATION_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-clearTranslationButton`;
  private static readonly EXPORT_INLAY_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-exportInlayButton`;
  private static readonly IMPORT_INLAY_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-importInlayButton`;
  private static readonly CLEAR_INLAY_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-clearInlayButton`;
  private static readonly EXPORT_CHAT_INLAY_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-exportChatInlayButton`;
  private static readonly GITHUB_COPILOT_MANAGER_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-githubCopilotManagerButton`;
  private static readonly SPLIT_CHAT_FOR_HYPA_V3_BUTTON_ID = `${PluginToolsUI.ROOT_ID}-splitChatForHypaV3Button`;

  public static showModal(): void {
    const modal = document.createElement("div");
    modal.id = PluginToolsUI.MODAL_ID;
    modal.className = "fixed inset-0 z-50 p-1 sm:p-2 bg-black/50";
    modal.tabIndex = -1;
    modal.innerHTML = `
      <div class="flex justify-center w-full h-full">
        <div class="flex flex-col p-3 sm:p-6 rounded-lg bg-zinc-900 w-full max-w-3xl h-full">
          <!-- Header -->
          <div class="flex justify-between items-center w-full mb-4">
            <h2 class="text-lg sm:text-2xl font-semibold text-zinc-100">도구</h2>
            <button id="${PluginToolsUI.CLOSE_TOOLS_BUTTON_ID}" class="p-2 text-zinc-400 hover:text-zinc-200 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>

          <!-- Scrollable Container -->
          <div class="flex-1 overflow-y-auto min-h-0">
            <!-- Plugin Settings Section -->
            <div class="mb-6 p-4 rounded-lg bg-zinc-800">
              <h3 class="mb-3 text-zinc-200 font-medium">플러그인 설정</h3>
              <div class="grid grid-cols-2 gap-4">
                <button id="${PluginToolsUI.EXPORT_SETTINGS_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    <span class="text-zinc-200">파일로 내보내기</span>
                  </div>
                </button>

                <button id="${PluginToolsUI.IMPORT_SETTINGS_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    <span class="text-zinc-200">파일에서 가져오기</span>
                  </div>
                </button>
              </div>
            </div>

            <!-- Translation Cache Section -->
            <div class="mb-6 p-4 rounded-lg bg-zinc-800">
              <h3 class="mb-3 text-zinc-200 font-medium">번역 캐시</h3>
              <div class="grid grid-cols-2 gap-4">
                <button id="${PluginToolsUI.EXPORT_TRANSLATION_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    <span class="text-zinc-200">내보내기</span>
                  </div>
                </button>

                <button id="${PluginToolsUI.IMPORT_TRANSLATION_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    <span class="text-zinc-200">가져오기</span>
                  </div>
                </button>

                <button id="${PluginToolsUI.CLEAR_TRANSLATION_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>
                    </svg>
                    <span class="text-zinc-200">지우기</span>
                  </div>
                </button>
              </div>
            </div>
 
            <!-- Inlay Cache Section -->
            <div class="mb-6 p-4 rounded-lg bg-zinc-800">
              <h3 class="mb-3 text-zinc-200 font-medium">인레이 캐시</h3>
              <div class="grid grid-cols-2 gap-4">
                <button id="${PluginToolsUI.EXPORT_INLAY_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    <span class="text-zinc-200">내보내기</span>
                  </div>
                </button>
            
                <button id="${PluginToolsUI.IMPORT_INLAY_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                  <span class="text-zinc-200">가져오기</span>
                  </div>
                </button>

                <button id="${PluginToolsUI.CLEAR_INLAY_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>
                    </svg>
                    <span class="text-zinc-200">지우기</span>
                  </div>
                </button>

                <button id="${PluginToolsUI.EXPORT_CHAT_INLAY_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M10 10h4"/><path d="M10 13h4"/><path d="M10 16h4"/><polyline points="9 18 12 21 15 18"/>
                    </svg>
                    <span class="text-zinc-200">현재 챗 내보내기</span>
                  </div>
                </button>
              </div>
            </div>

            <!-- Other Section -->
            <div class="mb-6 p-4 rounded-lg bg-zinc-800">
              <h3 class="mb-3 text-zinc-200 font-medium">기타</h3>
              <div class="grid grid-cols-2 gap-4">
                <button id="${PluginToolsUI.GITHUB_COPILOT_MANAGER_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors">
                  <div class="flex flex-col items-center gap-2">
                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke-linecap="round" stroke-linejoin="round">
                       <path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.385.6.11.82-.26.82-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.385-1.333-1.754-1.333-1.754-1.09-.745.082-.73.082-.73 1.205.085 1.84 1.236 1.84 1.236 1.07 1.835 2.807 1.305 3.492.998.11-.775.418-1.305.762-1.605-2.665-.3-5.466-1.335-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.125-.303-.535-1.523.115-3.176 0 0 1.005-.322 3.3 1.23a11.5 11.5 0 0 1 6 0c2.28-1.552 3.285-1.23 3.285-1.23.655 1.653.245 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.43.37.81 1.096.81 2.21v3.285c0 .32.21.694.825.576C20.565 21.795 24 17.295 24 12c0-6.63-5.37-12-12-12z"/>
                     </svg>
                    <span class="text-zinc-200">GitHub Copilot 토큰 관리자</span>
                  </div>
                </button>
                
                <button id="${PluginToolsUI.SPLIT_CHAT_FOR_HYPA_V3_BUTTON_ID}" class="p-4 rounded-lg bg-zinc-700 hover:bg-zinc-500 text-zinc-400 hover:text-zinc-200 transition-colors" title="PC는 Shift+클릭, 모바일은 빠르게 2번 터치하면 대체 동작을 수행합니다.">
                  <div class="flex flex-col items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M3 3h18v18H3z"/><path d="M11 3l-2 3 2 3-2 3 2 3-2 3 2 3"/><path d="M15 3l-2 3 2 3-2 3 2 3-2 3 2 3"/>
                    </svg>
                    <span class="text-zinc-200">하이파 V3용 현재 챗 분할</span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    this.bindEvents(modal);
    document.body.appendChild(modal);
  }

  private static bindEvents(modal: HTMLElement): void {
    const closeButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.CLOSE_TOOLS_BUTTON_ID)
    );
    const exportSettingsButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.EXPORT_SETTINGS_BUTTON_ID)
    );
    const importSettingsButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.IMPORT_SETTINGS_BUTTON_ID)
    );
    const exportTranslationButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.EXPORT_TRANSLATION_BUTTON_ID)
    );
    const importTranslationButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.IMPORT_TRANSLATION_BUTTON_ID)
    );
    const clearTranslationButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.CLEAR_TRANSLATION_BUTTON_ID)
    );
    const exportInlayButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.EXPORT_INLAY_BUTTON_ID)
    );
    const importInlayButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.IMPORT_INLAY_BUTTON_ID)
    );
    const clearInlayButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.CLEAR_INLAY_BUTTON_ID)
    );
    const exportChatInlayButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.EXPORT_CHAT_INLAY_BUTTON_ID)
    );
    const githubCopilotManagerButton = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.GITHUB_COPILOT_MANAGER_BUTTON_ID)
    );
    const splitChatForHypaV3Button = modal.querySelector(
      "#" + CSS.escape(PluginToolsUI.SPLIT_CHAT_FOR_HYPA_V3_BUTTON_ID)
    ) as HTMLElement;

    const splitChatForHypaV3ButtonHandler = createDualActionHandler(
      splitChatForHypaV3Button,
      {
        onMainAction: () => this.splitChatForHypaV3(true),
        onAlternativeAction: () => this.splitChatForHypaV3(false),
      }
    );

    modal.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        splitChatForHypaV3ButtonHandler.destroy();
        modal.remove();
      }
    });

    closeButton?.addEventListener("click", () => {
      splitChatForHypaV3ButtonHandler.destroy();
      modal.remove();
    });

    exportSettingsButton?.addEventListener("click", async () => {
      await this.exportSettings();
    });

    importSettingsButton?.addEventListener("click", async () => {
      await this.importSettings();
    });

    exportTranslationButton?.addEventListener("click", async () => {
      await this.exportTranslation();
    });

    importTranslationButton?.addEventListener("click", async () => {
      await this.importTranslation();
    });

    clearTranslationButton?.addEventListener("click", async () => {
      await this.clearTranslation();
    });

    exportInlayButton?.addEventListener("click", async () => {
      await this.exportInlay();
    });

    importInlayButton?.addEventListener("click", async () => {
      await this.importInlay();
    });

    clearInlayButton?.addEventListener("click", async () => {
      await this.clearInlay();
    });

    exportChatInlayButton?.addEventListener("click", async () => {
      await this.exportChatInlay();
    });

    githubCopilotManagerButton?.addEventListener("click", () => {
      modal.remove();
      GithubCopilotTokenManagerUI.showModal();
    });
  }

  private static async exportSettings(): Promise<void> {
    try {
      const data = PLUGIN_SETTINGS_MANAGER.toJSON();
      const jsonData = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonData], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.download = `${PLUGIN_NAME}-${Utils.getTimestamp()}.json`;
      a.href = url;

      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      URL.revokeObjectURL(url);
    } catch (error) {
      Logger.error("Failed to export plugin settings:", error);
      window.alert("플러그인 설정 내보내기에 실패했습니다.");
    }
  }

  private static async importSettings(): Promise<void> {
    const input = document.createElement("input");
    input.accept = "application/json";
    input.type = "file";

    input.addEventListener("change", async () => {
      const file = input.files?.[0];

      if (!file) return;

      const confirmed = await Utils.confirmEx(
        `${file.name}에서 플러그인 설정을 가져오시겠습니까?`
      );

      if (!confirmed) {
        return;
      }

      try {
        const jsonData = await file.text();
        const data = JSON.parse(jsonData);

        for (const [key, value] of Object.entries(data)) {
          if (typeof key !== "string" || typeof value !== "string") {
            window.alert("파일이 올바른 플러그인 설정이 아닙니다.");
            return;
          }
        }

        PLUGIN_SETTINGS_MANAGER.fromJSON(data);

        window.alert(`플러그인 설정을 성공적으로 가져왔습니다.`);
      } catch (error) {
        Logger.error("Failed to import plugin settings:", error);
        window.alert("플러그인 설정 가져오기에 실패했습니다.");
      }
    });

    input.click();
  }

  private static async exportTranslation(): Promise<void> {
    try {
      const data = await LLMTranslateCache.getAll();
      const dataLength = Object.keys(data).length;

      if (dataLength === 0) {
        window.alert("내보낼 번역 캐시가 없습니다.");
        return;
      }

      const jsonData = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonData], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.download = `risu-translation-cache-${Utils.getTimestamp()}.json`;
      a.href = url;

      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      URL.revokeObjectURL(url);
    } catch (error) {
      Logger.error("Failed to export translation cache:", error);
      window.alert("번역 캐시 내보내기에 실패했습니다.");
    }
  }

  private static async importTranslation(): Promise<void> {
    const input = document.createElement("input");
    input.accept = "application/json";
    input.type = "file";

    input.addEventListener("change", async () => {
      const file = input.files?.[0];

      if (!file) return;

      const confirmed = await Utils.confirmEx(
        `${file.name}에서 번역 캐시를 가져오시겠습니까?`
      );

      if (!confirmed) {
        return;
      }

      try {
        const jsonData = await file.text();
        const data = JSON.parse(jsonData);
        const dataLength = Object.keys(data).length;

        for (const [key, value] of Object.entries(data)) {
          if (typeof key !== "string" || typeof value !== "string") {
            window.alert("파일이 올바른 번역 캐시가 아닙니다.");
            return;
          }
        }

        await LLMTranslateCache.putAll(data);

        window.alert(`${dataLength}개의 번역 캐시를 성공적으로 가져왔습니다.`);
      } catch (error) {
        Logger.error("Failed to import translation cache:", error);
        window.alert("번역 캐시 가져오기에 실패했습니다.");
      }
    });

    input.click();
  }

  private static async clearTranslation(): Promise<void> {
    const count = await LLMTranslateCache.count();
    const confirmed = await Utils.confirmEx(
      `${count}개의 번역 캐시를 지우시겠습니까?`
    );

    if (!confirmed) {
      return;
    }

    try {
      await LLMTranslateCache.clear();

      window.alert("번역 캐시를 성공적으로 지웠습니다.");
    } catch (error) {
      Logger.error("Failed to clear translation cache:", error);
      window.alert("번역 캐시 지우기에 실패했습니다.");
    }
  }

  private static async exportInlay(): Promise<void> {
    try {
      const totalCount = await InlayCache.count();

      if (totalCount === 0) {
        window.alert("내보낼 인레이 캐시가 없습니다.");
        return;
      }

      const filename = `risu-inlay-cache-${Utils.getTimestamp()}.bin`;
      const fileStream = streamSaver.createWriteStream(filename); // Create file stream with StreamSaver
      const writer = fileStream.getWriter();
      const batchSize = 10; // Number of records to process at once
      let exportedCount = 0;

      PluginProgressUI.show("인레이 캐시 내보내는 중...");

      while (true) {
        const data = await InlayCache.getRange(exportedCount, batchSize);
        const dataLength = Object.keys(data).length;

        if (dataLength === 0) {
          break;
        }

        const jsonData = JSON.stringify(data);
        const bytesData = new TextEncoder().encode(jsonData);
        const bytesLength = new Uint32Array([bytesData.byteLength]);

        await writer.write(new Uint8Array(bytesLength.buffer)); // Write 4-byte length header
        await writer.write(bytesData); // Write JSON data

        exportedCount += dataLength;
        PluginProgressUI.updateProgress(exportedCount / totalCount);

        // Wait to allow UI thread to update
        await new Promise((resolve) => setTimeout(resolve, 0));
      }

      await writer.close();

      PluginProgressUI.updateMessage(
        `${exportedCount}개의 인레이 캐시 내보냄!`
      );
      PluginProgressUI.updateProgress(1);

      setTimeout(() => {
        PluginProgressUI.hide();
      }, 2000);
    } catch (error) {
      PluginProgressUI.hide();

      Logger.error("Failed to export inlay cache:", error);
      window.alert("인레이 캐시 내보내기에 실패했습니다.");
    }
  }

  private static async importInlay(): Promise<void> {
    const input = document.createElement("input");
    input.accept = ".bin";
    input.type = "file";

    input.addEventListener("change", async () => {
      const file = input.files?.[0];

      if (!file) return;

      const confirmed = await Utils.confirmEx(
        `${file.name}에서 인레이 캐시를 가져오시겠습니까?`
      );

      if (!confirmed) {
        return;
      }

      try {
        const fileStream = file.stream();
        const reader = fileStream.getReader();
        let buffer = new Uint8Array(0);
        let readingLength = true;
        let dataLength = 0;
        let importedCount = 0;
        let bytesRead = 0;

        PluginProgressUI.show("인레이 캐시 가져오는 중...");

        while (true) {
          const { value, done } = await reader.read();

          if (done) break;

          const newBuffer = new Uint8Array(buffer.length + value.length);
          newBuffer.set(buffer);
          newBuffer.set(value, buffer.length); // Add chunk to buffer
          buffer = newBuffer;

          while (buffer.length > 0) {
            if (readingLength) {
              if (buffer.length < 4) break;

              dataLength = new Uint32Array(buffer.slice(0, 4).buffer)[0]; // Read 4-byte length header
              buffer = buffer.slice(4);
              readingLength = false;
            } else {
              if (buffer.length < dataLength) break;

              const bytesData = buffer.slice(0, dataLength); // Read JSON data
              buffer = buffer.slice(dataLength);
              readingLength = true;

              const jsonData = new TextDecoder().decode(bytesData);
              const data = JSON.parse(jsonData);

              for (const [key, value] of Object.entries(data)) {
                if (typeof key !== "string" || typeof value !== "object") {
                  reader.cancel();

                  PluginProgressUI.hide();
                  window.alert("파일이 올바른 인레이 캐시가 아닙니다.");
                  return;
                }
              }

              await InlayCache.putAll(data);

              importedCount += Object.keys(data).length;
            }
          }

          bytesRead += value.length;
          PluginProgressUI.updateProgress(Math.min(bytesRead / file.size, 1));

          // Wait to allow UI thread to update
          await new Promise((resolve) => setTimeout(resolve, 0));
        }

        PluginProgressUI.updateMessage(
          `${importedCount}개의 인레이 캐시 가져옴!`
        );
        PluginProgressUI.updateProgress(1);

        setTimeout(() => {
          PluginProgressUI.hide();
        }, 2000);
      } catch (error) {
        PluginProgressUI.hide();

        Logger.error("Failed to import inlay cache:", error);
        window.alert("인레이 캐시 가져오기에 실패했습니다.");
      }
    });

    input.click();
  }

  private static async clearInlay(): Promise<void> {
    const count = await InlayCache.count();
    const confirmed = await Utils.confirmEx(
      `${count}개의 인레이 캐시를 지우시겠습니까?`
    );

    if (!confirmed) {
      return;
    }

    try {
      await InlayCache.clear();

      window.alert("인레이 캐시를 성공적으로 지웠습니다.");
    } catch (error) {
      Logger.error("Failed to clear inlay cache:", error);
      window.alert("인레이 캐시 지우기에 실패했습니다.");
    }
  }

  private static async exportChatInlay(): Promise<void> {
    const inlayPattern =
      /{{(?:inlayed|inlay)::([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})}}/g;
    const base64Pattern = /^data:image\/([a-z]+);base64,(.+)$/i;

    try {
      const currentChar = risuAPI.getChar();
      const currentChat = currentChar?.chats?.[currentChar.chatPage];
      const currentMessages = currentChat?.message;

      if (!currentMessages || currentMessages.length === 0) {
        window.alert("현재 챗에 메시지가 없습니다.");
        return;
      }

      // Collect all inlay IDs from messages
      const inlayIds = new Set<string>();

      for (const message of currentMessages) {
        if (!message.data) continue;

        const matches = message.data.matchAll(inlayPattern);

        for (const match of matches) {
          inlayIds.add(match[1]);
        }
      }

      if (inlayIds.size === 0) {
        window.alert("현재 챗에 인레이 이미지가 없습니다.");
        return;
      }

      const filename = `risu-chat-inlay-${Utils.getTimestamp()}.zip`;
      const fileStream = streamSaver.createWriteStream(filename);
      const writer = fileStream.getWriter();

      PluginProgressUI.show("인레이 이미지 내보내는 중...");

      // Create fflate zip with callback for chunks
      const zip = new Zip((err, data, final) => {
        if (err) {
          writer.abort();
          throw err;
        }

        // Write chunk to stream
        if (data.length > 0) {
          writer.write(data);
        }

        // Close the stream when zip is complete
        if (final) {
          writer.close();

          PluginProgressUI.updateMessage("인레이 이미지 내보내기 완료!");
          PluginProgressUI.updateProgress(1);

          setTimeout(() => {
            PluginProgressUI.hide();
          }, 2000);
        }
      });

      let processedCount = 0;
      let imageCount = 0;

      for (const inlayId of inlayIds) {
        try {
          const data = await InlayCache.get(inlayId);

          if (!data) continue;

          // Only process image type inlays
          if (data.type !== "image" || !data.data) continue;

          // Extract base64 data (remove data:image/xxx;base64, prefix)
          const match = data.data.match(base64Pattern);

          if (!match) continue;

          const [, dataExt, base64Image] = match;
          const extension = data.ext || dataExt || "png";
          const fileName = data.name
            ? data.name.includes(".")
              ? data.name
              : `${data.name}.${extension}`
            : `${inlayId}.${extension}`;
          const bytesImage = Utils.base64ToUint8Array(base64Image);

          // Add file to zip with compression
          const fileEntry = new ZipDeflate(fileName, { level: 6 });

          zip.add(fileEntry);
          fileEntry.push(bytesImage, true);

          imageCount++;
        } catch (error) {
          Logger.error(`Error processing inlay ${inlayId}:`, error);
        }

        processedCount++;
        PluginProgressUI.updateProgress(processedCount / inlayIds.size);

        // Wait to allow UI thread to update
        await new Promise((resolve) => setTimeout(resolve, 0));
      }

      // Check if any images were found before finalizing
      if (imageCount === 0) {
        writer.abort();

        PluginProgressUI.hide();
        window.alert("현재 챗에 인레이 이미지가 없습니다.");
        return;
      }

      // Finalize the zip
      zip.end();
    } catch (error) {
      PluginProgressUI.hide();

      Logger.error("Failed to export chat inlay images:", error);
      window.alert("인레이 이미지 내보내기에 실패했습니다.");
    }
  }

  private static splitChatForHypaV3(preserveOrphanedMemory: boolean): void {
    const currentChar = risuAPI.getChar();
    const currentChat = currentChar?.chats?.[currentChar.chatPage];
    const currentMessages = currentChat?.message;

    if (!currentMessages || currentMessages.length === 0) {
      window.alert("현재 챗에 메시지가 없습니다.");
      return;
    }

    const lastSummary =
      currentChat.hypaV3Data?.summaries?.[
        currentChat.hypaV3Data.summaries.length - 1
      ];

    if (!lastSummary) {
      window.alert("현재 챗에 하이파 V3 데이터가 없습니다.");
      return;
    }

    const lastChatIndex = currentMessages.findIndex(
      (message) => message.chatId === [...lastSummary.chatMemos].at(-1)
    );

    if (lastChatIndex === -1) {
      window.alert(
        "하이파 V3의 가장 마지막 요약본과 연결된 메시지를 찾을 수 없습니다."
      );
      return;
    }

    if (currentMessages.length === lastChatIndex + 1) {
      window.alert(
        "요약되지 않은 새 메시지가 없습니다. 분할이 필요하지 않습니다."
      );
      return;
    }

    const summarizedChat = structuredClone(currentChat);
    summarizedChat.name += " 요약";
    summarizedChat.message.splice(lastChatIndex + 1); // Summarized chat: Including from 0 to the last chat index
    currentChar.chats.unshift(summarizedChat);

    const unsummarizedChat = structuredClone(currentChat);
    unsummarizedChat.name += " 비요약";
    unsummarizedChat.message.splice(0, lastChatIndex); // Unsummarized chat: From the last chat index to the end

    if (!preserveOrphanedMemory) {
      const lastChatMemo =
        lastSummary.chatMemos[lastSummary.chatMemos.length - 1];

      unsummarizedChat.hypaV3Data?.summaries.forEach((summary) => {
        summary.chatMemos = [lastChatMemo];
      });
    }

    currentChar.chats.unshift(unsummarizedChat);

    if (preserveOrphanedMemory) {
      window.alert(
        "현재 챗이 분할되었습니다: 요약/비요약 챗이 생성됨. 고아 메모리 보존을 켜야 합니다."
      );
    } else {
      window.alert(
        "현재 챗이 분할되었습니다: 비요약 챗의 모든 요약본을 처음 메시지에 링크함. 고아 메모리 보존을 꺼도 됩니다."
      );
    }
  }
}

class GithubCopilotTokenManagerUI {
  private static readonly ROOT_ID = `${PLUGIN_NAME}-githubCopilotTokenManagerUI`;
  private static readonly MODAL_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-modal`;
  private static readonly CLOSE_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-closeButton`;
  private static readonly TOKEN_INPUT_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-tokenInput`;
  private static readonly GENERATE_TOKEN_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-generateTokenButton`;
  private static readonly CHECK_STATUS_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-checkStatusButton`;
  private static readonly GET_MODELS_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-getModelsButton`;
  private static readonly AUTO_CONFIG_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-autoConfigButton`;

  private static readonly GENERATE_DIALOG_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-generateDialog`;
  private static readonly GENERATE_CLOSE_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-generateCloseButton`;
  private static readonly GENERATE_COPY_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-generateCopyButton`;
  private static readonly GENERATE_CANCEL_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-generateCancelButton`;
  private static readonly GENERATE_CONFIRM_BUTTON_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-generateConfirmButton`;

  private static readonly STATUS_CONTAINER_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-statusContainer`;
  private static readonly MODELS_CONTAINER_ID = `${GithubCopilotTokenManagerUI.ROOT_ID}-modelsContainer`;

  private static readonly CLIENT_ID = "01ab8ac9400c4e429b23";
  private static readonly TOKEN_ARG_KEY = "tools_githubCopilotToken";

  public static showModal(): void {
    const modal = document.createElement("div");

    modal.id = GithubCopilotTokenManagerUI.MODAL_ID;
    modal.className = "fixed inset-0 z-50 p-1 sm:p-2 bg-black/50";
    modal.tabIndex = -1;
    modal.innerHTML = `
      <div class="flex justify-center w-full h-full">
        <div class="flex flex-col p-3 sm:p-6 rounded-lg bg-zinc-900 w-full max-w-3xl h-full">
          <!-- Header -->
          <div class="flex justify-between items-center w-full mb-4">
            <h2 class="text-lg sm:text-2xl font-semibold text-zinc-100">GitHub Copilot 토큰 관리자</h2>
            <button id="${GithubCopilotTokenManagerUI.CLOSE_BUTTON_ID}" class="p-2 text-zinc-400 hover:text-zinc-200 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          
          <!-- Scrollable Container -->
          <div class="flex-1 overflow-y-auto min-h-0">
            <div class="mb-4">
              <label class="block mb-2 text-zinc-300">토큰</label>
              <input 
                type="text" 
                id="${GithubCopilotTokenManagerUI.TOKEN_INPUT_ID}" 
                class="w-full px-3 py-2 rounded bg-zinc-800 border border-zinc-700 text-zinc-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                placeholder="토큰 생성 버튼을 누르세요"
              />
            </div>
            
            <!-- Buttons -->
            <div class="grid grid-cols-2 gap-3 mb-4">
              <button id="${GithubCopilotTokenManagerUI.GENERATE_TOKEN_BUTTON_ID}" class="flex flex-col items-center justify-center p-4 rounded bg-zinc-800 hover:bg-blue-600 text-zinc-200 transition-colors border border-zinc-700">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mb-2">
                  <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path>
                </svg>
                <span>토큰 생성</span>
              </button>
              
              <button id="${GithubCopilotTokenManagerUI.CHECK_STATUS_BUTTON_ID}" class="flex flex-col items-center justify-center p-4 rounded bg-zinc-800 hover:bg-blue-600 text-zinc-200 transition-colors border border-zinc-700">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mb-2">
                  <circle cx="12" cy="12" r="10"></circle><path d="M9 12l2 2 4-4"></path>
                </svg>
                <span>상태 확인</span>
              </button>
              
              <button id="${GithubCopilotTokenManagerUI.GET_MODELS_BUTTON_ID}" class="flex flex-col items-center justify-center p-4 rounded bg-zinc-800 hover:bg-blue-600 text-zinc-200 transition-colors border border-zinc-700">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mb-2">
                  <rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="M8 10h8"></path><path d="M8 14h4"></path>
                </svg>
                <span>모델 목록</span>
              </button>
              
              <button id="${GithubCopilotTokenManagerUI.AUTO_CONFIG_BUTTON_ID}" class="flex flex-col items-center justify-center p-4 rounded bg-zinc-800 hover:bg-blue-600 text-zinc-200 transition-colors border border-zinc-700">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mb-2">
                  <circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
                <span>자동 설정</span>
              </button>
            </div>
            
            <!-- Hidden Container -->
            <div id="${GithubCopilotTokenManagerUI.STATUS_CONTAINER_ID}" class="space-y-4 hidden">
              <!-- Status information will be displayed here -->
            </div>

            <div id="${GithubCopilotTokenManagerUI.MODELS_CONTAINER_ID}" class="space-y-4 hidden">
              <!-- Models information will be displayed here -->
            </div>
          </div>
        </div>
      </div>
    `;

    this.loadSavedToken(modal);
    this.bindEvents(modal);
    document.body.appendChild(modal);
  }

  private static loadSavedToken(modal: HTMLElement): void {
    const tokenInput = modal.querySelector(
      "#" + CSS.escape(GithubCopilotTokenManagerUI.TOKEN_INPUT_ID)
    ) as HTMLInputElement;

    if (tokenInput) {
      const token: string = PLUGIN_SETTINGS_MANAGER.get(
        GithubCopilotTokenManagerUI.TOKEN_ARG_KEY
      );

      if (token) {
        tokenInput.value = token;
      }
    }
  }

  private static bindEvents(modal: HTMLElement): void {
    const closeButton = modal.querySelector(
      "#" + CSS.escape(GithubCopilotTokenManagerUI.CLOSE_BUTTON_ID)
    );
    const tokenInput = modal.querySelector(
      "#" + CSS.escape(GithubCopilotTokenManagerUI.TOKEN_INPUT_ID)
    ) as HTMLInputElement;

    const generateTokenButton = modal.querySelector(
      "#" + CSS.escape(GithubCopilotTokenManagerUI.GENERATE_TOKEN_BUTTON_ID)
    );
    const checkStatusButton = modal.querySelector(
      "#" + CSS.escape(GithubCopilotTokenManagerUI.CHECK_STATUS_BUTTON_ID)
    );
    const getModelsButton = modal.querySelector(
      "#" + CSS.escape(GithubCopilotTokenManagerUI.GET_MODELS_BUTTON_ID)
    );
    const autoConfigButton = modal.querySelector(
      "#" + CSS.escape(GithubCopilotTokenManagerUI.AUTO_CONFIG_BUTTON_ID)
    );

    modal.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        modal.remove();
      }
    });

    closeButton?.addEventListener("click", () => {
      modal.remove();
    });

    tokenInput?.addEventListener("input", () => {
      setArgEx(
        `${PLUGIN_NAME}::${GithubCopilotTokenManagerUI.TOKEN_ARG_KEY}`,
        tokenInput.value.trim()
      );
    });

    generateTokenButton?.addEventListener("click", async () => {
      await this.generateToken();
    });

    checkStatusButton?.addEventListener("click", async () => {
      await this.showStatus(modal);
    });

    getModelsButton?.addEventListener("click", async () => {
      await this.getModels(modal);
    });

    autoConfigButton?.addEventListener("click", async () => {
      await this.autoConfig();
    });
  }

  private static async generateToken(): Promise<void> {
    try {
      const deviceCode = await this.getDeviceCode();

      const generateDialog = document.createElement("div");
      generateDialog.id = GithubCopilotTokenManagerUI.GENERATE_DIALOG_ID;
      generateDialog.className = "fixed inset-0 z-100 p-1 sm:p-2 bg-black/50";
      generateDialog.innerHTML = `
        <div class="flex justify-center items-center w-full h-full">
        <div class="flex flex-col p-3 sm:p-6 rounded-lg bg-zinc-900 w-auto max-w-md h-auto">
          <!-- Header -->
          <div class="flex justify-between items-center w-full mb-4">
            <h2 class="text-2xl font-semibold text-zinc-100">GitHub Copilot 토큰 생성</h2>
            <button id="${GithubCopilotTokenManagerUI.GENERATE_CLOSE_BUTTON_ID}" class="p-2 text-zinc-400 hover:text-zinc-200 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          
          <!-- Scrollable Container -->
          <div class="flex-1 overflow-y-auto min-h-0 mb-4">
            <div class="bg-zinc-800 p-6 rounded-lg text-zinc-200 mb-4">
              <ol class="space-y-6 text-lg">
                <li>
                  <div class="flex items-start">
                    <span class="mr-2 bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center">1</span>
                    <div>
                      <p><a href="https://github.com/login/device" target="_blank" class="text-blue-400 underline">https://github.com/login/device</a> 로 이동하세요</p>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="flex items-start">
                    <span class="mr-2 bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center">2</span>
                    <div>
                      <p>아래 코드를 입력하세요</p>
                      <div class="mt-2 mb-2 bg-zinc-700 text-zinc-100 p-3 rounded-md text-2xl tracking-wider font-mono text-center flex justify-between items-center">
                        <span>${deviceCode.user_code}</span>
                        <button id="${GithubCopilotTokenManagerUI.GENERATE_COPY_BUTTON_ID}" class="text-sm bg-zinc-800 hover:bg-zinc-500 px-2 py-1 rounded ml-2">복사</button>
                      </div>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="flex items-start">
                    <span class="mr-2 bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center">3</span>
                    <span>GitHub 계정으로 인증하세요</span>
                  </div>
                </li>
              </ol>
            </div>
            <p class="text-zinc-300 text-center">인증을 완료한 후 확인 버튼을 클릭하세요.</p>
          </div>
          
          <!-- Buttons -->
          <div class="flex justify-end mt-4 pt-2 gap-2 border-t border-zinc-700">
            <button id="${GithubCopilotTokenManagerUI.GENERATE_CANCEL_BUTTON_ID}" class="px-4 py-2 rounded bg-zinc-800 text-zinc-200 hover:bg-red-500 transition-colors">취소</button>
            <button id="${GithubCopilotTokenManagerUI.GENERATE_CONFIRM_BUTTON_ID}" class="px-4 py-2 rounded bg-zinc-800 text-zinc-200 hover:bg-blue-500 transition-colors">확인</button>
          </div>
        </div>
        </div>
      `;

      // Bind events
      const closeButton = generateDialog.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.GENERATE_CLOSE_BUTTON_ID)
      );
      const copyButton = generateDialog.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.GENERATE_COPY_BUTTON_ID)
      );
      const cancelButton = generateDialog.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.GENERATE_CANCEL_BUTTON_ID)
      );
      const confirmButton = generateDialog.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.GENERATE_CONFIRM_BUTTON_ID)
      );

      generateDialog.addEventListener("keydown", (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          generateDialog.remove();
        }
      });

      closeButton?.addEventListener("click", () => {
        generateDialog.remove();
      });

      copyButton?.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(deviceCode.user_code);
          PluginToastUI.show("코드가 클립보드에 복사됨", 3000);
        } catch (err) {
          PluginToastUI.show("클립보드에 접근할 수 없음", 3000);
        }
      });

      cancelButton?.addEventListener("click", () => {
        generateDialog.remove();
      });

      return new Promise((resolve, reject) => {
        confirmButton?.addEventListener("click", async () => {
          try {
            const accessToken = await this.getAccessToken(
              deviceCode.device_code
            );

            setArgEx(
              `${PLUGIN_NAME}::${GithubCopilotTokenManagerUI.TOKEN_ARG_KEY}`,
              accessToken
            );

            const tokenInput = document.getElementById(
              GithubCopilotTokenManagerUI.TOKEN_INPUT_ID
            ) as HTMLInputElement;

            if (tokenInput) {
              tokenInput.value = accessToken;
            }

            generateDialog.remove();

            window.alert("GitHub Copilot 토큰이 생성되었습니다.");
            resolve();
          } catch (error) {
            generateDialog.remove();

            window.alert(String(error));
            reject(error);
          }
        });

        document.body.appendChild(generateDialog);
      });
    } catch (error) {
      window.alert(String(error));
    }
  }

  private static async getDeviceCode(): Promise<any> {
    const response = await risuAPI.risuFetch(
      "https://github.com/login/device/code",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "User-Agent":
            "node-fetch/1.0 (+https://github.com/bitinn/node-fetch)",
        },
        body: {
          client_id: GithubCopilotTokenManagerUI.CLIENT_ID,
          scope: "user:email",
        },
        rawResponse: false,
        plainFetchDeforce: true,
      }
    );

    if (!response.ok) {
      throw new Error(
        `디바이스 코드 요청 실패: ${JSON.stringify(response.data)}`
      );
    }

    return response.data;
  }

  private static async getAccessToken(deviceCode: string): Promise<string> {
    const response = await risuAPI.risuFetch(
      "https://github.com/login/oauth/access_token",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "User-Agent":
            "node-fetch/1.0 (+https://github.com/bitinn/node-fetch)",
        },
        body: {
          client_id: GithubCopilotTokenManagerUI.CLIENT_ID,
          device_code: deviceCode,
          grant_type: "urn:ietf:params:oauth:grant-type:device_code",
        },
        rawResponse: false,
        plainFetchDeforce: true,
      }
    );

    if (!response.ok) {
      throw new Error(
        `액세스 토큰 요청 실패: ${JSON.stringify(response.data)}`
      );
    }

    const data = response.data;

    if (data.error === "authorization_pending") {
      throw new Error("인증이 아직 완료되지 않았습니다.");
    }

    if (!data.access_token) {
      throw new Error(
        `액세스 토큰을 찾을 수 없습니다: ${JSON.stringify(data)}`
      );
    }

    return data.access_token;
  }

  private static async showStatus(modal: HTMLElement): Promise<void> {
    const token: string = PLUGIN_SETTINGS_MANAGER.get(
      GithubCopilotTokenManagerUI.TOKEN_ARG_KEY
    );

    if (!token) {
      window.alert("저장된 GitHub Copilot 토큰이 없습니다.");
      return;
    }

    try {
      PluginToastUI.show("상태 확인 중", 1000);

      // Invalidate response cache for GET request
      await risuAPI.risuFetch("https://github.com", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "User-Agent":
            "node-fetch/1.0 (+https://github.com/bitinn/node-fetch)",
        },
        rawResponse: false,
        plainFetchDeforce: true,
      });

      const response = await risuAPI.risuFetch(
        "https://api.github.com/copilot_internal/v2/token",
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
            "User-Agent": "GitHubCopilotChat/0.24.1",
            "Editor-Version": "vscode/1.96.4",
            "Editor-Plugin-Version": "copilot-chat/0.24.1",
            "X-GitHub-Api-Version": "2024-12-15",
          },
          rawResponse: false,
          plainFetchDeforce: true,
        }
      );

      if (!response.ok) {
        window.alert(`상태 확인 실패: ${JSON.stringify(response.data)}`);
        return;
      }

      const data = response.data;
      const sku = data.sku || "알 수 없음";
      const telemetry = data.telemetry || "알 수 없음";
      const enabledFeatures: string[] = [];

      for (const [key, value] of Object.entries(data)) {
        if (typeof value === "boolean" && value) {
          enabledFeatures.push(key);
        }
      }

      const statusContainer = modal.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.STATUS_CONTAINER_ID)
      );
      const modelsContainer = modal.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.MODELS_CONTAINER_ID)
      );

      if (modelsContainer) {
        modelsContainer.classList.add("hidden");
      }

      if (!statusContainer) {
        return;
      }

      statusContainer.innerHTML = `
        <div class="p-4 bg-zinc-800 rounded border border-zinc-700 mb-4">
          <h3 class="text-lg text-zinc-100 font-semibold mb-3">구독 종류</h3>
          <div class="bg-zinc-900 p-3 rounded">
            <div class="flex items-center">
              ${
                sku === "monthly_subscriber"
                  ? `<svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                   </svg>`
                  : `<svg class="w-5 h-5 text-red-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                   </svg>`
              }
              <span class="text-zinc-100 font-medium">${sku}</span>
            </div>
          </div>
        </div>
        
        <div class="p-4 bg-zinc-800 rounded border border-zinc-700 mb-4">
          <h3 class="text-lg text-zinc-100 font-semibold mb-3">텔레메트리 상태</h3>
          <div class="bg-zinc-900 p-3 rounded">
            <div class="flex items-center">
              ${
                telemetry === "disabled"
                  ? `<svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                   </svg>`
                  : `<svg class="w-5 h-5 text-red-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
                   </svg>`
              }
              <span class="text-zinc-100">${telemetry}</span>
            </div>
          </div>
        </div>
        
        <div class="p-4 bg-zinc-800 rounded border border-zinc-700">
          <h3 class="text-lg text-zinc-100 font-semibold mb-3">활성화된 기능</h3>
          <div class="bg-zinc-900 p-3 rounded">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
              ${enabledFeatures
                .map(
                  (feature) => `
                <div class="flex items-center">
                  <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                  <span class="text-zinc-300">${feature}</span>
                </div>
              `
                )
                .join("")}
            </div>
          </div>
        </div>
      `;
      statusContainer.classList.remove("hidden");
      statusContainer.scrollIntoView({ behavior: "smooth" });
    } catch (error) {
      window.alert(`상태 확인 중 오류 발생: ${String(error)}`);
    }
  }

  private static async getModels(modal: HTMLElement): Promise<void> {
    const token: string = PLUGIN_SETTINGS_MANAGER.get(
      GithubCopilotTokenManagerUI.TOKEN_ARG_KEY
    );

    if (!token) {
      window.alert("저장된 GitHub Copilot 토큰이 없습니다.");
      return;
    }

    try {
      PluginToastUI.show("모델 정보 요청 중", 1000);

      // Invalidate response cache for GET request
      await risuAPI.risuFetch("https://github.com", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "User-Agent":
            "node-fetch/1.0 (+https://github.com/bitinn/node-fetch)",
        },
        rawResponse: false,
        plainFetchDeforce: true,
      });

      const response = await risuAPI.risuFetch(
        "https://api.githubcopilot.com/models",
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
          rawResponse: false,
          plainFetchDeforce: true,
        }
      );

      if (!response.ok) {
        window.alert(`모델 정보 요청 실패: ${JSON.stringify(response.data)}`);
        return;
      }

      const data = response.data;
      const modelIds = data.data.map((model: any) => model.id);

      const statusContainer = modal.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.STATUS_CONTAINER_ID)
      );
      const modelsContainer = modal.querySelector(
        "#" + CSS.escape(GithubCopilotTokenManagerUI.MODELS_CONTAINER_ID)
      );

      if (statusContainer) {
        statusContainer.classList.add("hidden");
      }

      if (!modelsContainer) {
        return;
      }

      modelsContainer.innerHTML = `
      <div class="p-4 bg-zinc-800 rounded border border-zinc-700 mb-4">
        <h3 class="text-lg text-zinc-100 font-semibold mb-3">모델 ID 목록</h3>
        <div class="bg-zinc-900 p-3 rounded font-mono text-sm text-zinc-300 overflow-y-auto max-h-48">
          ${modelIds
            .map((id: string) => `<div class="py-1">${id}</div>`)
            .join("")}
        </div>
      </div>
      
      <div class="p-4 bg-zinc-800 rounded border border-zinc-700">
        <h3 class="text-lg text-zinc-100 font-semibold mb-3">모델 상세 정보</h3>
        <div class="bg-zinc-900 p-3 rounded font-mono text-sm text-zinc-300 overflow-y-auto max-h-72 whitespace-pre-wrap">
          ${JSON.stringify(data, null, 4)}
        </div>
      </div>
    `;
      modelsContainer.classList.remove("hidden");
      modelsContainer.scrollIntoView({ behavior: "smooth" });
    } catch (error) {
      window.alert(`모델 정보 요청 중 오류 발생: ${String(error)}`);
    }
  }

  private static async autoConfig(): Promise<void> {
    const token: string = PLUGIN_SETTINGS_MANAGER.get(
      GithubCopilotTokenManagerUI.TOKEN_ARG_KEY
    );

    if (!token) {
      window.alert("저장된 GitHub Copilot 토큰이 없습니다.");
      return;
    }

    const confirmed = await Utils.confirmEx(
      "다음 설정으로 플러그인의 커스텀 프로바이더를 설정하시겠습니까?\n\n" +
        "URL: https://api.githubcopilot.com/chat/completions\n" +
        `키/패스워드: ${token}\n` +
        "모델명: claude-3.7-sonnet\n" +
        "커스텀 플래그: hasFirstSystemPrompt, requiresAlternateRole"
    );

    if (!confirmed) {
      return;
    }

    try {
      setArgEx(
        `${PLUGIN_NAME}::common_openaiCompatibleProvider_url`,
        "https://api.githubcopilot.com/chat/completions"
      );
      setArgEx(`${PLUGIN_NAME}::common_openaiCompatibleProvider_apiKey`, token);
      setArgEx(
        `${PLUGIN_NAME}::common_openaiCompatibleProvider_model`,
        "claude-3.7-sonnet"
      );
      setArgEx(
        `${PLUGIN_NAME}::common_openaiCompatibleProvider_hasFirstSystemPrompt`,
        "1"
      );
      setArgEx(
        `${PLUGIN_NAME}::common_openaiCompatibleProvider_requiresAlternateRole`,
        "1"
      );
      setArgEx(
        `${PLUGIN_NAME}::common_openaiCompatibleProvider_mustStartWithUserInput`,
        "0"
      );

      window.alert(
        "GitHub Copilot 설정이 완료되었습니다! \n\n" +
          "리스 옵션 > 채팅 봇 > 모델을 플러그인으로 설정하고\n" +
          "[LBI] [OpenAICompatible] custom 을 선택하세요."
      );
    } catch (error) {
      window.alert(`설정 중 오류 발생: ${String(error)}`);
    }
  }
}

class PluginProgressUI {
  private static backdropEl: HTMLElement | null;
  private static messageEl: HTMLElement | null;
  private static barEl: HTMLElement | null;
  private static percentEl: HTMLElement | null;

  public static show(message: string): void {
    PluginProgressUI.hide();

    const backdropEl = document.createElement("div");
    backdropEl.className =
      "fixed inset-0 z-100 flex items-center justify-center p-1 sm:p-2 bg-black/70";

    backdropEl.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
      }
    });

    backdropEl.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
    });

    const modalEl = document.createElement("div");
    modalEl.className =
      "flex flex-col w-96 max-w-full p-6 rounded-lg bg-zinc-900";
    backdropEl.appendChild(modalEl);

    const messageEl = document.createElement("div");
    messageEl.className = "mb-4 text-lg text-center text-zinc-100";
    messageEl.textContent = message;
    modalEl.appendChild(messageEl);

    const barContainerEl = document.createElement("div");
    barContainerEl.className =
      "overflow-hidden w-full h-2 mb-2 rounded-full bg-zinc-700";
    modalEl.appendChild(barContainerEl);

    const barEl = document.createElement("div");
    barEl.className = "w-0 h-full bg-blue-500 transition-all duration-300";
    barContainerEl.appendChild(barEl);

    const percentEl = document.createElement("div");
    percentEl.className = "text-sm text-center text-zinc-400";
    percentEl.textContent = "0%";
    modalEl.appendChild(percentEl);

    document.body.appendChild(backdropEl);

    PluginProgressUI.backdropEl = backdropEl;
    PluginProgressUI.messageEl = messageEl;
    PluginProgressUI.barEl = barEl;
    PluginProgressUI.percentEl = percentEl;
  }

  public static updateProgress(ratio: number): void {
    if (!PluginProgressUI.barEl || !PluginProgressUI.percentEl) return;

    const percent = Math.min(Math.round(ratio * 100), 100);

    PluginProgressUI.barEl.style.width = `${percent}%`;
    PluginProgressUI.percentEl.textContent = `${percent}%`;
  }

  public static updateMessage(message: string): void {
    if (!PluginProgressUI.messageEl) return;

    PluginProgressUI.messageEl.textContent = message;
  }

  public static hide(): void {
    if (!PluginProgressUI.backdropEl) return;

    PluginProgressUI.backdropEl.remove();

    PluginProgressUI.backdropEl = null;
    PluginProgressUI.messageEl = null;
    PluginProgressUI.barEl = null;
    PluginProgressUI.percentEl = null;
  }
}

interface DualActionParams {
  onMainAction?: () => void;
  onAlternativeAction?: () => void;
}

interface DualActionHandler {
  destroy(): void;
  update(newParams: DualActionParams): void;
}

function createDualActionHandler(
  element: HTMLElement,
  params: DualActionParams = {}
): DualActionHandler {
  const DOUBLE_TAP_DELAY = 300;
  let lastTap = 0;
  let tapTimeout: number | undefined = undefined;

  const handleTouch = (event: TouchEvent) => {
    const currentTime = new Date().getTime();
    const tapLength = currentTime - lastTap;

    if (tapLength < DOUBLE_TAP_DELAY && tapLength > 0) {
      // Double tap detected
      event.preventDefault();
      window.clearTimeout(tapTimeout); // Cancel the first tap timeout
      params.onAlternativeAction?.();
      lastTap = 0; // Reset state
    } else {
      lastTap = currentTime; // First tap
      // Delayed single tap execution
      tapTimeout = window.setTimeout(() => {
        if (lastTap === currentTime) {
          // If no double tap occurred
          params.onMainAction?.();
        }
      }, DOUBLE_TAP_DELAY);
    }
  };

  const handleClick = (event: MouseEvent) => {
    if (event.shiftKey) {
      params.onAlternativeAction?.();
    } else {
      params.onMainAction?.();
    }
  };

  if ("ontouchend" in window) {
    // Mobile environment
    element.addEventListener("touchend", handleTouch);
  } else {
    // Desktop environment
    element.addEventListener("click", handleClick);
  }

  return {
    destroy() {
      if ("ontouchend" in window) {
        element.removeEventListener("touchend", handleTouch);
      } else {
        element.removeEventListener("click", handleClick);
      }

      window.clearTimeout(tapTimeout); // Cleanup timeout
    },
    update(newParams: DualActionParams) {
      params = newParams;
    },
  };
}

class RisuCharMessageAutoTranslator {
  private static timeout: number;

  public static initialize(): void {
    let lastMessages: Message[] | null = null;

    RisuCharMessageAutoTranslator.dispose();

    const checkAndClick = () => {
      const chatSettings = getChatSettings();

      if (!chatSettings.autoClickTranslateButton) {
        RisuCharMessageAutoTranslator.timeout = window.setTimeout(
          checkAndClick,
          1000
        );
        return;
      }

      const currentChar = risuAPI.getChar();
      const currentChat = currentChar?.chats?.[currentChar.chatPage];
      const currentMessages: Message[] = currentChat?.message;

      if (
        !currentMessages ||
        currentMessages.length === 0 ||
        currentMessages === lastMessages ||
        currentMessages[currentMessages.length - 1].role !== "char" ||
        currentChat.isStreaming
      ) {
        lastMessages = currentMessages;
        RisuCharMessageAutoTranslator.timeout = window.setTimeout(
          checkAndClick,
          1000
        );
        return;
      }

      const buttons = document.querySelectorAll("button.button-icon-translate");

      if (
        buttons.length === 0 ||
        buttons[0].classList.contains("text-blue-400")
      ) {
        lastMessages = currentMessages;
        RisuCharMessageAutoTranslator.timeout = window.setTimeout(
          checkAndClick,
          1000
        );
        return;
      }

      (buttons[0] as HTMLButtonElement).click();

      lastMessages = currentMessages;

      RisuCharMessageAutoTranslator.timeout = window.setTimeout(
        checkAndClick,
        1000
      );
    };

    // Add hotkey to toggle auto click translate button option
    document.addEventListener(
      "keydown",
      RisuCharMessageAutoTranslator.onKeydown
    );

    RisuCharMessageAutoTranslator.timeout = window.setTimeout(
      checkAndClick,
      1000
    );

    Logger.debug("RisuCharMessageAutoTranslator initialized");
  }

  public static dispose(): void {
    window.clearTimeout(RisuCharMessageAutoTranslator.timeout);

    document.removeEventListener(
      "keydown",
      RisuCharMessageAutoTranslator.onKeydown
    );

    Logger.debug("RisuCharMessageAutoTranslator disposed");
  }

  private static onKeydown(e: KeyboardEvent): void {
    if (e.ctrlKey && e.altKey && e.shiftKey && e.key.toLowerCase() === "t") {
      e.preventDefault();

      const autoClickTranslateButton =
        getChatSettings()?.autoClickTranslateButton;

      setArgEx(
        `${PLUGIN_NAME}::chat_autoClickTranslateButton`,
        Number(!autoClickTranslateButton)
      );

      PluginToastUI.show(
        `자동 번역 ${!autoClickTranslateButton ? "켜짐" : "꺼짐"}`,
        2000
      );
    }
  }
}

class RisuTextAreaEnhancer {
  private static readonly WHITE_LIST = [
    "div.risu-sidebar textarea",
    "textarea#messageInputTranslate",
  ];

  private static readonly EVENT_HANDLER_MARKER = `data-${PLUGIN_NAME}-risuTextAreaEnhancer`;

  private static observer: MutationObserver | null = null;

  public static initialize(): void {
    RisuTextAreaEnhancer.dispose();

    RisuTextAreaEnhancer.observer = new MutationObserver((mutations) => {
      const commonSettings = getCommonSettings();

      RisuTextAreaEnhancer.WHITE_LIST.forEach((selector) => {
        const elements = document.querySelectorAll(selector);

        elements.forEach((element) => {
          if (commonSettings.useEditorForInputBox) {
            if (
              !element.getAttribute(RisuTextAreaEnhancer.EVENT_HANDLER_MARKER)
            ) {
              element.addEventListener("focus", RisuTextAreaEnhancer.onFocus);
              element.setAttribute(
                RisuTextAreaEnhancer.EVENT_HANDLER_MARKER,
                "1"
              );
            }
          } else {
            element.removeEventListener("focus", RisuTextAreaEnhancer.onFocus);
            element.removeAttribute(RisuTextAreaEnhancer.EVENT_HANDLER_MARKER);
          }
        });
      });
    });

    RisuTextAreaEnhancer.observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    Logger.debug("RisuTextAreaEnhancer initialized");
  }

  public static dispose(): void {
    if (RisuTextAreaEnhancer.observer) {
      RisuTextAreaEnhancer.observer.disconnect();
      RisuTextAreaEnhancer.observer = null;
    }

    RisuTextAreaEnhancer.WHITE_LIST.forEach((selector) => {
      const elements = document.querySelectorAll(selector);

      elements.forEach((element) => {
        element.removeEventListener("focus", RisuTextAreaEnhancer.onFocus);
        element.removeAttribute(RisuTextAreaEnhancer.EVENT_HANDLER_MARKER);
      });
    });

    Logger.debug("RisuTextAreaEnhancer disposed");
  }

  private static onFocus = async (e: Event) => {
    const target = e.currentTarget as HTMLTextAreaElement;
    const result = await PluginTextEditorUI.showModal("편집기", target.value);

    if (result.confirmed && result.value != null) {
      target.value = result.value;

      const inputEvent = new Event("input", { bubbles: true });
      target.dispatchEvent(inputEvent);

      const changeEvent = new Event("change", { bubbles: true });
      target.dispatchEvent(changeEvent);
    }
  };
}

class HTMLTextSeparator {
  public textNodes: Text[];

  // Tags to skip during parsing
  private static readonly skipTags: readonly string[] = ["style", "script"];

  private parser: DOMParser;
  private doc: Document;

  public constructor(html: string) {
    // Create a new DOMParser instance
    this.parser = new DOMParser();

    // Parse the HTML string into a DOM document
    this.doc = this.parser.parseFromString(`<body>${html}</body>`, "text/html");

    // Store text nodes
    this.textNodes = [];

    // Parse the document
    this.parseDocument();
  }

  // Get the final HTML output without html/head/body wrapper
  public toString(): string {
    return this.doc.body.innerHTML;
  }

  // Collect text nodes from the document
  private parseDocument(): void {
    if (!this.doc.body) {
      throw new Error("Document body is null");
    }

    this.textNodes = this.collectTextNodes(this.doc.body);
  }

  // Recursively collect text nodes
  private collectTextNodes(node: Node, textNodes: Text[] = []): Text[] {
    // Skip if node is in skipTags
    if (
      node.nodeName &&
      HTMLTextSeparator.skipTags.includes(node.nodeName.toLowerCase())
    ) {
      return textNodes;
    }

    // If it's a text node with non-empty content and contains at least one letter
    if (node instanceof Text) {
      const content = node.textContent?.trim() || "";
      if (content.length > 0 && /[\p{L}]/gu.test(content)) {
        textNodes.push(node);
      }
    }

    // Recursively process child nodes
    for (const childNode of node.childNodes) {
      this.collectTextNodes(childNode, textNodes);
    }

    return textNodes;
  }
}

class RequestHandler {
  public static async handleRequest(
    pluginRequest: PluginV2ProviderArgument,
    defaultUniqueId: string,
    abortSignal?: AbortSignal
  ): Promise<string | ReadableStream<string>> {
    const commonSettings = getCommonSettings();
    const chatSettings = getChatSettings();
    const memorySettings = getMemorySettings();
    const translationSettings = getTranslationSettings();
    const otherSettings = getOtherSettings();
    const processedRequest = structuredClone(pluginRequest);
    const requestType = Utils.getRequestType(pluginRequest);

    Logger.debug("Plugin raw settings:", PLUGIN_SETTINGS_MANAGER.toJSON());
    Logger.debug("Plugin common settings:", commonSettings);
    Logger.debug("Plugin chat settings:", chatSettings);
    Logger.debug("Plugin memory settings:", memorySettings);
    Logger.debug("Plugin translation settings:", translationSettings);
    Logger.debug("Plugin other settings:", otherSettings);
    Logger.debug("Received following request:", pluginRequest);
    Logger.info("Request type:", requestType);

    // Process Xml commands
    {
      const openai_t2i =
        RequestHandler.parseXmlCommand_openai_t2i(processedRequest);

      if (openai_t2i) {
        const provider = new OpenAIProvider(
          commonSettings.openaiProvider_apiKey
        );
        return provider.textToImage(pluginRequest, openai_t2i);
      }

      const openai_i2i = await RequestHandler.parseXmlCommand_openai_i2i(
        processedRequest
      );

      if (openai_i2i) {
        const provider = new OpenAIProvider(
          commonSettings.openaiProvider_apiKey
        );
        return provider.imageToImage(pluginRequest, openai_i2i);
      }

      const abort = await RequestHandler.parseXmlCommand_abort(
        processedRequest
      );

      if (abort) {
        Logger.info("Plugin aborted by xml command!");
        return null as any; // This intentionally raises an exception
      }
    }

    // Normal mode
    processedRequest.max_tokens =
      processedRequest.max_tokens || DEFAULT.MAX_TOKENS;

    switch (requestType) {
      case REQUEST_TYPE.CHAT: {
        const modelDef = getLLMDefinition(defaultUniqueId);

        if (!modelDef) {
          throw new Error(`Unknown model id: ${defaultUniqueId}`);
        }

        Utils.applySamplingParameters(processedRequest, chatSettings);
        RequestHandler.applyCommonPreProcessing(
          processedRequest,
          modelDef,
          commonSettings
        );
        RequestHandler.applyChatPreProcessing(
          processedRequest,
          modelDef,
          chatSettings
        );

        // Streaming mode
        if (
          chatSettings.claude_useStreaming &&
          modelDef.provider === LLM_PROVIDER.ANTHROPIC
        ) {
          return AutoProvider.getStreamedResponse(processedRequest, modelDef);
        }

        if (
          commonSettings.openaiCompatibleProvider_useStreaming &&
          modelDef.provider === LLM_PROVIDER.OPENAICOMPATIBLE
        ) {
          return AutoProvider.getStreamedResponse(processedRequest, modelDef);
        }

        // Non-streaming mode
        const modelContent = await AutoProvider.getResponse(
          processedRequest,
          modelDef
        );

        return RequestHandler.applyChatPostProcessing(
          processedRequest,
          modelDef,
          chatSettings,
          modelContent
        );
      }

      case REQUEST_TYPE.EMOTION: {
        const uniqueId = memorySettings.model || defaultUniqueId;
        const modelDef = getLLMDefinition(uniqueId);

        if (!modelDef) {
          throw new Error(`Unknown model id: ${uniqueId}`);
        }

        processedRequest.max_tokens =
          memorySettings.sampling_maxTokens ?? processedRequest.max_tokens;

        // Gemini thinking model
        if (
          GoogleAIProvider.isGeminiThinkingModel(modelDef) &&
          processedRequest.max_tokens < 1024
        ) {
          processedRequest.max_tokens = 1024;
        }

        // Gemini thinking mode
        if (
          GoogleAIProvider.getGeminiThinkingMode(pluginRequest, modelDef) ===
            "manual" &&
          processedRequest.max_tokens < processedRequest.thinking_tokens + 1024
        ) {
          processedRequest.max_tokens = processedRequest.thinking_tokens + 1024;
        }

        Utils.applySamplingParameters(processedRequest, memorySettings);

        RequestHandler.applyCommonPreProcessing(
          processedRequest,
          modelDef,
          commonSettings
        );
        RequestHandler.applyEmotionPreProcessing(processedRequest, modelDef);

        return await AutoProvider.getResponse(processedRequest, modelDef);
      }

      case REQUEST_TYPE.MEMORY: {
        const uniqueId = memorySettings.model || defaultUniqueId;
        const modelDef = getLLMDefinition(uniqueId);

        if (!modelDef) {
          throw new Error(`Unknown model id: ${uniqueId}`);
        }

        processedRequest.max_tokens =
          memorySettings.sampling_maxTokens ?? processedRequest.max_tokens;

        Utils.applySamplingParameters(processedRequest, memorySettings);
        RequestHandler.applyCommonPreProcessing(
          processedRequest,
          modelDef,
          commonSettings
        );
        RequestHandler.applyMemoryPreProcessing(
          processedRequest,
          modelDef,
          memorySettings
        );

        return await AutoProvider.getResponse(processedRequest, modelDef);
      }

      case REQUEST_TYPE.TRANSLATION: {
        const uniqueId = translationSettings.model || defaultUniqueId;
        const modelDef = getLLMDefinition(uniqueId);

        if (!modelDef) {
          throw new Error(`Unknown model id: ${uniqueId}`);
        }

        Utils.applySamplingParameters(processedRequest, translationSettings);
        RequestHandler.applyCommonPreProcessing(
          processedRequest,
          modelDef,
          commonSettings
        );
        RequestHandler.applyTranslationPreProcessing(
          processedRequest,
          modelDef,
          translationSettings
        );

        const preprocessCBSIndex = processedRequest.prompt_chat.findIndex(
          (message) => message.content.match(/{{lbi::trans::preprocess}}/i)
        );
        let modelContent = null;

        if (preprocessCBSIndex !== -1) {
          Logger.info("HTML translation mode.");

          modelContent = await RequestHandler.translateHTML(
            processedRequest,
            modelDef,
            translationSettings
          );
        } else {
          Logger.info("Normal translation mode.");
          Logger.debug("Original input:", processedRequest.prompt_chat);

          modelContent = await AutoProvider.getResponse(
            processedRequest,
            modelDef
          );
          Logger.debug("Final output:", modelContent);
        }

        RequestHandler.applyTranslationPostProcessing(
          modelContent,
          modelDef,
          translationSettings
        );

        return modelContent;
      }

      case REQUEST_TYPE.OTHER: {
        const uniqueId = otherSettings.model || defaultUniqueId;
        const modelDef = getLLMDefinition(uniqueId);

        if (!modelDef) {
          throw new Error(`Unknown model id: ${uniqueId}`);
        }

        processedRequest.max_tokens =
          otherSettings.sampling_maxTokens ?? processedRequest.max_tokens;

        Utils.applySamplingParameters(processedRequest, otherSettings);
        RequestHandler.applyCommonPreProcessing(
          processedRequest,
          modelDef,
          commonSettings
        );

        return await AutoProvider.getResponse(processedRequest, modelDef);
      }

      default: {
        throw new Error(
          `Unexpected request type: ${JSON.stringify(processedRequest)}`
        );
      }
    }
  }

  private static parseXmlCommand_openai_t2i(
    pluginRequest: PluginV2ProviderArgument
  ): OpenAIImageGenerateBody | null {
    const command = "lbi_openai_t2i";
    const rootEl = RequestHandler.extractXmlCommand(pluginRequest, command);

    if (!rootEl) return null;

    const body: OpenAIImageGenerateBody = {
      prompt: "pineapple pizza",
      model: "gpt-image-1",
    };

    // prompt
    const promptEl = rootEl.querySelector("prompt");

    if (!promptEl || !promptEl.textContent) {
      throw new Error("Parameter 'prompt' is required.");
    }

    body.prompt = promptEl.textContent.trim();

    // background
    const backgroundEl = rootEl.querySelector("background");

    if (backgroundEl && backgroundEl.textContent) {
      const bg = backgroundEl.textContent.trim();

      if (["auto", "transparent", "opaque"].includes(bg)) {
        body.background = bg as "auto" | "transparent" | "opaque";
      }
    }

    // model
    const modelEl = rootEl.querySelector("model");

    if (modelEl && modelEl.textContent) {
      const model = modelEl.textContent.trim();

      if (["dall-e-2", "dall-e-3", "gpt-image-1"].includes(model)) {
        body.model = model as "dall-e-2" | "dall-e-3" | "gpt-image-1";
      }
    }

    // moderation
    const moderationEl = rootEl.querySelector("moderation");

    if (moderationEl && moderationEl.textContent) {
      const mod = moderationEl.textContent.trim();

      if (["auto", "low"].includes(mod)) {
        body.moderation = mod as "auto" | "low";
      }
    }

    // n
    const nEl = rootEl.querySelector("n");

    if (nEl && nEl.textContent) {
      const n = parseInt(nEl.textContent.trim(), 10);

      if (!isNaN(n) && n >= 1 && n <= 10) {
        body.n = n;
      }
    }

    // output_compression
    const outputCompressionEl = rootEl.querySelector("output_compression");

    if (outputCompressionEl && outputCompressionEl.textContent) {
      const comp = parseInt(outputCompressionEl.textContent.trim(), 10);

      if (!isNaN(comp) && comp >= 0 && comp <= 100) {
        body.output_compression = comp;
      }
    }

    // output_format
    const outputFormatEl = rootEl.querySelector("output_format");

    if (outputFormatEl && outputFormatEl.textContent) {
      const format = outputFormatEl.textContent.trim();

      if (["png", "jpeg", "webp"].includes(format)) {
        body.output_format = format as "png" | "jpeg" | "webp";
      }
    }

    // quality
    const qualityEl = rootEl.querySelector("quality");

    if (qualityEl && qualityEl.textContent) {
      const quality = qualityEl.textContent.trim();

      if (
        ["auto", "standard", "hd", "low", "medium", "high"].includes(quality)
      ) {
        body.quality = quality as
          | "auto"
          | "standard"
          | "hd"
          | "low"
          | "medium"
          | "high";
      }
    }

    // response_format must be 'b64_json' or unset

    // size
    const sizeEl = rootEl.querySelector("size");

    if (sizeEl && sizeEl.textContent) {
      const size = sizeEl.textContent.trim();

      if (
        [
          "auto",
          "256x256",
          "512x512",
          "1024x1024",
          "1024x1536",
          "1024x1792",
          "1536x1024",
          "1792x1024",
        ].includes(size)
      ) {
        body.size = size as
          | "auto"
          | "256x256"
          | "512x512"
          | "1024x1024"
          | "1024x1536"
          | "1024x1792"
          | "1536x1024"
          | "1792x1024";
      }
    }

    // style
    const styleEl = rootEl.querySelector("style");

    if (styleEl && styleEl.textContent && body.model === "dall-e-3") {
      const style = styleEl.textContent.trim();

      if (["vivid", "natural"].includes(style)) {
        body.style = style as "vivid" | "natural";
      }
    }

    return body;
  }

  private static async parseXmlCommand_openai_i2i(
    pluginRequest: PluginV2ProviderArgument
  ): Promise<OpenAIImageEditBody | null> {
    const command = "lbi_openai_i2i";
    const rootEl = RequestHandler.extractXmlCommand(pluginRequest, command);

    if (!rootEl) return null;

    const body: OpenAIImageEditBody = {
      image: [],
      prompt: "pineapple pizza",
      model: "gpt-image-1",
    };

    // image
    const imageEl = rootEl.querySelector("image");

    if (!imageEl || !imageEl.textContent) {
      throw new Error("Parameter 'image' is required.");
    }

    const inlayPattern =
      /{{(?:inlayed|inlay)::([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})}}/g;
    const base64Pattern = /^data:image\/([a-z]+);base64,(.+)$/i;

    const matches = imageEl.textContent.trim().matchAll(inlayPattern);
    const inlayIds = new Set<string>();

    for (const match of matches) {
      inlayIds.add(match[1]);
    }

    for (const inlayId of inlayIds) {
      const data = await InlayCache.get(inlayId);

      if (!data) continue;

      if (data.type !== "image" || !data.data) continue;

      const match = data.data.match(base64Pattern);

      if (!match) continue;

      const [, dataExt, base64Image] = match;
      const extension = data.ext || dataExt || "png";
      const bytesImage = Utils.base64ToUint8Array(base64Image);
      const blob = new Blob([bytesImage], { type: `image/${extension}` });

      body.image.push(blob);
    }

    if (body.image.length === 0) {
      throw new Error("image is required.");
    }

    // prompt
    const promptEl = rootEl.querySelector("prompt");

    if (!promptEl || !promptEl.textContent) {
      throw new Error("prompt is required.");
    }

    body.prompt = promptEl.textContent.trim();

    // mask
    const maskEl = rootEl.querySelector("mask");

    if (maskEl && maskEl.textContent) {
      const match = maskEl.textContent.trim().match(inlayPattern);

      if (match) {
        const inlayId = match[1];

        const data = await InlayCache.get(inlayId);

        if (data && data.type === "image" && data.data) {
          const match = data.data.match(base64Pattern);

          if (match) {
            const [, dataExt, base64Image] = match;
            const extension = data.ext || dataExt || "png";
            const bytesImage = Utils.base64ToUint8Array(base64Image);
            const blob = new Blob([bytesImage], { type: `image/${extension}` });

            body.mask = blob;
          }
        }
      }
    }

    // model
    const modelEl = rootEl.querySelector("model");

    if (modelEl && modelEl.textContent) {
      const model = modelEl.textContent.trim();

      if (["dall-e-2", "gpt-image-1"].includes(model)) {
        body.model = model as "dall-e-2" | "gpt-image-1";
      }
    }

    // n
    const nEl = rootEl.querySelector("n");

    if (nEl && nEl.textContent) {
      const n = parseInt(nEl.textContent.trim(), 10);

      if (!isNaN(n) && n >= 1 && n <= 10) {
        body.n = n;
      }
    }

    // quality
    const qualityEl = rootEl.querySelector("quality");

    if (qualityEl && qualityEl.textContent) {
      const quality = qualityEl.textContent.trim();

      if (["auto", "standard", "low", "medium", "high"].includes(quality)) {
        body.quality = quality as
          | "auto"
          | "standard"
          | "low"
          | "medium"
          | "high";
      }
    }

    // response_format must be 'b64_json' or unset

    // size
    const sizeEl = rootEl.querySelector("size");

    if (sizeEl && sizeEl.textContent) {
      const size = sizeEl.textContent.trim();

      if (
        [
          "auto",
          "256x256",
          "512x512",
          "1024x1024",
          "1024x1536",
          "1536x1024",
        ].includes(size)
      ) {
        body.size = size as
          | "auto"
          | "256x256"
          | "512x512"
          | "1024x1024"
          | "1024x1536"
          | "1536x1024";
      }
    }

    return body;
  }

  private static async parseXmlCommand_abort(
    pluginRequest: PluginV2ProviderArgument
  ): Promise<Boolean> {
    const command = "lbi_abort";
    const rootEl = RequestHandler.extractXmlCommand(
      pluginRequest,
      command,
      false
    );

    if (!rootEl) return false;

    return true;
  }

  private static extractXmlCommand(
    pluginRequest: PluginV2ProviderArgument,
    command: string,
    exactMatch: boolean = true
  ): Element | null {
    const requestType = Utils.getRequestType(pluginRequest);
    let trimedContent = null;

    switch (requestType) {
      case REQUEST_TYPE.CHAT: {
        const currentChar = risuAPI.getChar();
        const currentChat = currentChar?.chats?.[currentChar.chatPage];
        const currentMessages = currentChat?.message;

        if (!currentMessages || currentMessages.length === 0) return null;

        const lastMessage = currentMessages[currentMessages.length - 1];

        if (
          lastMessage.role !== LLM_ROLE.USER ||
          lastMessage.data.trim().length === 0
        )
          return null;

        trimedContent = lastMessage.data.trim();
        break;
      }

      case REQUEST_TYPE.OTHER: {
        const lastMessage =
          pluginRequest.prompt_chat[pluginRequest.prompt_chat.length - 1];

        if (!lastMessage) return null;

        if (
          lastMessage.role !== LLM_ROLE.SYSTEM &&
          lastMessage.role !== LLM_ROLE.USER
        )
          return null;

        if (lastMessage.content.trim().length === 0) return null;

        trimedContent = lastMessage.content.trim();
        break;
      }

      default: {
        return null;
      }
    }

    const commandPattern = exactMatch
      ? new RegExp(`(^<${command}>[\\s\\S]*<\/${command}>$)`)
      : new RegExp(`(^<${command}>[\\s\\S]*<\/${command}>)`);
    const match = trimedContent.match(commandPattern);

    if (!match) return null;

    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(match[1], "text/xml");

    if (xmlDoc.querySelector("parsererror")) {
      throw new Error("Invalid XML command. Check syntax.");
    }

    const rootEl = xmlDoc.querySelector(command);

    if (!rootEl) {
      throw new Error("Unexpected error.");
    }

    return rootEl;
  }

  private static applyCommonPreProcessing(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition,
    commonSettings: CommonSettings
  ): void {
    // Gemini: Block paid model
    if (
      commonSettings.gemini_blockPaidModel &&
      modelDef.id.includes("gemini") &&
      !modelDef.flags.includes(LLM_FLAG.isFreeModel)
    ) {
      const requestType = Utils.getRequestType(pluginRequest);

      throw new Error(
        `'제미니 유료 모델 차단' 옵션에 의해 요청이 중단되었습니다: '${requestType}' 요청에서 '${modelDef.name}'를 호출함.`
      );
    }

    // Gemini Thinking: Parse remaining thoughts in assistant message
    if (GoogleAIProvider.isGeminiThinkingModel(modelDef)) {
      pluginRequest.prompt_chat.forEach((message) => {
        if (message.role !== LLM_ROLE.ASSISTANT) {
          return;
        }

        if (!message.thoughts) {
          message.thoughts = [];
        }

        const thoughts = message.thoughts;

        message.content = message.content.replace(
          /<Thoughts>([\s\S]*?)<\/Thoughts>/g,
          (match, p1) => {
            if (p1.trim() !== "") {
              thoughts.push(p1);
            }

            return "";
          }
        );

        message.content = message.content.replace(
          /<details><summary>.*<\/summary>([\s\S]*?)<\/details>/g,
          (match, p1) => {
            if (p1.trim() !== "") {
              thoughts.push(p1);
            }

            return "";
          }
        );
      });
    }
  }

  private static applyChatPreProcessing(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition,
    chatSettings: ChatSettings
  ): void {
    // Claude: stop caching extension
    PluginTimerUI.stop();

    // Remove [Start a new chat]
    if (chatSettings.removeStartANewChat) {
      const index = pluginRequest.prompt_chat.findIndex(
        (message) =>
          message.role === LLM_ROLE.SYSTEM && message.memo === "NewChat"
      );

      if (index !== -1) {
        pluginRequest.prompt_chat.splice(index, 1);
      }
    }

    // Gemini: the use of the system role should be avoided for jailbreak
    if (!chatSettings.gemini_preserveSystem && modelDef.id.includes("gemini")) {
      pluginRequest.prompt_chat.forEach((message) => {
        if (message.role === LLM_ROLE.SYSTEM) {
          message.role = LLM_ROLE.USER;
        }
      });
    }
  }

  private static async applyChatPostProcessing(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition,
    chatSettings: ChatSettings,
    modelContent: string
  ): Promise<string> {
    Logger.debug("Model content:", modelContent);

    let processed = modelContent;

    // Gemini: separate CoT if needed
    if (chatSettings.gemini_separateCot) {
      const thinkingMode = GoogleAIProvider.getGeminiThinkingMode(
        pluginRequest,
        modelDef
      );

      if (
        GoogleAIProvider.isGeminiThinkingModel(modelDef) ||
        thinkingMode === "manual" ||
        thinkingMode === "auto"
      ) {
        processed = await RequestHandler.geminiSeparateCot(processed);
      }
    }

    // Gemini: remove foreign languages if needed
    if (
      chatSettings.gemini_removeForeignLanguage &&
      modelDef.id.includes("gemini")
    ) {
      processed = await RequestHandler.geminiRemoveForeignLanguages(processed);
    }

    Logger.info("Processed content:", processed);
    return processed;
  }

  private static async geminiSeparateCot(original: string): Promise<string> {
    if (original.match(/<Thoughts>([\s\S]*?)<\/Thoughts>/g)) {
      return original;
    }

    const chatmlPrompt = Utils.parseChatML(
      DEFAULT.CHAT_GEMINI_COT_SEPARATION_PROMPT
    );

    if (!chatmlPrompt) {
      throw new Error("Gemini CoT separation prompt is not in ChatML format.");
    }

    const pluginRequest: PluginV2ProviderArgument = {
      prompt_chat: chatmlPrompt.map((message) => ({
        ...message,
        content: message.content.replace(/{{slot::content}}/g, original),
        thoughts: [],
      })),
      max_tokens: 8192,
      temperature: 0,
      top_p: 0.9,
      presence_penalty: 0,
      frequency_penalty: 0,
      top_k: 40,
      min_p: 0,
      repetition_penalty: 0,
      thinking_tokens: 0,
      stop_sequences: [],
      mode: "translate",
    };

    try {
      Logger.info("Separating CoT part from the response.");
      PluginToastUI.show("CoT 분리하는 중", 3000);

      const modelDef = getLLMDefinition(
        "gemini-2.0-flash-exp"
      ) as LLMDefinition;
      const modelContent = (
        await AutoProvider.getResponse(pluginRequest, modelDef)
      ).trim();
      Logger.debug("Model content:", modelContent);

      const extractedCot = /```([\s\S]+)```/.exec(modelContent)?.[1]?.trim();

      if (extractedCot) {
        const lines = extractedCot.split("\n").filter((e) => e.trim() !== "");
        let processed = original;

        lines.forEach((e) => {
          processed = processed.replace(e, "");
        });

        processed = processed.trim();
        processed = `<Thoughts>${extractedCot}<\/Thoughts>\n\n${processed}`;
        return processed;
      }
    } catch (error) {}

    PluginToastUI.show("CoT 분리에 실패함", 3000);
    return original;
  }

  private static async geminiRemoveForeignLanguages(
    original: string
  ): Promise<string> {
    const thoughts: string[] = [];
    const originalWithoutThoughts = original.replace(
      /<Thoughts>([\s\S]*?)<\/Thoughts>/g,
      (match, p1) => {
        thoughts.push(p1);
        return "";
      }
    );

    // Exclude English, Korean, and Emoji from Unicode character sets
    // Add follwing to exclude Japanese: \p{Hira}\p{Kana}\p{Han}
    if (
      !originalWithoutThoughts.match(
        /[\p{L}](?<![a-zA-Zㄱ-ㅎㅏ-ㅣ가-힣\p{Emoji_Presentation}])/gu
      )
    ) {
      return original;
    }

    const chatmlPrompt = Utils.parseChatML(
      DEFAULT.CHAT_GEMINI_FOREIGN_LANGUAGE_REMOVAL_PROMPT
    );

    if (!chatmlPrompt) {
      throw new Error(
        "Gemini foreign language removal prompt is not in ChatML format."
      );
    }

    const pluginRequest: PluginV2ProviderArgument = {
      prompt_chat: chatmlPrompt.map((message) => ({
        ...message,
        content: message.content.replace(
          /{{slot::content}}/g,
          originalWithoutThoughts
        ),
        thoughts: [],
      })),
      max_tokens: 8192,
      temperature: 0,
      top_p: 0.9,
      presence_penalty: 0,
      frequency_penalty: 0,
      top_k: 40,
      min_p: 0,
      repetition_penalty: 0,
      thinking_tokens: 0,
      stop_sequences: [],
      mode: "translate",
    };

    try {
      Logger.info(
        "Languages ​​other than Korean and English have been detected. Removing foreign languages."
      );
      PluginToastUI.show("외국어 정상화하는 중", 3000);

      const modelDef = getLLMDefinition(
        "gemini-2.0-flash-exp"
      ) as LLMDefinition;
      const modelContent = (
        await AutoProvider.getResponse(pluginRequest, modelDef)
      ).trim();
      Logger.debug("Model content:", modelContent);

      return (
        thoughts
          .map((thought) => `<Thoughts>${thought}</Thoughts>`)
          .join("\n\n") + modelContent
      );
    } catch (error) {
      PluginToastUI.show("외국어 제거에 실패함", 3000);
      return original;
    }
  }

  private static applyEmotionPreProcessing(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): void {
    // Gemini: the use of the system role should be avoided for jailbreak
    if (modelDef.id.includes("gemini")) {
      pluginRequest.prompt_chat.forEach((message) => {
        if (message.role === LLM_ROLE.SYSTEM) {
          message.role = LLM_ROLE.USER;
        }
      });
    }

    // Remove thoughts
    pluginRequest.prompt_chat.forEach((message) => {
      if (message.role !== LLM_ROLE.USER) {
        return;
      }

      message.content = message.content.replace(
        /<Thoughts>([\s\S]*?)<\/Thoughts>/g,
        (match, p1) => {
          return "";
        }
      );
    });
  }

  private static applyMemoryPreProcessing(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition,
    memorySettings: MemorySettings
  ): void {
    if (memorySettings.prefill != "") {
      pluginRequest.prompt_chat.push({
        role: LLM_ROLE.ASSISTANT,
        content: memorySettings.prefill,
        thoughts: [],
      });
    }
  }

  private static applyTranslationPreProcessing(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition,
    translationSettings: TranslationSettings
  ): void {
    if (translationSettings.prefill != "") {
      pluginRequest.prompt_chat.push({
        role: LLM_ROLE.ASSISTANT,
        content: translationSettings.prefill,
        thoughts: [],
      });
    }

    // Remove thoughts
    if (translationSettings.removeThoughts) {
      pluginRequest.prompt_chat.forEach((message) => {
        if (message.role !== LLM_ROLE.USER) {
          return;
        }

        message.content = message.content.replace(
          /<Thoughts>([\s\S]*?)<\/Thoughts>/g,
          (match, p1) => {
            return "";
          }
        );

        message.content = message.content.replace(
          /<details><summary>.*<\/summary>([\s\S]*?)<\/details>/g,
          (match, p1) => {
            return "";
          }
        );
      });
    }
  }

  private static async translateHTML(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition,
    translationSettings: TranslationSettings
  ): Promise<string> {
    const processedRequest = structuredClone(pluginRequest);

    const preprocessCBSIndex = processedRequest.prompt_chat.findIndex(
      (message) => message.content.match(/{{lbi::trans::preprocess}}/i)
    );

    if (preprocessCBSIndex === -1) {
      throw new Error(
        `No message to preprocess found in the request: ${JSON.stringify(
          pluginRequest
        )}`
      );
    }

    processedRequest.prompt_chat[preprocessCBSIndex].content =
      processedRequest.prompt_chat[preprocessCBSIndex].content.replace(
        /{{lbi::trans::preprocess}}/i,
        ""
      );

    const originalInput =
      processedRequest.prompt_chat[preprocessCBSIndex].content;
    Logger.debug("Original input:", originalInput);

    const parser = new HTMLTextSeparator(originalInput);
    const textNodes: Text[] = parser.textNodes.filter(
      (node) => node.textContent
    );
    const matchBetweenSpaces = /^\s*([\s\S]+?)\s*$/;

    // Create JSON object
    const jsonInput = textNodes.map((node, index) => ({
      id: index,
      source_text: node.textContent!.match(matchBetweenSpaces)![1],
    }));
    Logger.debug("JSON input:", jsonInput);

    processedRequest.prompt_chat[preprocessCBSIndex].content =
      JSON.stringify(jsonInput);

    // Detect input language
    const inputKoreanRatio = Utils.getKoreanPercentage(
      jsonInput.map((e) => e.source_text).join("")
    );
    Logger.info("Korean ratio in JSON input:", inputKoreanRatio);

    if (inputKoreanRatio > 50) {
      processedRequest.prompt_chat = processedRequest.prompt_chat.map(
        (message) => ({
          ...message,
          content: message.content.replace(
            /{{lbi::trans::targetlang}}/gi,
            "English"
          ),
        })
      );

      Logger.info("Set target language to English.");
    } else {
      processedRequest.prompt_chat = processedRequest.prompt_chat.map(
        (message) => ({
          ...message,
          content: message.content.replace(
            /{{lbi::trans::targetlang}}/gi,
            "Korean"
          ),
        })
      );

      Logger.info("Set target language to Korean.");
    }

    // Set JSON Schema
    /*
    {
      $schema: "https://json-schema.org/draft/2020-12/schema",
      type: "array",
      items: {
        type: "object",
        properties: {
          id: {
            type: "integer",
          },
          target_text: {
            type: "string",
          },
        },
        additionalProperties: false,
        required: ["id", "target_text"],
      },
      additionalItems: false,
    }
    processedRequest.json_schema = {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: {
            type: "integer",
          },
          target_text: {
            type: "string",
          },
        },
        required: ["id", "target_text"],
      },
    };
    */

    // Call API
    const modelContent = await AutoProvider.getResponse(
      processedRequest,
      modelDef
    );
    Logger.debug("Model output:", modelContent);

    // Try parsing JSON
    let jsonContent: Array<{ id: number; target_text: string }>;

    try {
      jsonContent = JSON.parse(modelContent.match(/\[[\s\S]*\]/)![0]);
    } catch (parseError) {
      jsonContent = RequestHandler.parseTranslationJSON(modelContent);

      Logger.warn(
        `Fixed the invalid JSON, but this may lead to unintended results.`
      );
    }

    Logger.debug("JSON output:", jsonContent);

    jsonContent.forEach(({ id, target_text }) => {
      if (id >= 0 && id < textNodes.length) {
        const node = textNodes[id];

        if (translationSettings.showOriginal) {
          const originalArray = node.textContent!.split("\n");
          const translatedArray = node
            .textContent!.replace(matchBetweenSpaces, (match, p1) => {
              return match.replace(p1, target_text);
            })
            .split("\n");

          if (originalArray.length !== translatedArray.length) {
            node.textContent =
              node.textContent +
              "\n\n" +
              node.textContent!.replace(matchBetweenSpaces, (match, p1) => {
                return match.replace(p1, target_text);
              });

            Logger.warn(
              "The number of paragraphs in the source text and the target text do not match:",
              id
            );
          } else {
            const parallelArray = [];

            for (let i = 0; i < translatedArray.length; i++) {
              if (/[\p{L}]/gu.test(originalArray[i])) {
                parallelArray.push(originalArray[i]);
                parallelArray.push(translatedArray[i]);
              } else {
                parallelArray.push(originalArray[i]);
              }
            }

            node.textContent = parallelArray.join("\n\n");
          }
        } else {
          node.textContent = node.textContent!.replace(
            matchBetweenSpaces,
            (match, p1) => {
              return match.replace(p1, target_text);
            }
          );
        }
      } else {
        Logger.warn("API returned an invalid HTML node id:", id);
      }
    });

    // Create final output
    const finalOutput = parser.toString();
    Logger.debug("Final output:", finalOutput);

    return finalOutput;
  }

  private static parseTranslationJSON(
    modelContent: string
  ): Array<{ id: number; target_text: string }> {
    try {
      const matches = modelContent
        .trim()
        // IN: \`\`\`json\n[{"id":0,"target_text":"first"}] [{"id":0,"target_text":"middle"}] [{"id":0,"target_text":"last"}]\n\`\`\`
        // OUT: [{"id":0,"target_text":"first"}] [{"id":0,"target_text":"middle"}] [{"id":0,"target_text":"last"}]
        .match(/\[[\s\S]*\]/)?.[0]
        // IN: [{"id":0,"target_text":"⏷"})]
        // OUT: [{"id":0,"target_text":"⏷"}]
        .replace(/}\s*\)\s*]$/, "}]")
        // IN: [{"id":0,"target_text":"first"}] [{"id":0,"target_text":"middle"}] [{"id":0,"target_text":"last"}]
        .match(
          /\[\s*{\s*"id"\s*:\s*\d+\s*,\s*"target_text"\s*:\s*"[\s\S]*?"\s*}\s*]/g
        );

      // OUT: [{"id":0,"target_text":"last"}]
      const lastMatch = matches?.[matches.length - 1];

      const fixed = lastMatch
        // IN: "target_text" : "번역문\"}
        // OUT: "target_text" : "번역문"}
        ?.replace(/("target_text"\s*:\s*"[\s\S]*?)\\?"\s*}/g, '$1"}')
        // target_text 필드 내의 이스케이프되지 않은 줄바꿈만 이스케이프 처리
        .replace(
          /"target_text"\s*:\s*"([\s\S]*?)(?="\s*,|"\s*}|"\s*}\s*])/g,
          (match, p1) => match.replace(p1, p1.replace(/\n/g, "\\n"))
        )
        // target_text 필드 내의 이스케이프되지 않은 큰 따옴표만 이스케이프 처리
        .replace(
          /"target_text"\s*:\s*"(.*?)(?="\s*,|"\s*}|"\s*}\s*])/g,
          (match, p1) => {
            return `"target_text":"${p1.replace(/(?<!\\)"/g, '\\"')}`;
          }
        )
        // 기울어진 큰 따옴표를 이스케이프된 일반 큰 따옴표로 변경
        .replace(/[“”]/g, '\\"');

      if (fixed) {
        return JSON.parse(fixed);
      }
    } catch (error) {}

    throw new Error(
      `API returned an invalid JSON format. Please try again with the correct prompt: ${modelContent}`
    );
  }

  private static applyTranslationPostProcessing(
    content: string,
    modelDef: LLMDefinition,
    translationSettings: TranslationSettings
  ): void {
    if (translationSettings.saveToTranslatorNote) {
      let tnote = risuAPI.getChar().translatorNote || "";
      const lastContext = tnote
        .match(/<Previous Context>([\s\S]*?)<\/Previous Context>/)?.[1]
        ?.trim();
      const realContent = content
        .replace(/<details><summary>.*<\/summary>([\s\S]*?)<\/details>/, "")
        .trim();

      if (lastContext == null) {
        if (tnote) tnote += "\n\n";
        tnote += `<Previous Context>\n${realContent}\n</Previous Context>`;
      } else {
        tnote = tnote.replace(
          /<Previous Context>([\s\S]*?)<\/Previous Context>/,
          `<Previous Context>\n${realContent}\n</Previous Context>`
        );
      }

      risuAPI.getChar().translatorNote = tnote;
    }
  }
}

class AutoProvider {
  private static googleAIProvider: {
    lastApiKeys: string;
    parsedApiKeys: string[];
  } = {
    lastApiKeys: "",
    parsedApiKeys: [],
  };

  private static vertexAIProvider: {
    lastCredentials: string;
    parsedCredentials: VertexAICredential[];
  } = {
    lastCredentials: "",
    parsedCredentials: [],
  };

  public static async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    while (true) {
      const commonSettings = getCommonSettings();
      const provider = AutoProvider.getProvider(modelDef);

      try {
        return await provider.getResponse(pluginRequest, modelDef);
      } catch (error: any) {
        // Google AI key rotation
        if (
          provider instanceof GoogleAIProvider &&
          error?.error?.code === 429
        ) {
          Utils.removeElement(
            AutoProvider.googleAIProvider.parsedApiKeys,
            provider.apiKey
          );

          // No keys left
          if (AutoProvider.googleAIProvider.parsedApiKeys.length === 0) {
            const vertexId = "vertex-" + modelDef.id;
            const vertexDef = getLLMDefinition(vertexId);

            if (commonSettings.fallbackToVertexGemini && vertexDef) {
              PluginToastUI.show("버텍스 제미니로 폴백", 2000);

              return await AutoProvider.getResponse(pluginRequest, vertexDef);
            }

            throw new Error(
              `'사용 가능한' 구글 스튜디오 키가 없음: ${JSON.stringify(error)}`
            );
          }

          // Retry with new key
          continue;
        }

        // Vertex AI key rotation
        if (
          provider instanceof VertexAIProvider &&
          error?.error?.code === 429
        ) {
          Utils.removeElement(
            AutoProvider.vertexAIProvider.parsedCredentials,
            provider.credential
          );

          // No keys left
          if (AutoProvider.vertexAIProvider.parsedCredentials.length === 0) {
            throw new Error(
              `'사용 가능한' 버텍스 키가 없음: ${JSON.stringify(error)}`
            );
          }

          // Retry with new key
          continue;
        }

        // Other error
        throw error;
      }
    }
  }

  public static async getStreamedResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<ReadableStream<string>> {
    const provider = AutoProvider.getProvider(modelDef);

    if (!provider.getStreamedResponse) {
      throw new Error(
        `Streaming is not supported for model: ${modelDef.uniqueId}`
      );
    }

    return await provider.getStreamedResponse(pluginRequest, modelDef);
  }

  private static getProvider(modelDef: LLMDefinition): BaseProvider {
    const commonSettings = getCommonSettings();

    if (modelDef.provider === LLM_PROVIDER.GOOGLEAI) {
      // Update api key list
      if (
        AutoProvider.googleAIProvider.lastApiKeys !==
          commonSettings.googleAIProvider_apiKey ||
        AutoProvider.googleAIProvider.parsedApiKeys.length === 0
      ) {
        AutoProvider.googleAIProvider.parsedApiKeys =
          commonSettings.googleAIProvider_apiKey
            .trim()
            .split(/\s+/)
            .map((key) => key.trim())
            .filter((key) => key.length > 0);

        AutoProvider.googleAIProvider.lastApiKeys =
          commonSettings.googleAIProvider_apiKey;
      }

      // Select api key
      const apiKey = Utils.pickElement(
        AutoProvider.googleAIProvider.parsedApiKeys
      );

      if (!apiKey) {
        throw new Error(
          "구글 스튜디오 키가 없음: API 키 칸에 유효한 키를 넣으세요."
        );
      }

      return new GoogleAIProvider(apiKey);
    }

    if (modelDef.provider === LLM_PROVIDER.VERTEXAI) {
      // Append legacy credential
      if (
        commonSettings.vertexAIProvider_projectId !== "" &&
        commonSettings.vertexAIProvider_privateKey !== "" &&
        commonSettings.vertexAIProvider_clientEmail !== ""
      ) {
        const legacy = {
          project_id: commonSettings.vertexAIProvider_projectId,
          private_key: commonSettings.vertexAIProvider_privateKey,
          client_email: commonSettings.vertexAIProvider_clientEmail,
        };

        commonSettings.vertexAIProvider_credentials =
          JSON.stringify(legacy) +
          (commonSettings.vertexAIProvider_credentials
            ? ", " + commonSettings.vertexAIProvider_credentials
            : "");
      }

      // Update credential list
      if (
        AutoProvider.vertexAIProvider.lastCredentials !==
          commonSettings.vertexAIProvider_credentials ||
        AutoProvider.vertexAIProvider.parsedCredentials.length === 0
      ) {
        try {
          const parsed = JSON.parse(
            "[" + commonSettings.vertexAIProvider_credentials.trim() + "]"
          );

          if (
            !Array.isArray(parsed) ||
            !parsed.every((e) => typeof e === "object" && e !== null)
          ) {
            throw new Error("Invalid Vertex AI JSON keys.");
          }

          AutoProvider.vertexAIProvider.parsedCredentials = parsed;
          AutoProvider.vertexAIProvider.lastCredentials =
            commonSettings.vertexAIProvider_credentials;
        } catch (error) {
          throw new Error("Invalid Vertex AI JSON keys.");
        }
      }

      const credential = Utils.pickElement(
        AutoProvider.vertexAIProvider.parsedCredentials
      );

      if (!credential) {
        throw new Error(
          "버텍스 키가 없음: JSON 키 파일 칸에 유효한 키를 넣으세요."
        );
      }

      return new VertexAIProvider(credential);
    }

    if (modelDef.provider === LLM_PROVIDER.ANTHROPIC) {
      return new AnthropicProvider(commonSettings.anthropicProvider_apiKey);
    }

    if (modelDef.provider === LLM_PROVIDER.DEEPSEEK) {
      return new DeepseekProvider(
        commonSettings.deepseekProvider_apiKey,
        commonSettings.deepseekProvider_customUrl
      );
    }

    if (modelDef.provider === LLM_PROVIDER.OPENAI) {
      return new OpenAIProvider(commonSettings.openaiProvider_apiKey);
    }

    if (modelDef.provider === LLM_PROVIDER.AWS) {
      return new AWSProvider(
        commonSettings.awsProvider_accessKey,
        commonSettings.awsProvider_secretAccessKey,
        commonSettings.awsProvider_region
      );
    }

    if (modelDef.provider === LLM_PROVIDER.OPENAICOMPATIBLE) {
      modelDef.id = commonSettings.openaiCompatibleProvider_model;

      return new OpenAICompatibleProvider(
        commonSettings.openaiCompatibleProvider_url,
        commonSettings.openaiCompatibleProvider_apiKey
      );
    }

    throw new Error(`No provider found for model: ${modelDef.uniqueId}`);
  }
}

interface DeepseekMessage {
  role: LLMRole;
  content: string;
  prefix?: boolean;
}

interface DeepseekBody {
  messages: DeepseekMessage[];
  model: string;
  max_tokens: number;
  temperature?: number;
  top_p?: number;
  frequency_penalty?: number;
  presence_penalty?: number;
  response_format?: {
    type: "text" | "json_object";
  };
  stop?: string[];
  stream?: boolean;
  stream_options?: {
    include_usage: boolean;
  };
  tools?: [
    type: "function",
    function: {
      name: string;
      description: string;
      parameters: object;
    }
  ];
  tool_choice?: object;
  logprobs?: boolean;
  top_logprobs?: number;
}

class DeepseekProvider extends BaseProvider {
  private static readonly proxyModelAliasMap: {
    readonly [key: string]: string;
  } = {
    default: "deepseek-ai/DeepSeek-R1",
    "https://openrouter.ai/api/v1/chat/completions": "deepseek/deepseek-r1",
    "https://api.fireworks.ai/inference/v1/chat/completions":
      "accounts/fireworks/models/deepseek-r1",
    "https://api.together.xyz/v1/chat/completions": "deepseek-ai/DeepSeek-R1",
    "https://api.hyperbolic.xyz/v1/chat/completions": "deepseek-ai/DeepSeek-R1",
    "https://api.kluster.ai/v1/chat/completions": "deepseek-ai/DeepSeek-R1",
    "https://api.featherless.ai/v1/chat/completions": "deepseek-ai/DeepSeek-R1",
    "https://chatapi.akash.network/api/v1/chat/completions": "DeepSeek-R1",
    "https://api.minimaxi.chat/v1/text/chatcompletion_v2": "DeepSeek-R1",
  };

  private readonly apiKey: string;
  private readonly customUrl?: string;

  public constructor(apiKey: string, customUrl?: string) {
    super();
    this.apiKey = apiKey;
    this.customUrl = customUrl;
  }

  private static buildDeepseekBody(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): DeepseekBody {
    const commonSettings = getCommonSettings();
    const requestType = Utils.getRequestType(pluginRequest);
    const openAIChats = structuredClone(pluginRequest.prompt_chat);

    // Find the index where the first 'user' or 'assistant' role appears
    let splitIndex = openAIChats.findIndex(
      (message) =>
        message.role === LLM_ROLE.USER || message.role === LLM_ROLE.ASSISTANT
    );

    // If no 'user' or 'assistant' role is found, set splitIndex to the length of the array
    if (splitIndex === -1) {
      splitIndex = openAIChats.length;
    }

    // Extract the beginning consecutive system messages and join content of the system messages using '\n\n'
    const system: DeepseekMessage = {
      role: LLM_ROLE.SYSTEM,
      content: openAIChats
        .slice(0, splitIndex)
        .map((message) => message.content.trim())
        .join("\n\n"),
    };

    // Remove the system messages from the original array
    openAIChats.splice(0, splitIndex);

    // Ensure the first message is the user message
    if (openAIChats.length === 0 || openAIChats[0].role !== LLM_ROLE.USER) {
      openAIChats.unshift({ role: LLM_ROLE.USER, content: "Start" });
    }

    // Build messages
    const messages: DeepseekMessage[] = [];

    for (let i = 0; i < openAIChats.length; i++) {
      const message = openAIChats[i];
      const trimedContent = message.content.trim();
      const lastMessage =
        messages.length > 0 ? messages[messages.length - 1] : null;

      if (message.role === LLM_ROLE.SYSTEM) {
        if (lastMessage?.role === LLM_ROLE.USER) {
          messages[messages.length - 1].content += "\n\n" + trimedContent;
        } else {
          messages.push({
            role: LLM_ROLE.USER,
            content: trimedContent,
          });
        }
      } else if (
        message.role === LLM_ROLE.USER ||
        message.role === LLM_ROLE.ASSISTANT
      ) {
        if (lastMessage?.role === message.role) {
          messages[messages.length - 1].content += "\n\n" + trimedContent;
        } else {
          messages.push({
            role: message.role,
            content: trimedContent,
          });
        }
      }
    }

    // Restore system message
    if (system.content !== "") {
      messages.unshift(system);
    }

    // Add prefix to last assistant message
    const lastMessage = messages.at(-1);

    if (lastMessage?.role === LLM_ROLE.ASSISTANT) {
      lastMessage.prefix = true;
    }

    // Build body
    const body: DeepseekBody = {
      messages: messages,
      model: modelDef.id,
      max_tokens: pluginRequest.max_tokens,

      ...(pluginRequest.temperature != null && {
        temperature: pluginRequest.temperature,
      }),
      ...(pluginRequest.top_p != null && { top_p: pluginRequest.top_p }),
      ...(pluginRequest.frequency_penalty != null && {
        frequency_penalty: pluginRequest.frequency_penalty,
      }),
      ...(pluginRequest.presence_penalty != null && {
        presence_penalty: pluginRequest.presence_penalty,
      }),
    };

    // Validate api parameters
    DeepseekProvider.validateApiParameters(body);

    // Preview prompt
    if (
      commonSettings.previewPrompt &&
      (requestType === REQUEST_TYPE.CHAT ||
        requestType === REQUEST_TYPE.TRANSLATION)
    ) {
      const bodyCloned = structuredClone(body);

      for (let i = 0; i < bodyCloned.messages.length; i++) {
        const message = bodyCloned.messages[i];
        const sameRoleMessages = bodyCloned.messages.filter(
          (v) => v.role === message.role
        );
        const reverseIndex = -(
          sameRoleMessages.length - sameRoleMessages.indexOf(message)
        );

        if (message.role === LLM_ROLE.SYSTEM) {
          continue;
        }

        message.role = `${message.role}[${reverseIndex}]` as LLMRole;
      }

      PluginTextEditorUI.showModal(
        "프롬프트 미리보기",
        JSON.stringify(bodyCloned, null, 2)
      );

      throw new Error(
        "Sending chat is interrupted because 'preview prompt' option is turned on."
      );
    }

    return body;
  }

  private static validateApiParameters(body: DeepseekBody): void {
    if (
      body.temperature != null &&
      (body.temperature < 0 || body.temperature > 2)
    ) {
      body.temperature = 1;
    }

    if (body.top_p != null && (body.top_p < 0 || body.top_p > 1)) {
      delete body.top_p;
    }

    if (
      body.frequency_penalty != null &&
      (body.frequency_penalty < -2 || body.frequency_penalty > 2)
    ) {
      delete body.frequency_penalty;
    }

    if (
      body.presence_penalty != null &&
      (body.presence_penalty < -2 || body.presence_penalty > 2)
    ) {
      delete body.presence_penalty;
    }
  }

  public async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    // Determine the actual model
    if (this.customUrl && modelDef.id.includes("reasoner")) {
      modelDef.id =
        DeepseekProvider.proxyModelAliasMap[this.customUrl] ||
        DeepseekProvider.proxyModelAliasMap.default;
      Logger.info("Using custom url:", this.customUrl);
    }

    const url =
      this.customUrl || "https://api.deepseek.com/beta/v1/chat/completions";

    const jsonBody = DeepseekProvider.buildDeepseekBody(
      pluginRequest,
      modelDef
    );

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
      },
      body: jsonBody,
      rawResponse: false,
    };

    Logger.info("Calling Deepseek with model:", modelDef.id);
    const response = await risuFetchEx(pluginRequest, url, fetchArgs);

    if (!response.ok) {
      throw new Error(JSON.stringify(response.data));
    }

    const reasoningPart =
      response?.data?.choices?.[0]?.message?.reasoning_content;
    const contentPart = response?.data?.choices?.[0]?.message?.content;
    let parsed = "";

    if (!contentPart) {
      Logger.error("No content field in response");
      throw new Error(JSON.stringify(response.data));
    }

    switch (Utils.getRequestType(pluginRequest)) {
      case REQUEST_TYPE.CHAT: {
        parsed +=
          reasoningPart?.length > 0
            ? `<Thoughts>\n\n${reasoningPart}\n</Thoughts>\n\n`
            : "";

        parsed += contentPart;
        break;
      }

      case REQUEST_TYPE.TRANSLATION: {
        // Translation should return <details> tag instead of <Thoughts> tag,
        // and a line break (\n\n) should follow the </summary> tag
        // to ensure proper markdown formatting
        parsed +=
          reasoningPart?.length > 0
            ? `<details><summary>생각의 사슬</summary>\n\n${reasoningPart}</details>\n\n`
            : "";

        parsed += contentPart;
        break;
      }

      default: {
        parsed += contentPart;
        break;
      }
    }

    return parsed;
  }
}

interface GptMessage {
  role: LLMRole;
  content: string;
}

interface GptBody {
  model: string;
  messages: GptMessage[];
  max_tokens?: number;
  max_completion_tokens?: number;
  max_output_tokens?: number;
  temperature?: number;
  top_p?: number;
  frequency_penalty?: number;
  presence_penalty?: number;
  stream?: boolean;
}

interface OpenAIImageGenerateBody {
  prompt: string;
  background?: "auto" | "transparent" | "opaque";
  model?: "dall-e-2" | "dall-e-3" | "gpt-image-1";
  moderation?: "auto" | "low";
  n?: number;
  output_compression?: number;
  output_format?: "png" | "jpeg" | "webp";
  quality?: "auto" | "standard" | "hd" | "low" | "medium" | "high";
  response_format?: "url" | "b64_json";
  size?:
    | "auto"
    | "256x256"
    | "512x512"
    | "1024x1024"
    | "1024x1536"
    | "1024x1792"
    | "1536x1024"
    | "1792x1024";
  style?: "vivid" | "natural";
}

interface OpenAIImageEditBody {
  image: Blob[];
  prompt: string;
  mask?: Blob;
  model?: "dall-e-2" | "gpt-image-1";
  n?: number;
  quality?: "auto" | "standard" | "low" | "medium" | "high";
  response_format?: "url" | "b64_json";
  size?:
    | "auto"
    | "256x256"
    | "512x512"
    | "1024x1024"
    | "1024x1536"
    | "1536x1024";
}

class OpenAIProvider extends BaseProvider {
  private readonly apiKey: string;

  public constructor(apiKey: string) {
    super();
    this.apiKey = apiKey;
  }

  public static validateApiParameters(body: GptBody): void {
    if (
      body.temperature != null &&
      (body.temperature < 0 || body.temperature > 1)
    ) {
      body.temperature = 1;
    }

    if (body.top_p != null && (body.top_p < 0 || body.top_p > 2)) {
      delete body.top_p;
    }

    if (
      body.frequency_penalty != null &&
      (body.frequency_penalty < -2 || body.frequency_penalty > 2)
    ) {
      delete body.frequency_penalty;
    }

    if (
      body.presence_penalty != null &&
      (body.presence_penalty < -2 || body.presence_penalty > 2)
    ) {
      delete body.presence_penalty;
    }
  }

  private static buildGptBody(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): GptBody {
    const commonSettings = getCommonSettings();
    const requestType = Utils.getRequestType(pluginRequest);
    const openAIChats = structuredClone(pluginRequest.prompt_chat);

    // Find the index where the first 'user' or 'assistant' role appears
    let splitIndex = openAIChats.findIndex(
      (message) =>
        message.role === LLM_ROLE.USER || message.role === LLM_ROLE.ASSISTANT
    );

    // If no 'user' or 'assistant' role is found, set splitIndex to the length of the array
    if (splitIndex === -1) {
      splitIndex = openAIChats.length;
    }

    // Extract the beginning consecutive system messages and join content of the system messages using '\n\n'
    const system: GptMessage = {
      role: LLM_ROLE.SYSTEM,
      content: openAIChats
        .slice(0, splitIndex)
        .map((message) => message.content.trim())
        .join("\n\n"),
    };

    // Remove the system messages from the original array
    openAIChats.splice(0, splitIndex);

    // Build messages
    const messages: GptMessage[] = [];

    for (let i = 0; i < openAIChats.length; i++) {
      const message = openAIChats[i];
      const trimedContent = message.content.trim();
      const lastMessage =
        messages.length > 0 ? messages[messages.length - 1] : null;

      if (message.role === LLM_ROLE.SYSTEM) {
        if (lastMessage?.role === message.role) {
          messages[messages.length - 1].content += "\n\n" + trimedContent;
        } else {
          messages.push({
            role: message.role,
            content: trimedContent,
          });
        }
      } else if (
        message.role === LLM_ROLE.USER ||
        message.role === LLM_ROLE.ASSISTANT
      ) {
        messages.push({
          role: message.role,
          content: trimedContent,
        });
      }
    }

    // Restore system message
    if (system.content !== "") {
      messages.unshift(system);
    }

    // Convert system message to user message
    if (!modelDef.flags.includes(LLM_FLAG.hasFullSystemPrompt)) {
      messages.forEach((message) => {
        if (message.role === LLM_ROLE.SYSTEM) {
          message.role = LLM_ROLE.USER;
        }
      });
    }

    // Build body
    const body: GptBody = {
      model: modelDef.id,
      messages: messages,
      ...(modelDef.flags.includes(LLM_FLAG.hasMaxCompletionTokens)
        ? { max_completion_tokens: pluginRequest.max_tokens }
        : { max_tokens: pluginRequest.max_tokens }),
      ...(pluginRequest.temperature != null && {
        temperature: pluginRequest.temperature,
      }),
      ...(pluginRequest.top_p != null && { top_p: pluginRequest.top_p }),
      ...(pluginRequest.frequency_penalty != null && {
        frequency_penalty: pluginRequest.frequency_penalty,
      }),
      ...(pluginRequest.presence_penalty != null && {
        presence_penalty: pluginRequest.presence_penalty,
      }),
    };

    // Validate api parameters
    OpenAIProvider.validateApiParameters(body);

    // Preview prompt
    if (
      commonSettings.previewPrompt &&
      (requestType === REQUEST_TYPE.CHAT ||
        requestType === REQUEST_TYPE.TRANSLATION)
    ) {
      const bodyCloned = structuredClone(body);

      for (let i = 0; i < bodyCloned.messages.length; i++) {
        const message = bodyCloned.messages[i];
        const sameRoleMessages = bodyCloned.messages.filter(
          (v) => v.role === message.role
        );
        const reverseIndex = -(
          sameRoleMessages.length - sameRoleMessages.indexOf(message)
        );

        message.role = `${message.role}[${reverseIndex}]` as LLMRole;
      }

      PluginTextEditorUI.showModal(
        "프롬프트 미리보기",
        JSON.stringify(bodyCloned, null, 2)
      );

      throw new Error(
        "Sending chat is interrupted because 'preview prompt' option is turned on."
      );
    }

    return body;
  }

  public async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    const url = `https://api.openai.com/v1/chat/completions`;

    const jsonBody = OpenAIProvider.buildGptBody(pluginRequest, modelDef);

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
      },
      body: jsonBody,
      rawResponse: false,
    };

    Logger.info("Calling OpenAI with model:", modelDef.id);
    const response = await risuFetchEx(pluginRequest, url, fetchArgs);

    if (!response.ok) {
      throw new Error(JSON.stringify(response.data));
    }

    const contentPart = response?.data?.choices?.[0]?.message?.content;

    if (!contentPart) {
      Logger.error("No content field in response");
      throw new Error(JSON.stringify(response.data));
    }

    return contentPart;
  }

  public async textToImage(
    pluginRequest: PluginV2ProviderArgument,
    body: OpenAIImageGenerateBody
  ) {
    if (body.model === "gpt-image-1") {
      body.moderation = body.moderation || "low";
      delete body.response_format;
    } else {
      body.response_format = "b64_json";
    }

    const url = `https://api.openai.com/v1/images/generations`;

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
      },
      body: body,
      rawResponse: false,
    };

    Logger.info("Calling OpenAI with model:", body.model);
    const response = await risuFetchEx(pluginRequest, url, fetchArgs);

    if (!response.ok) {
      throw new Error(JSON.stringify(response.data));
    }

    const imageParts: Record<string, string>[] = response.data?.data;

    if (!imageParts || imageParts.length === 0) {
      Logger.error("No data field in response");
      throw new Error(JSON.stringify(response.data));
    }

    const createRequests = imageParts.map(async (imagePart) => {
      const inlayId = await InlayCache.create(
        `data:image/${body.output_format || "png"};base64,${imagePart.b64_json}`
      );

      return `{{inlay::${inlayId}}}`;
    });

    const inlays = await Promise.all(createRequests);

    return inlays.length === 1 ? inlays[0] : inlays.join("\n");
  }

  public async imageToImage(
    pluginRequest: PluginV2ProviderArgument,
    body: OpenAIImageEditBody
  ) {
    if (body.model === "gpt-image-1") {
      delete body.response_format;
    } else {
      body.response_format = "b64_json";
    }

    const url = `https://api.openai.com/v1/images/edits`;

    // Build real body
    const formData = new FormData();

    body.image.forEach((img) => {
      formData.append("image[]", img);
    });

    formData.append("prompt", body.prompt);

    if (body.mask) {
      formData.append("mask", body.mask);
    }

    if (body.model) formData.append("model", body.model);
    if (body.n) formData.append("n", String(body.n));
    if (body.quality) formData.append("quality", body.quality);
    if (body.size) formData.append("size", body.size);

    // const respFormData = new Response(formData);
    // const bytesFormData = new Uint8Array(await respFormData.arrayBuffer());
    // const contentType = respFormData.headers.get("Content-Type") as string;

    const fetchArgs = {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        // "Content-Type": contentType,
      },
      // body: bytesFormData,
      body: formData,
    };

    Logger.info("Calling OpenAI with model:", body.model);

    // nativeFetch was causing lag when viewing request log
    // const response = await nativeFetch(url, fetchArgs);
    const response = await fetch(url, fetchArgs);

    if (response.status !== 200) {
      throw new Error(await new Response(response.body).text());
    }

    const responseBody = await response.json();
    const imageParts: Record<string, string>[] = responseBody?.data;

    if (!imageParts || imageParts.length === 0) {
      Logger.error("No data field in response");
      throw new Error(JSON.stringify(responseBody));
    }

    const createRequests = imageParts.map(async (imagePart) => {
      const inlayId = await InlayCache.create(
        `data:image/png;base64,${imagePart.b64_json}`
      );

      return `{{inlay::${inlayId}}}`;
    });

    const inlays = await Promise.all(createRequests);

    return inlays.length === 1 ? inlays[0] : inlays.join(" ");
  }
}

class OpenAICompatibleProvider extends BaseProvider {
  private readonly url: string;
  private readonly apiKey: string;

  public constructor(url: string, apiKey: string) {
    super();
    this.url = url;
    this.apiKey = apiKey;
  }

  private static buildGptBody(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): GptBody {
    const commonSettings = getCommonSettings();
    const requestType = Utils.getRequestType(pluginRequest);
    let openAIChats: OpenAIChat[] = structuredClone(pluginRequest.prompt_chat);
    let systemMessage: OpenAIChat | null = null;

    if (commonSettings.openaiCompatibleProvider_hasFirstSystemPrompt) {
      while (openAIChats[0].role === LLM_ROLE.SYSTEM) {
        if (systemMessage) {
          systemMessage.content += "\n\n" + openAIChats[0].content.trim();
        } else {
          systemMessage = {
            role: LLM_ROLE.SYSTEM,
            content: openAIChats[0].content.trim(),
          };
        }

        openAIChats = openAIChats.slice(1);
      }

      for (let i = 0; i < openAIChats.length; i++) {
        if (openAIChats[i].role === LLM_ROLE.SYSTEM) {
          openAIChats[i].role = LLM_ROLE.USER;
        }
      }
    }

    if (commonSettings.openaiCompatibleProvider_requiresAlternateRole) {
      let newMessages: OpenAIChat[] = [];

      for (let i = 0; i < openAIChats.length; i++) {
        const message = openAIChats[i];
        const trimedContent = message.content.trim();
        const lastMessage = newMessages.length > 0 ? newMessages.at(-1) : null;

        if (
          message.role === LLM_ROLE.SYSTEM ||
          message.role === LLM_ROLE.USER ||
          message.role === LLM_ROLE.ASSISTANT
        ) {
          if (lastMessage?.role === message.role) {
            newMessages[newMessages.length - 1].content +=
              "\n\n" + trimedContent;
          } else {
            newMessages.push({
              role: message.role,
              content: trimedContent,
            });
          }
        }
      }

      openAIChats = newMessages;
    }

    if (commonSettings.openaiCompatibleProvider_mustStartWithUserInput) {
      if (openAIChats.length === 0 || openAIChats[0].role !== LLM_ROLE.USER) {
        openAIChats.unshift({ role: LLM_ROLE.USER, content: "Start" });
      }
    }

    if (systemMessage) {
      openAIChats.unshift(systemMessage);
    }

    // Build messages
    const gptMessages: GptMessage[] = [];

    for (let i = 0; i < openAIChats.length; i++) {
      const message = openAIChats[i];

      if (
        message.role === LLM_ROLE.SYSTEM ||
        message.role === LLM_ROLE.USER ||
        message.role === LLM_ROLE.ASSISTANT
      ) {
        gptMessages.push({ role: message.role, content: message.content });
      }
    }

    // Build body
    const body: GptBody = {
      model: modelDef.id,
      messages: gptMessages,
      ...(commonSettings.openaiCompatibleProvider_useMaxOutputTokensInstead
        ? { max_output_tokens: pluginRequest.max_tokens }
        : { max_tokens: pluginRequest.max_tokens }),
      ...(pluginRequest.temperature != null && {
        temperature: pluginRequest.temperature,
      }),
      ...(pluginRequest.top_p != null && { top_p: pluginRequest.top_p }),
      ...(pluginRequest.frequency_penalty != null && {
        frequency_penalty: pluginRequest.frequency_penalty,
      }),
      ...(pluginRequest.presence_penalty != null && {
        presence_penalty: pluginRequest.presence_penalty,
      }),
    };

    // Github claude thinking
    if (
      OpenAICompatibleProvider.isGithubClaudeThinking(pluginRequest, modelDef)
    ) {
      // Remove sampling parameters
      delete body.temperature;
      delete body.top_p;
      delete body.frequency_penalty;
      delete body.presence_penalty;

      // Remove prefills
      while (
        body.messages.length > 0 &&
        body.messages.at(-1)?.role === LLM_ROLE.ASSISTANT
      ) {
        body.messages.pop();
      }
    }

    // Preview prompt
    if (
      commonSettings.previewPrompt &&
      (requestType === REQUEST_TYPE.CHAT ||
        requestType === REQUEST_TYPE.TRANSLATION)
    ) {
      const bodyCloned = structuredClone(body);

      for (let i = 0; i < bodyCloned.messages.length; i++) {
        const message = bodyCloned.messages[i];
        const sameRoleMessages = bodyCloned.messages.filter(
          (v) => v.role === message.role
        );
        const reverseIndex = -(
          sameRoleMessages.length - sameRoleMessages.indexOf(message)
        );

        message.role = `${message.role}[${reverseIndex}]` as LLMRole;
      }

      PluginTextEditorUI.showModal(
        "프롬프트 미리보기",
        JSON.stringify(bodyCloned, null, 2)
      );

      throw new Error(
        "Sending chat is interrupted because 'preview prompt' option is turned on."
      );
    }

    return body;
  }

  private static isGithubClaudeThinking(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): boolean {
    const thinkingModels: readonly string[] = ["claude-3.7-sonnet-thought"];

    return thinkingModels.includes(modelDef.id);
  }

  public async getResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<string> {
    const jsonBody = OpenAICompatibleProvider.buildGptBody(
      pluginRequest,
      modelDef
    );

    const fetchArgs: GlobalFetchArgs = {
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
      },
      body: jsonBody,
      rawResponse: false,
    };

    Logger.info("Calling OpenAICompatible with model:", modelDef.id);
    const response = await risuFetchEx(pluginRequest, this.url, fetchArgs);

    if (!response.ok) {
      throw new Error(JSON.stringify(response.data));
    }

    const contentPart = response?.data?.choices?.[0]?.message?.content;

    if (!contentPart) {
      Logger.error("No content field in response");
      throw new Error(JSON.stringify(response.data));
    }

    return contentPart;
  }

  public async getStreamedResponse(
    pluginRequest: PluginV2ProviderArgument,
    modelDef: LLMDefinition
  ): Promise<ReadableStream<string>> {
    const jsonBody = OpenAICompatibleProvider.buildGptBody(
      pluginRequest,
      modelDef
    );

    jsonBody.stream = true;

    const fetchArgs = {
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(jsonBody),
    };

    Logger.info("Calling OpenAI Compatible with model:", modelDef.id);
    const response = await risuAPI.nativeFetch(this.url, fetchArgs);

    if (response.status !== 200) {
      throw new Error(await new Response(response.body).text());
    }

    const stream = new ReadableStream<string>({
      async start(controller) {
        const reader = response.body!.getReader();
        const decoder = new TextDecoder();
        const prefix = "data: ";
        const parseLine = async (line: string) => {
          try {
            const parsed = JSON.parse(line);

            if (parsed?.choices?.[0]?.delta?.content) {
              return parsed.choices[0].delta.content;
            }

            if (parsed?.error) {
              return "\nError: " + parsed.error.message;
            }
          } catch (error) {}
        };
        let buffer = "";
        let i = 0;

        while (true) {
          try {
            const { value, done } = await reader.read();

            if (done) {
              break;
            }

            buffer += decoder.decode(value);

            const lines = buffer.split("\n\n");

            for (; i < lines.length - 1; i++) {
              const line = lines[i];

              // console.log(line); // Debug

              if (line.startsWith(prefix)) {
                const deltaText = await parseLine(line.slice(prefix.length));

                if (deltaText) {
                  controller.enqueue(deltaText);
                }
              }
            }
          } catch (error) {
            throw error;
          }
        }

        controller.close();
      },
      cancel() {},
    });

    return stream;
  }
}

function addProviderEx(displayName: string, defaultUniqueId: string): void {
  const doNotSetTokenizer: boolean = PLUGIN_SETTINGS_MANAGER.get(
    "compatibility_doNotSetTokenizer"
  );

  let options: PluginV2ProviderOptions = {};

  if (!doNotSetTokenizer) {
    const tokenizer = getLLMTokenizer(defaultUniqueId);

    options = { tokenizer: tokenizer };
    Logger.debug(`Setting tokenizer for ${defaultUniqueId}: ${tokenizer}`);
  } else {
    Logger.debug(
      `Skipping tokenizer setting for ${defaultUniqueId} (compatibility mode)`
    );
  }

  risuAPI.addProvider(
    displayName,
    async (pluginRequest, abortSignal?) => {
      try {
        return {
          success: true,
          content: await RequestHandler.handleRequest(
            pluginRequest,
            defaultUniqueId,
            abortSignal
          ),
        };
      } catch (error) {
        let errorMessage: string;

        if (error instanceof Error) {
          // Standard Error instance
          errorMessage = error.message;
        } else {
          // Fallback for non-Error objects
          errorMessage = String(error);
        }

        Logger.error(errorMessage);

        return {
          success: false,
          content: errorMessage,
        };
      }
    },
    options
  );
}

function initializeSvelteApp(): {
  app: Record<string, any>;
  mountEl: HTMLDivElement;
} {
  const mountEl = document.createElement("div");
  mountEl.id = `${PLUGIN_NAME}-app`;

  document.body.appendChild(mountEl);

  const app = mount(App, {
    target: mountEl,
  });

  Logger.debug("Svelte app initialized");
  return { app, mountEl };
}

// Register providers
const groupedLLMDefs = groupLLMDefinitionByProvider();

Object.entries(groupedLLMDefs).forEach(([provider, definitions]) => {
  definitions.forEach((def) => {
    addProviderEx(
      `[${PLUGIN_TITLE}] [${provider}] ${def.uniqueId}`,
      def.uniqueId
    );
  });
});

// Initialize
RisuCharMessageAutoTranslator.initialize();
RisuTextAreaEnhancer.initialize();
new PluginSettingsUI(PLUGIN_SETTING_DEFINITIONS).initialize();

const { app, mountEl } = initializeSvelteApp();
// testModalOpen.set(true);

// Cleanup
risuAPI.onUnload(async () => {
  RisuCharMessageAutoTranslator.dispose();
  RisuTextAreaEnhancer.dispose();
  PluginTimerUI.stop();

  // unmount(app);
  // mountEl.remove();

  Logger.debug(`${PLUGIN_NAME} unloaded`);
});

// console.log(risuAPI.getDatabase())
