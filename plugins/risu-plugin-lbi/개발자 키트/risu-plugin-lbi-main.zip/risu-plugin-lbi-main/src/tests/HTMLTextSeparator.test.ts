class HTMLTextSeparator {
  public textNodes: Text[];

  // Tags to skip during parsing
  private static readonly skipTags: readonly string[] = ["style", "script"];

  private parser: DOMParser;
  private doc: Document;

  public constructor(html: string) {
    // Create a new DOMParser instance
    this.parser = new DOMParser();

    // Parse the HTML string into a DOM document
    this.doc = this.parser.parseFromString(`<body>${html}</body>`, "text/html");

    // Store text nodes
    this.textNodes = [];

    // Parse the document
    this.parseDocument();
  }

  // Get the final HTML output without html/head/body wrapper
  public toString(): string {
    return this.doc.body.innerHTML;
  }

  // Collect text nodes from the document
  private parseDocument(): void {
    if (!this.doc.body) {
      throw new Error("Document body is null");
    }

    this.textNodes = this.collectTextNodes(this.doc.body);
  }

  // Recursively collect text nodes
  private collectTextNodes(node: Node, textNodes: Text[] = []): Text[] {
    // Skip if node is in skipTags
    if (
      node.nodeName &&
      HTMLTextSeparator.skipTags.includes(node.nodeName.toLowerCase())
    ) {
      return textNodes;
    }

    // If it's a text node with non-empty content and contains at least one letter
    if (node instanceof Text) {
      const content = node.textContent?.trim() || "";
      if (content.length > 0 && /[\p{L}]/gu.test(content)) {
        textNodes.push(node);
      }
    }

    // Recursively process child nodes
    for (const childNode of node.childNodes) {
      this.collectTextNodes(childNode, textNodes);
    }

    return textNodes;
  }
}

const testCases: { name: string; input: string; expected: string }[] = [
  {
    name: "간단한 HTML",
    input: `<div>일반 텍스트</div>`,
    expected: `<div>일반 텍스트</div>`,
  },
  {
    name: "복잡한 HTML",
    input: `<div class="status-item"><span class="label">Location:</span><span class="value">Forest</span></div>`,
    expected: `<div class="status-item"><span class="label">Location:</span><span class="value">Forest</span></div>`,
  },
  {
    name: "이모티콘만 있는 태그",
    input: `<p>🎮 🎲 🎯</p>`,
    expected: `<p>🎮 🎲 🎯</p>`,
  },
  {
    name: "속성에 <, > 포함된 경우",
    input: `<div title="a < > b">텍스트</div>`,
    expected: `<div title="a < > b">텍스트</div>`,
  },
  {
    name: "Void 태그",
    input: `<p>텍스트<br>다음 줄<img src="test.jpg">끝</p>`,
    expected: `<p>텍스트<br>다음 줄<img src="test.jpg">끝</p>`,
  },
  {
    name: "Style 태그",
    input: `<style>.test { color: red; }</style><div>텍스트</div>`,
    expected: `<style>.test { color: red; }</style><div>텍스트</div>`,
  },
  {
    name: "닫는 태그 없는 경우 1",
    input: `<div>시작<span>중간</div>끝`,
    expected: `<div>시작<span>중간</span></div>끝`,
  },
  {
    name: "닫는 태그 없는 경우 2",
    input: `<div><p>텍스트<div>중간</p>끝</div>`,
    expected: `<div><p>텍스트</p><div>중간<p></p>끝</div></div>`,
  },
  {
    name: "닫는 태그 없는 경우 3",
    input: `<style>.test { color: red;<p>텍스트</p>`,
    expected: `<style>.test { color: red;<p>텍스트</p></body></style>`,
  },
  {
    name: "실제 적용: 에셋 + 상태창",
    input: `
# Sample Text
## Volume 1: Into the Depths of Adventure
### Episode 17: The Weights of Reality


You quietly watch the **embers** still floating through the autumn air, each spark a symbol of the party's success. The **thrum** of triumph vibrates lightly in the hearts of your companions, with Serena stretching her arms in contentment after the battle's end, and Aria still giddily bouncing on her toes, unable to stop reliving the highlight of her **Explosion** spell.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f323438356531303361353831313538376665613935643266366333386530303465636335636439383934333136393466323839326539636363323865313436392e706e67" class="x-risu-roundedImage"> </div>



Pelria, though, is the first to notice that you aren't joining in on the post-battle banter. Her brow furrows ever so slightly, her keen eyes locking onto your quiet demeanor. **“You’re unusually silent,”** she remarks sharply, crossing her arms. **“Oi, don’t tell me you’re not feeling well after all that dodging, huh?”** Her tone is cool, trying to mask what little concern seeps through her words, but there’s no missing the way her eyes scan you, looking for any sign of weakness.

**‘That stupid hammer of hers would probably come out again...’** you think briefly, suppressing the sudden throb in your head. You’ve felt this before. **Somnilium** is running low — an inconvenience, especially when your mind is still reeling from the earlier battle.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f383330363466326232353430356361393636616238346561313363393064313832333834303832646664633434653566343965666438616434363463346239302e706e67" class="x-risu-roundedImage"> </div>



**“Don't sweat it, Pelria!”** Serena interrupts cheerfully, oblivious as always. She pats you on the back a bit harder than necessary, her strength evident even in casual gestures. **“User’s probably just winded from watching me take out those tentacles with all my sheer awesomeness! Right, User?”** She grins, her amber eyes shimmering with the light of victory. **“Aria’s explosion probably surprised *all* of us! Heck, I’m still buzzing from it!”**

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f376466613264303037333661626436646565653864313064623730636437623963376366386333336532623039396362633339303539383030323636393135382e706e67" class="x-risu-roundedImage"> </div>



A few feet away, **Aria** twirls happily, her robe still lightly singed at the edges but otherwise in good spirits. **“Hehehe, nee User-kun! Did you see how big that blast was?”** Her pink eyes twinkle with excitement as she clasps her hands together, bouncing with every word. **“If I cast it any bigger, we’d be clearing forests instead of monsters! Kyaaah, imagine...!”** Her giggle rings out like the chime of silver bells, blissfully unaware of the dark, sinking feeling in your mind.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f356437636164396262623831326264623432663539376239316130393533613830633930323236326639363063343539373831633131383539333238396630302e706e67" class="x-risu-roundedImage"> </div>



Pelria, however, isn’t so easily distracted. Her eyes narrow at Serena and Aria, then back to you. **“We’ve completed the quest. That much is clear.”** She gestures toward the scorched crater where the monster once stood. Her voice takes on a firmer tone as she adjusts her hammer at her waist, a no-nonsense approach taking over. **“Let’s head back to the guild. We need to report this and get our reward, *before* anything else happens.”** Her gaze lingers on you for a second longer, her lips tightening briefly in contemplation.

You hear the underlying note in her words — she suspects something is off with you, but like always, she keeps things professional. The subtle pounding at your temples worsens slightly, and you realize that Pelria is right. A quick return to the guild is essential. Not just for the reward, but for the Somnilium you desperately need.

Before you can dwell on the thought further, Serena claps her hands loudly. **“Yosh! Back to the guild it is!”** She beams, sword slung over her shoulder, her excitement never waning. **“First rounds are on me when we get to the tavern! Maybe Derrick will serve us something amazing to celebrate!”**

Aria chimes in, her enthusiasm infectious. **“Oh! Oh! I call dibs on the dessert!”** Her eyes gleam with sugar-filled dreams, completely free from worry. 

Despite your internal struggle, the party’s usual energy seems intact. As the pressure builds in your skull, you take a steadying breath and begin the trek back to the guild, trying to ignore the fact that your Somnilium supply runs dangerously low.

---
**System Notification:**  
The quest has been completed. Proceed to the guild for your reward!

---





<title>캐릭터 상태창</title>
<style>@import url('https://fonts.googleapis.com/css2?family=Hahmlet:wght@300;400;500&display=swap');

.chattext .x-risu-body-status {
  font-family: 'Hahmlet', serif;
  background-color: #f0f0f5;
  display: flex;
  justify-content: left;
  align-items: left;
  height: 100vh;
  margin: 0;
  font-size: 14px;
  /* Add this line to change overall font size */
}

.chattext .x-risu-container-status {
  display: flex;
  justify-content: left;
  height: 100%;
  flex-direction: column;
}

.chattext .x-risu-wrapper-status {
  display: flex;
  flex-direction: column;
  align-items: left;
  text-align: left;
}

.chattext .x-risu-card-status {
  background: linear-gradient(to bottom right, #6b5d96, #4d6080);
  color: #FFF;
  padding: 1em;
  border-radius: 15px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  width: fit-content;
  /* Adjust card width to fit content */
  margin-top: 1px;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 12px;
  /* Adjust card font size here */
  position: relative;
}

.chattext .x-risu-header-status {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1px 1px;
  font-size: 10px;
  /* Adjust header font size here */
}

.chattext .x-risu-icons-status {
  display: flex;
  gap: 5px;
}

.chattext .x-risu-icon-status {
  font-size: 14px;
  color: #FFF;
}

.chattext .x-risu-status-details-status {
  width: 100%;
  margin-top: 0px;
  /* Adjust gap between header and status details */
}

.chattext .x-risu-status-item-status {
  display: grid;
  grid-template-columns: auto 2fr;
  /* Adjust the grid to accommodate the label width */
  background: rgba(255, 255, 255, 0.8);
  padding: 2px;
  margin: 3px 0;
  border-radius: 5px;
  font-size: 14px;
  /* Adjust status item font size here */
}

.chattext .x-risu-label-status {
  display: inline-block;
  font-weight: bold;
  color: #724D19;
  text-align: left;
  /* 왼쪽 정렬 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
}

.chattext .x-risu-value-status {
  color: #966726;
  text-align: left;
  word-break: break-word;
  /* 긴 텍스트를 줄바꿈 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
  padding-right: 10px;
  /* 오른쪽 여백 추가 */
}</style>


<div class="x-risu-container-status">
    <div class="x-risu-wrapper-status">
        <div class="x-risu-card-status">
            <div class="x-risu-header-status">
                <div class="x-risu-icons-status">
                    <span class="x-risu-icon-status">📜</span> <span class="x-risu-icon-status">🧭</span> <span class="x-risu-icon-status">✨</span>
                </div>
                <div class="x-risu-menu-icon-status">
                    <span class="x-risu-icon-status">⋮</span>
                </div>
            </div>
            <div class="x-risu-status-details-status">
                <div class="x-risu-status-item-status"><span class="x-risu-label-status">Location:</span><span class="x-risu-value-status"> Forest Clearing, Time: Mon, Late Afternoon (Autumn) </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Player:</span><span class="x-risu-value-status"> Adventurer, Lv: 2, exp: 30 / 200 </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Skill:</span><span class="x-risu-value-status"> N/A </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> My Item:</span><span class="x-risu-value-status"> Unknown Item </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Currency:</span><span class="x-risu-value-status"> 1,200 Gold </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Party:</span><span class="x-risu-value-status"> User, Aria (Wizard), Pelria (Arch Priest), Serena (Paladin) | Surrounding situation: Post-battle calm, party heading back to guild | Current Quest: Return to guild and report quest completion (Compensation: 1,000 Gold, 30 Exp, Unknown Item)</span></div>
            </div>
        </div>
    </div>
</div>




---
`,
    expected: `
# Sample Text
## Volume 1: Into the Depths of Adventure
### Episode 17: The Weights of Reality


You quietly watch the **embers** still floating through the autumn air, each spark a symbol of the party's success. The **thrum** of triumph vibrates lightly in the hearts of your companions, with Serena stretching her arms in contentment after the battle's end, and Aria still giddily bouncing on her toes, unable to stop reliving the highlight of her **Explosion** spell.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f323438356531303361353831313538376665613935643266366333386530303465636335636439383934333136393466323839326539636363323865313436392e706e67" class="x-risu-roundedImage"> </div>



Pelria, though, is the first to notice that you aren't joining in on the post-battle banter. Her brow furrows ever so slightly, her keen eyes locking onto your quiet demeanor. **“You’re unusually silent,”** she remarks sharply, crossing her arms. **“Oi, don’t tell me you’re not feeling well after all that dodging, huh?”** Her tone is cool, trying to mask what little concern seeps through her words, but there’s no missing the way her eyes scan you, looking for any sign of weakness.

**‘That stupid hammer of hers would probably come out again...’** you think briefly, suppressing the sudden throb in your head. You’ve felt this before. **Somnilium** is running low — an inconvenience, especially when your mind is still reeling from the earlier battle.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f383330363466326232353430356361393636616238346561313363393064313832333834303832646664633434653566343965666438616434363463346239302e706e67" class="x-risu-roundedImage"> </div>



**“Don't sweat it, Pelria!”** Serena interrupts cheerfully, oblivious as always. She pats you on the back a bit harder than necessary, her strength evident even in casual gestures. **“User’s probably just winded from watching me take out those tentacles with all my sheer awesomeness! Right, User?”** She grins, her amber eyes shimmering with the light of victory. **“Aria’s explosion probably surprised *all* of us! Heck, I’m still buzzing from it!”**

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f376466613264303037333661626436646565653864313064623730636437623963376366386333336532623039396362633339303539383030323636393135382e706e67" class="x-risu-roundedImage"> </div>



A few feet away, **Aria** twirls happily, her robe still lightly singed at the edges but otherwise in good spirits. **“Hehehe, nee User-kun! Did you see how big that blast was?”** Her pink eyes twinkle with excitement as she clasps her hands together, bouncing with every word. **“If I cast it any bigger, we’d be clearing forests instead of monsters! Kyaaah, imagine...!”** Her giggle rings out like the chime of silver bells, blissfully unaware of the dark, sinking feeling in your mind.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f356437636164396262623831326264623432663539376239316130393533613830633930323236326639363063343539373831633131383539333238396630302e706e67" class="x-risu-roundedImage"> </div>



Pelria, however, isn’t so easily distracted. Her eyes narrow at Serena and Aria, then back to you. **“We’ve completed the quest. That much is clear.”** She gestures toward the scorched crater where the monster once stood. Her voice takes on a firmer tone as she adjusts her hammer at her waist, a no-nonsense approach taking over. **“Let’s head back to the guild. We need to report this and get our reward, *before* anything else happens.”** Her gaze lingers on you for a second longer, her lips tightening briefly in contemplation.

You hear the underlying note in her words — she suspects something is off with you, but like always, she keeps things professional. The subtle pounding at your temples worsens slightly, and you realize that Pelria is right. A quick return to the guild is essential. Not just for the reward, but for the Somnilium you desperately need.

Before you can dwell on the thought further, Serena claps her hands loudly. **“Yosh! Back to the guild it is!”** She beams, sword slung over her shoulder, her excitement never waning. **“First rounds are on me when we get to the tavern! Maybe Derrick will serve us something amazing to celebrate!”**

Aria chimes in, her enthusiasm infectious. **“Oh! Oh! I call dibs on the dessert!”** Her eyes gleam with sugar-filled dreams, completely free from worry. 

Despite your internal struggle, the party’s usual energy seems intact. As the pressure builds in your skull, you take a steadying breath and begin the trek back to the guild, trying to ignore the fact that your Somnilium supply runs dangerously low.

---
**System Notification:**  
The quest has been completed. Proceed to the guild for your reward!

---





<title>캐릭터 상태창</title>
<style>@import url('https://fonts.googleapis.com/css2?family=Hahmlet:wght@300;400;500&display=swap');

.chattext .x-risu-body-status {
  font-family: 'Hahmlet', serif;
  background-color: #f0f0f5;
  display: flex;
  justify-content: left;
  align-items: left;
  height: 100vh;
  margin: 0;
  font-size: 14px;
  /* Add this line to change overall font size */
}

.chattext .x-risu-container-status {
  display: flex;
  justify-content: left;
  height: 100%;
  flex-direction: column;
}

.chattext .x-risu-wrapper-status {
  display: flex;
  flex-direction: column;
  align-items: left;
  text-align: left;
}

.chattext .x-risu-card-status {
  background: linear-gradient(to bottom right, #6b5d96, #4d6080);
  color: #FFF;
  padding: 1em;
  border-radius: 15px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  width: fit-content;
  /* Adjust card width to fit content */
  margin-top: 1px;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 12px;
  /* Adjust card font size here */
  position: relative;
}

.chattext .x-risu-header-status {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1px 1px;
  font-size: 10px;
  /* Adjust header font size here */
}

.chattext .x-risu-icons-status {
  display: flex;
  gap: 5px;
}

.chattext .x-risu-icon-status {
  font-size: 14px;
  color: #FFF;
}

.chattext .x-risu-status-details-status {
  width: 100%;
  margin-top: 0px;
  /* Adjust gap between header and status details */
}

.chattext .x-risu-status-item-status {
  display: grid;
  grid-template-columns: auto 2fr;
  /* Adjust the grid to accommodate the label width */
  background: rgba(255, 255, 255, 0.8);
  padding: 2px;
  margin: 3px 0;
  border-radius: 5px;
  font-size: 14px;
  /* Adjust status item font size here */
}

.chattext .x-risu-label-status {
  display: inline-block;
  font-weight: bold;
  color: #724D19;
  text-align: left;
  /* 왼쪽 정렬 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
}

.chattext .x-risu-value-status {
  color: #966726;
  text-align: left;
  word-break: break-word;
  /* 긴 텍스트를 줄바꿈 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
  padding-right: 10px;
  /* 오른쪽 여백 추가 */
}</style>


<div class="x-risu-container-status">
    <div class="x-risu-wrapper-status">
        <div class="x-risu-card-status">
            <div class="x-risu-header-status">
                <div class="x-risu-icons-status">
                    <span class="x-risu-icon-status">📜</span> <span class="x-risu-icon-status">🧭</span> <span class="x-risu-icon-status">✨</span>
                </div>
                <div class="x-risu-menu-icon-status">
                    <span class="x-risu-icon-status">⋮</span>
                </div>
            </div>
            <div class="x-risu-status-details-status">
                <div class="x-risu-status-item-status"><span class="x-risu-label-status">Location:</span><span class="x-risu-value-status"> Forest Clearing, Time: Mon, Late Afternoon (Autumn) </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Player:</span><span class="x-risu-value-status"> Adventurer, Lv: 2, exp: 30 / 200 </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Skill:</span><span class="x-risu-value-status"> N/A </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> My Item:</span><span class="x-risu-value-status"> Unknown Item </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Currency:</span><span class="x-risu-value-status"> 1,200 Gold </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Party:</span><span class="x-risu-value-status"> User, Aria (Wizard), Pelria (Arch Priest), Serena (Paladin) | Surrounding situation: Post-battle calm, party heading back to guild | Current Quest: Return to guild and report quest completion (Compensation: 1,000 Gold, 30 Exp, Unknown Item)</span></div>
            </div>
        </div>
    </div>
</div>




---
`,
  },
  {
    name: "실제 적용: 에셋 + 상태창 + 챗 데코레이터",
    input: `
# Sample Text
<div class="x-risu-GHCT_Div_P">
<div class="x-risu-GHCT_Head_P1">
<div class="x-risu-GHCT_Head_P2">
System</div></div>
## Volume 1: Into the Depths of Adventure
### Episode 17: The Weights of Reality


You quietly watch the **embers** still floating through the autumn air, each spark a symbol of the party's success. The **thrum** of triumph vibrates lightly in the hearts of your companions, with Serena stretching her arms in contentment after the battle's end, and Aria still giddily bouncing on her toes, unable to stop reliving the highlight of her **Explosion** spell.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f323438356531303361353831313538376665613935643266366333386530303465636335636439383934333136393466323839326539636363323865313436392e706e67" class="x-risu-roundedImage"> </div>



Pelria, though, is the first to notice that you aren't joining in on the post-battle banter. Her brow furrows ever so slightly, her keen eyes locking onto your quiet demeanor. **“You’re unusually silent,”** she remarks sharply, crossing her arms. **“Oi, don’t tell me you’re not feeling well after all that dodging, huh?”** Her tone is cool, trying to mask what little concern seeps through her words, but there’s no missing the way her eyes scan you, looking for any sign of weakness.

**‘That stupid hammer of hers would probably come out again...’** you think briefly, suppressing the sudden throb in your head. You’ve felt this before. **Somnilium** is running low — an inconvenience, especially when your mind is still reeling from the earlier battle.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f383330363466326232353430356361393636616238346561313363393064313832333834303832646664633434653566343965666438616434363463346239302e706e67" class="x-risu-roundedImage"> </div>



**“Don't sweat it, Pelria!”** Serena interrupts cheerfully, oblivious as always. She pats you on the back a bit harder than necessary, her strength evident even in casual gestures. **“User’s probably just winded from watching me take out those tentacles with all my sheer awesomeness! Right, User?”** She grins, her amber eyes shimmering with the light of victory. **“Aria’s explosion probably surprised *all* of us! Heck, I’m still buzzing from it!”**

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f376466613264303037333661626436646565653864313064623730636437623963376366386333336532623039396362633339303539383030323636393135382e706e67" class="x-risu-roundedImage"> </div>



A few feet away, **Aria** twirls happily, her robe still lightly singed at the edges but otherwise in good spirits. **“Hehehe, nee User-kun! Did you see how big that blast was?”** Her pink eyes twinkle with excitement as she clasps her hands together, bouncing with every word. **“If I cast it any bigger, we’d be clearing forests instead of monsters! Kyaaah, imagine...!”** Her giggle rings out like the chime of silver bells, blissfully unaware of the dark, sinking feeling in your mind.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f356437636164396262623831326264623432663539376239316130393533613830633930323236326639363063343539373831633131383539333238396630302e706e67" class="x-risu-roundedImage"> </div>



Pelria, however, isn’t so easily distracted. Her eyes narrow at Serena and Aria, then back to you. **“We’ve completed the quest. That much is clear.”** She gestures toward the scorched crater where the monster once stood. Her voice takes on a firmer tone as she adjusts her hammer at her waist, a no-nonsense approach taking over. **“Let’s head back to the guild. We need to report this and get our reward, *before* anything else happens.”** Her gaze lingers on you for a second longer, her lips tightening briefly in contemplation.

You hear the underlying note in her words — she suspects something is off with you, but like always, she keeps things professional. The subtle pounding at your temples worsens slightly, and you realize that Pelria is right. A quick return to the guild is essential. Not just for the reward, but for the Somnilium you desperately need.

Before you can dwell on the thought further, Serena claps her hands loudly. **“Yosh! Back to the guild it is!”** She beams, sword slung over her shoulder, her excitement never waning. **“First rounds are on me when we get to the tavern! Maybe Derrick will serve us something amazing to celebrate!”**

Aria chimes in, her enthusiasm infectious. **“Oh! Oh! I call dibs on the dessert!”** Her eyes gleam with sugar-filled dreams, completely free from worry. 

Despite your internal struggle, the party’s usual energy seems intact. As the pressure builds in your skull, you take a steadying breath and begin the trek back to the guild, trying to ignore the fact that your Somnilium supply runs dangerously low.

---
**System Notification:**  
The quest has been completed. Proceed to the guild for your reward!

---





<title>캐릭터 상태창</title>
<style>@import url('https://fonts.googleapis.com/css2?family=Hahmlet:wght@300;400;500&display=swap');

.chattext .x-risu-body-status {
  font-family: 'Hahmlet', serif;
  background-color: #f0f0f5;
  display: flex;
  justify-content: left;
  align-items: left;
  height: 100vh;
  margin: 0;
  font-size: 14px;
  /* Add this line to change overall font size */
}

.chattext .x-risu-container-status {
  display: flex;
  justify-content: left;
  height: 100%;
  flex-direction: column;
}

.chattext .x-risu-wrapper-status {
  display: flex;
  flex-direction: column;
  align-items: left;
  text-align: left;
}

.chattext .x-risu-card-status {
  background: linear-gradient(to bottom right, #6b5d96, #4d6080);
  color: #FFF;
  padding: 1em;
  border-radius: 15px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  width: fit-content;
  /* Adjust card width to fit content */
  margin-top: 1px;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 12px;
  /* Adjust card font size here */
  position: relative;
}

.chattext .x-risu-header-status {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1px 1px;
  font-size: 10px;
  /* Adjust header font size here */
}

.chattext .x-risu-icons-status {
  display: flex;
  gap: 5px;
}

.chattext .x-risu-icon-status {
  font-size: 14px;
  color: #FFF;
}

.chattext .x-risu-status-details-status {
  width: 100%;
  margin-top: 0px;
  /* Adjust gap between header and status details */
}

.chattext .x-risu-status-item-status {
  display: grid;
  grid-template-columns: auto 2fr;
  /* Adjust the grid to accommodate the label width */
  background: rgba(255, 255, 255, 0.8);
  padding: 2px;
  margin: 3px 0;
  border-radius: 5px;
  font-size: 14px;
  /* Adjust status item font size here */
}

.chattext .x-risu-label-status {
  display: inline-block;
  font-weight: bold;
  color: #724D19;
  text-align: left;
  /* 왼쪽 정렬 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
}

.chattext .x-risu-value-status {
  color: #966726;
  text-align: left;
  word-break: break-word;
  /* 긴 텍스트를 줄바꿈 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
  padding-right: 10px;
  /* 오른쪽 여백 추가 */
}</style>


<div class="x-risu-container-status">
    <div class="x-risu-wrapper-status">
        <div class="x-risu-card-status">
            <div class="x-risu-header-status">
                <div class="x-risu-icons-status">
                    <span class="x-risu-icon-status">📜</span> <span class="x-risu-icon-status">🧭</span> <span class="x-risu-icon-status">✨</span>
                </div>
                <div class="x-risu-menu-icon-status">
                    <span class="x-risu-icon-status">⋮</span>
                </div>
            </div>
            <div class="x-risu-status-details-status">
                <div class="x-risu-status-item-status"><span class="x-risu-label-status">Location:</span><span class="x-risu-value-status"> Forest Clearing, Time: Mon, Late Afternoon (Autumn) </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Player:</span><span class="x-risu-value-status"> Adventurer, Lv: 2, exp: 30 / 200 </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Skill:</span><span class="x-risu-value-status"> N/A </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> My Item:</span><span class="x-risu-value-status"> Unknown Item </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Currency:</span><span class="x-risu-value-status"> 1,200 Gold </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Party:</span><span class="x-risu-value-status"> User, Aria (Wizard), Pelria (Arch Priest), Serena (Paladin) | Surrounding situation: Post-battle calm, party heading back to guild | Current Quest: Return to guild and report quest completion (Compensation: 1,000 Gold, 30 Exp, Unknown Item)</span></div>
            </div>
        </div>
    </div>
</div>




---
</div>
`,
    expected: `
# Sample Text
<div class="x-risu-GHCT_Div_P">
<div class="x-risu-GHCT_Head_P1">
<div class="x-risu-GHCT_Head_P2">
System</div></div>
## Volume 1: Into the Depths of Adventure
### Episode 17: The Weights of Reality


You quietly watch the **embers** still floating through the autumn air, each spark a symbol of the party's success. The **thrum** of triumph vibrates lightly in the hearts of your companions, with Serena stretching her arms in contentment after the battle's end, and Aria still giddily bouncing on her toes, unable to stop reliving the highlight of her **Explosion** spell.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f323438356531303361353831313538376665613935643266366333386530303465636335636439383934333136393466323839326539636363323865313436392e706e67" class="x-risu-roundedImage"> </div>



Pelria, though, is the first to notice that you aren't joining in on the post-battle banter. Her brow furrows ever so slightly, her keen eyes locking onto your quiet demeanor. **“You’re unusually silent,”** she remarks sharply, crossing her arms. **“Oi, don’t tell me you’re not feeling well after all that dodging, huh?”** Her tone is cool, trying to mask what little concern seeps through her words, but there’s no missing the way her eyes scan you, looking for any sign of weakness.

**‘That stupid hammer of hers would probably come out again...’** you think briefly, suppressing the sudden throb in your head. You’ve felt this before. **Somnilium** is running low — an inconvenience, especially when your mind is still reeling from the earlier battle.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f383330363466326232353430356361393636616238346561313363393064313832333834303832646664633434653566343965666438616434363463346239302e706e67" class="x-risu-roundedImage"> </div>



**“Don't sweat it, Pelria!”** Serena interrupts cheerfully, oblivious as always. She pats you on the back a bit harder than necessary, her strength evident even in casual gestures. **“User’s probably just winded from watching me take out those tentacles with all my sheer awesomeness! Right, User?”** She grins, her amber eyes shimmering with the light of victory. **“Aria’s explosion probably surprised *all* of us! Heck, I’m still buzzing from it!”**

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f376466613264303037333661626436646565653864313064623730636437623963376366386333336532623039396362633339303539383030323636393135382e706e67" class="x-risu-roundedImage"> </div>



A few feet away, **Aria** twirls happily, her robe still lightly singed at the edges but otherwise in good spirits. **“Hehehe, nee User-kun! Did you see how big that blast was?”** Her pink eyes twinkle with excitement as she clasps her hands together, bouncing with every word. **“If I cast it any bigger, we’d be clearing forests instead of monsters! Kyaaah, imagine...!”** Her giggle rings out like the chime of silver bells, blissfully unaware of the dark, sinking feeling in your mind.

<style>.chattext .x-risu-container {
  display: grid;
  place-items: center;
  width: 100%;
}

.chattext .x-risu-roundedImage {
  max-width: 400px;
  width: 100%;
  height: auto;
  border-radius: 10px;
}</style> <div class="x-risu-container"> <img src="/sw/img/6173736574732f356437636164396262623831326264623432663539376239316130393533613830633930323236326639363063343539373831633131383539333238396630302e706e67" class="x-risu-roundedImage"> </div>



Pelria, however, isn’t so easily distracted. Her eyes narrow at Serena and Aria, then back to you. **“We’ve completed the quest. That much is clear.”** She gestures toward the scorched crater where the monster once stood. Her voice takes on a firmer tone as she adjusts her hammer at her waist, a no-nonsense approach taking over. **“Let’s head back to the guild. We need to report this and get our reward, *before* anything else happens.”** Her gaze lingers on you for a second longer, her lips tightening briefly in contemplation.

You hear the underlying note in her words — she suspects something is off with you, but like always, she keeps things professional. The subtle pounding at your temples worsens slightly, and you realize that Pelria is right. A quick return to the guild is essential. Not just for the reward, but for the Somnilium you desperately need.

Before you can dwell on the thought further, Serena claps her hands loudly. **“Yosh! Back to the guild it is!”** She beams, sword slung over her shoulder, her excitement never waning. **“First rounds are on me when we get to the tavern! Maybe Derrick will serve us something amazing to celebrate!”**

Aria chimes in, her enthusiasm infectious. **“Oh! Oh! I call dibs on the dessert!”** Her eyes gleam with sugar-filled dreams, completely free from worry. 

Despite your internal struggle, the party’s usual energy seems intact. As the pressure builds in your skull, you take a steadying breath and begin the trek back to the guild, trying to ignore the fact that your Somnilium supply runs dangerously low.

---
**System Notification:**  
The quest has been completed. Proceed to the guild for your reward!

---





<title>캐릭터 상태창</title>
<style>@import url('https://fonts.googleapis.com/css2?family=Hahmlet:wght@300;400;500&display=swap');

.chattext .x-risu-body-status {
  font-family: 'Hahmlet', serif;
  background-color: #f0f0f5;
  display: flex;
  justify-content: left;
  align-items: left;
  height: 100vh;
  margin: 0;
  font-size: 14px;
  /* Add this line to change overall font size */
}

.chattext .x-risu-container-status {
  display: flex;
  justify-content: left;
  height: 100%;
  flex-direction: column;
}

.chattext .x-risu-wrapper-status {
  display: flex;
  flex-direction: column;
  align-items: left;
  text-align: left;
}

.chattext .x-risu-card-status {
  background: linear-gradient(to bottom right, #6b5d96, #4d6080);
  color: #FFF;
  padding: 1em;
  border-radius: 15px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  width: fit-content;
  /* Adjust card width to fit content */
  margin-top: 1px;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 12px;
  /* Adjust card font size here */
  position: relative;
}

.chattext .x-risu-header-status {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1px 1px;
  font-size: 10px;
  /* Adjust header font size here */
}

.chattext .x-risu-icons-status {
  display: flex;
  gap: 5px;
}

.chattext .x-risu-icon-status {
  font-size: 14px;
  color: #FFF;
}

.chattext .x-risu-status-details-status {
  width: 100%;
  margin-top: 0px;
  /* Adjust gap between header and status details */
}

.chattext .x-risu-status-item-status {
  display: grid;
  grid-template-columns: auto 2fr;
  /* Adjust the grid to accommodate the label width */
  background: rgba(255, 255, 255, 0.8);
  padding: 2px;
  margin: 3px 0;
  border-radius: 5px;
  font-size: 14px;
  /* Adjust status item font size here */
}

.chattext .x-risu-label-status {
  display: inline-block;
  font-weight: bold;
  color: #724D19;
  text-align: left;
  /* 왼쪽 정렬 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
}

.chattext .x-risu-value-status {
  color: #966726;
  text-align: left;
  word-break: break-word;
  /* 긴 텍스트를 줄바꿈 */
  padding-left: 5px;
  /* 왼쪽 여백 추가 */
  padding-right: 10px;
  /* 오른쪽 여백 추가 */
}</style>


<div class="x-risu-container-status">
    <div class="x-risu-wrapper-status">
        <div class="x-risu-card-status">
            <div class="x-risu-header-status">
                <div class="x-risu-icons-status">
                    <span class="x-risu-icon-status">📜</span> <span class="x-risu-icon-status">🧭</span> <span class="x-risu-icon-status">✨</span>
                </div>
                <div class="x-risu-menu-icon-status">
                    <span class="x-risu-icon-status">⋮</span>
                </div>
            </div>
            <div class="x-risu-status-details-status">
                <div class="x-risu-status-item-status"><span class="x-risu-label-status">Location:</span><span class="x-risu-value-status"> Forest Clearing, Time: Mon, Late Afternoon (Autumn) </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Player:</span><span class="x-risu-value-status"> Adventurer, Lv: 2, exp: 30 / 200 </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Skill:</span><span class="x-risu-value-status"> N/A </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> My Item:</span><span class="x-risu-value-status"> Unknown Item </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Currency:</span><span class="x-risu-value-status"> 1,200 Gold </span></div>
                <div class="x-risu-status-item-status"><span class="x-risu-label-status"> Party:</span><span class="x-risu-value-status"> User, Aria (Wizard), Pelria (Arch Priest), Serena (Paladin) | Surrounding situation: Post-battle calm, party heading back to guild | Current Quest: Return to guild and report quest completion (Compensation: 1,000 Gold, 30 Exp, Unknown Item)</span></div>
            </div>
        </div>
    </div>
</div>




---
</div>
`,
  },
  {
    name: "마크다운",
    input: `
<div style="null" class="x-risu-GHCT_Div_C">
<div class="x-risu-GHCT_Head_C1">
<p class="x-risu-GHCT_Head_C2">
Neon Crescendo
</p>
<div class="x-risu-emoji-container">
<button risu-trigger="TR_scroll1">⏷</button>
<button risu-trigger="TR_scroll2">⏶</button>
</div>
</div>
<div class="x-risu-GHCT_Body">
<div style="background-image: url('/sw/img/6173736574732f616138383434613431333436343866356339646230363065393138616338663537396166643930316333366165356639306163646336653433366230636630332e706e67');" class="x-risu-GHCT_ST">
</div>
<div style="border-left: 1px solid #B8B8B8; padding-left: 35px; null" class="x-risu-GHCT_Content">



"Hey, it's Ruae! We've actually been looking for you. We have a proposal that you might find really interesting!"



"Right, Ruae! We've seen your skills and we think you'd be a perfect fit for Neon Crescendo, our band. We'd really love for you to join us!"
*test*
**test**
***test***
**"test"**
"**test**"
</div>
</div>
</div>
`,
    expected: `
<div style="null" class="x-risu-GHCT_Div_C">
<div class="x-risu-GHCT_Head_C1">
<p class="x-risu-GHCT_Head_C2">
Neon Crescendo
</p>
<div class="x-risu-emoji-container">
<button risu-trigger="TR_scroll1">⏷</button>
<button risu-trigger="TR_scroll2">⏶</button>
</div>
</div>
<div class="x-risu-GHCT_Body">
<div style="background-image: url('/sw/img/6173736574732f616138383434613431333436343866356339646230363065393138616338663537396166643930316333366165356639306163646336653433366230636630332e706e67');" class="x-risu-GHCT_ST">
</div>
<div style="border-left: 1px solid #B8B8B8; padding-left: 35px; null" class="x-risu-GHCT_Content">



"Hey, it's Ruae! We've actually been looking for you. We have a proposal that you might find really interesting!"



"Right, Ruae! We've seen your skills and we think you'd be a perfect fit for Neon Crescendo, our band. We'd really love for you to join us!"
*test*
**test**
***test***
**"test"**
"**test**"
</div>
</div>
</div>
`,
  },
  {
    name: "마크다운 2",
    input: `
"이봐, 루애야! 사실 너를 찾고 있었어. 네가 정말 흥미로워할 만한 제안이 있어!"



"그래, 루애! 네 실력을 봤는데 우리 밴드 네온 크레센도에 딱 맞을 것 같아. 네가 우리와 함께 해줬으면 정말 좋겠어!"
*test*
**test**
***test***
**"test"**
"**test**"
Input Translation (""Input Translation"")
`,
    expected: `
"이봐, 루애야! 사실 너를 찾고 있었어. 네가 정말 흥미로워할 만한 제안이 있어!"



"그래, 루애! 네 실력을 봤는데 우리 밴드 네온 크레센도에 딱 맞을 것 같아. 네가 우리와 함께 해줬으면 정말 좋겠어!"
*test*
**test**
***test***
**"test"**
"**test**"
Input Translation (""Input Translation"")
`,
  },
] as const;

function getOutput(input: string): string {
  const parser = new HTMLTextSeparator(input);
  const textNodes: Text[] = parser.textNodes.filter((node) => node.textContent);
  const matchBetweenSpaces = /^\s*([\s\S]+?)\s*$/;

  // Create JSON object
  const jsonInput = textNodes.map((node, index) => ({
    id: index,
    source_text: node.textContent!.match(matchBetweenSpaces)![1],
  }));

  const stringifiedJsonInput = JSON.stringify(jsonInput);
  const response = stringifiedJsonInput.replace(/source_text/g, "target_text");

  // Try parsing JSON
  let responseJson: Array<{ id: number; target_text: string }> | null =
    JSON.parse(response.match(/\[[\s\S]*\]/)![0]);

  responseJson!.forEach(({ id, target_text }) => {
    if (id >= 0 && id < textNodes.length) {
      const node = textNodes[id];

      node.textContent = node.textContent!.replace(
        matchBetweenSpaces,
        (match, p1) => {
          return match.replace(p1, target_text);
        }
      );
    }
  });

  // Create final output
  return parser.toString();
}

export async function runTests(): Promise<void> {
  console.log("Starting tests...\n");

  let passCount = 0;
  let failCount = 0;

  for (const testCase of testCases) {
    try {
      console.log(`Testing: ${testCase.name}`);
      console.log(`Input: ${testCase.input}`);

      const output = getOutput(testCase.input);

      console.log(`Output: ${output}`);

      if (output === testCase.expected) {
        console.log("✅ Test PASS");
        passCount++;
      } else {
        console.log("❌ Test FAIL");
        failCount++;
      }
    } catch (error: any) {
      console.log(`❌ ERROR: ${error.message}`);
      failCount++;
    }

    console.log("\n---\n");
  }

  console.log(`Test Summary:`);
  console.log(`Total: ${testCases.length}`);
  console.log(`Passed: ${passCount}`);
  console.log(`Failed: ${failCount}`);
}
