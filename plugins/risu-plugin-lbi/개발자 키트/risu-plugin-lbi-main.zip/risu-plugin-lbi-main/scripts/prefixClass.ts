import * as readline from "node:readline";

const prefix = "tw";
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function askForInput(): void {
  rl.question("> ", (input) => {
    if (input.trim()) {
      const output = addPrefix(input);
      console.log(`${output}\n`);
    }

    askForInput();
  });
}

function addPrefix(input: string): string {
  return input
    .split(" ")
    .map((cls) => {
      cls = cls.trim();
      if (!cls) return cls;
      if (cls.startsWith(prefix)) return cls;
      return `${prefix}:${cls}`;
    })
    .join(" ");
}

console.log(`Prefix: "${prefix}" - Enter class names (Ctrl+C to exit):`);

askForInput();
