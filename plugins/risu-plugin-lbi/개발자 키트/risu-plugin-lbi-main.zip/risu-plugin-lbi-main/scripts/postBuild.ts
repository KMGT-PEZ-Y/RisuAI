import * as fs from "node:fs";
import * as path from "node:path";
import { PLUGIN_SETTING_DEFINITIONS_BASE } from "../src/ts/pluginSettingBase.ts";

interface PluginInfo {
  title: string;
  version: string;
}

class PluginDeployer {
  private readonly pluginPath: string;
  private content: string;

  constructor(pluginPath: string) {
    this.pluginPath = pluginPath;
    this.content = fs.readFileSync(this.pluginPath, "utf8");
  }

  public deploy(): void {
    this.removeImports();
    this.addMetadata();

    fs.writeFileSync(this.pluginPath, this.content, "utf8"); // Write back to original file
    console.log(`Modified: ${this.pluginPath}`);

    const pluginDir = path.dirname(this.pluginPath);
    const pluginName = this.getPluginName();
    // const timestamp = this.getTimestamp();
    const fileName = `${pluginName}.js`;

    fs.copyFileSync(this.pluginPath, path.join(pluginDir, fileName));
    console.log(`Created: ${fileName}`);
  }

  private removeImports(): void {
    this.content = this.content.replace(
      /import\s+[\s\S]+?from\s+["'].+["'];{0,1}/g,
      ""
    );
  }

  private addMetadata(): void {
    // Insert metadata at the top
    this.content = "\n" + this.content;
    this.content =
      Object.keys(PLUGIN_SETTING_DEFINITIONS_BASE)
        .map((key) => `//@arg ${key} string`)
        .join("\n") + this.content;

    const pluginName = this.getPluginName();

    this.content =
      `//@name ${pluginName}\n//@display-name ${pluginName}\n` + this.content;
  }

  private getPluginName(): string {
    const { title, version } = this.extractPluginInfo();

    return `${title}-${version}`;
  }

  private extractPluginInfo(): PluginInfo {
    const titleMatch = this.content.match(
      /const PLUGIN_TITLE = ["'](.+?)["'];/
    );
    const versionMatch = this.content.match(
      /const PLUGIN_VERSION = ["'](.+?)["'];/
    );

    if (!titleMatch || !versionMatch) {
      console.error("Could not find PLUGIN_TITLE or PLUGIN_VERSION.");
      process.exit(1);
    }

    return {
      title: titleMatch[1],
      version: versionMatch[1],
    };
  }

  public getTimestamp(): string {
    return new Date().toLocaleString("sv-SE").replace(/:/g, "");
  }
}

try {
  const deployer = new PluginDeployer("dist/plugin.js");

  deployer.deploy();
} catch (error) {
  console.error("Error depolying plugin:", error);
  process.exit(1);
}
